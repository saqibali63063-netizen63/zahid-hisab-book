# Zahid Hisab Book - Android APK Packaging & Installation Guide

This guide explains how to package **Zahid Hisab Book** into an installable Android APK file for personal use on any Android phone using **Capacitor** and **Android Studio**.

---

## Prerequisites (on your PC/Laptop)
1. **Node.js** (v18 or newer installed)
2. **Android Studio** (Download free from [developer.android.com/studio](https://developer.android.com/studio))
3. Your Android phone with **USB Debugging** enabled or transfer cable/WhatsApp to send the `.apk` file.

---

## Step 1: Install Capacitor Dependencies
Open your project terminal in this directory and run:

```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
```

---

## Step 2: Build the Web Production Assets
Compile the optimized web application:

```bash
npm run build
```
This generates the offline-ready HTML, CSS, and JS inside the `dist/` directory.

---

## Step 3: Initialize Capacitor & Add Android Platform
Run the following commands:

```bash
npx cap init "Zahid Hisab Book" "com.zahidmobiles.hisabbook" --web-dir dist
npx cap add android
npx cap copy android
```

This creates a native `android/` project folder with all Gradle and Android Studio configurations pre-configured.

---

## Step 4: Open in Android Studio
Launch Android Studio with the newly created native project:

```bash
npx cap open android
```

Wait 1-2 minutes for Gradle to complete initial sync.

---

## Step 5: Android Permissions (Minimal & Safe)
In `android/app/src/main/AndroidManifest.xml`, ensure only essential local permissions are included:
```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <!-- Optional: vibration for keypad feedback -->
    <uses-permission android:name="android.permission.VIBRATE" />
    <!-- Optional: writing export files if needed -->
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Zahid Hisab"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme">
        <activity
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode"
            android:name=".MainActivity"
            android:label="Zahid Hisab Book"
            android:theme="@style/AppTheme.NoActionBarLaunch"
            android:launchMode="singleTask"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
```

---

## Step 6: Generate the APK File

### Option A: Build Debug APK (Easiest for Personal Use)
1. In Android Studio's top menu, click:  
   **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**
2. Once build completes, click the **"locate"** popup link in the bottom-right corner.
3. Your ready-to-install APK file is located at:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

### Option B: Build Signed Release APK (Production/Personal Permanent)
1. In Android Studio, click:  
   **Build** > **Generate Signed Bundle / APK...**
2. Choose **APK**, click **Next**.
3. Under **Key store path**, click **Create new...** (choose any password and alias like `zahidkey`).
4. Select destination folder and choose **release** build variant with **V1 (Jar Signature)** and **V2 (Full APK Signature)** checked.
5. Click **Finish**. Your signed release APK will be in:
   ```
   android/app/release/app-release.apk
   ```

---

## Step 7: Install on Your Android Phone
1. Send the `app-debug.apk` or `app-release.apk` to your phone via:
   - USB cable transfer
   - WhatsApp (send document)
   - Google Drive or Telegram
2. Tap the APK file on your Android phone.
3. If prompted: **"For your security, your phone is not allowed to install unknown apps from this source"**, tap **Settings** and toggle **"Allow from this source"**.
4. Tap **Install**.
5. Done! The "Zahid Hisab Book" app is now permanently installed on your phone, working 100% offline with full data persistence.
