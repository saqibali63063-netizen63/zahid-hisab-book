# Zahid Hisab Book — APK build

This project is configured to build an Android debug APK using GitHub Actions.

1. Extract this ZIP on your computer.
2. Create a new GitHub repository and upload all files/folders from this project.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and press **Run workflow** (or push to `main`).
5. When the run finishes successfully, open that workflow run and download the artifact named **zahid-hisab-book-apk**.
6. Extract the downloaded artifact. It contains `app-debug.apk`.
7. Send `app-debug.apk` to your Android phone, tap it, allow installation from that source if prompted, then install.

The APK is a debug-signed personal-install build. It is not a Play Store release.
