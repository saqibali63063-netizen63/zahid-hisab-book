/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useCallback } from 'react';
import {
  Account,
  AccountId,
  CommissionServiceType,
  Customer,
  ShopSettings,
  Supplier,
  Transaction,
  TransactionType,
} from './types';
import {
  deleteCustomer,
  deleteSupplier,
  deleteTransaction,
  getAccounts,
  getCustomers,
  getShopSettings,
  getSuppliers,
  getTransactions,
  recalculateBalances,
  saveCustomer,
  saveShopSettings,
  saveSupplier,
  saveTransaction,
  cleanupLegacyDemoData,
} from './lib/db';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { Header } from './components/Header';
import { BottomNav, TabType } from './components/BottomNav';
import { Dashboard } from './components/Dashboard';
import { TransactionList } from './components/TransactionList';
import { KhataManager } from './components/KhataManager';
import { ReportsView } from './components/ReportsView';
import { SettingsAndBackup } from './components/SettingsAndBackup';
import { TransactionModal } from './components/TransactionModal';
import { AccountTransferModal } from './components/AccountTransferModal';
import { CommissionModal } from './components/CommissionModal';
import { PrintReceiptModal } from './components/PrintReceiptModal';
import { PinLockScreen } from './components/PinLockScreen';
import { AccountDetailView } from './components/AccountDetailView';
import { Store, Loader2 } from 'lucide-react';

function AppContent() {
  const { t, language } = useLanguage();
  const [loading, setLoading] = useState(true);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [settings, setSettings] = useState<ShopSettings | null>(null);

  // App Lock State
  const [isLocked, setIsLocked] = useState(false);

  // Navigation state
  const [activeTab, setActiveTab] = useState<TabType | 'settings'>('dashboard');
  const [selectedAccountId, setSelectedAccountId] = useState<AccountId | null>(null);

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [defaultTxType, setDefaultTxType] = useState<TransactionType>('IN');
  const [defaultCategory, setDefaultCategory] = useState<string | undefined>(undefined);
  const [modalAccountId, setModalAccountId] = useState<AccountId | undefined>(undefined);
  const [modalLockAccount, setModalLockAccount] = useState<boolean>(false);

  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [transferFromAcc, setTransferFromAcc] = useState<AccountId>('cash');

  const [isCommissionModalOpen, setIsCommissionModalOpen] = useState(false);
  const [commissionModalType, setCommissionModalType] = useState<CommissionServiceType>('send_money');
  const [commissionModalAccId, setCommissionModalAccId] = useState<AccountId>('easypaisa');

  const [printTx, setPrintTx] = useState<Transaction | null>(null);

  // Load all data from IndexedDB
  const refreshData = useCallback(async () => {
    try {
      // Purge any legacy hardcoded demo data and ensure 0 starting balances
      await cleanupLegacyDemoData();

      const [accs, txs, custs, supps, stgs] = await Promise.all([
        getAccounts(),
        getTransactions(),
        getCustomers(),
        getSuppliers(),
        getShopSettings(),
      ]);

      setAccounts(accs);
      setTransactions(txs);
      setCustomers(custs);
      setSuppliers(supps);
      setSettings(stgs);

      // Lock app if PIN is enabled
      if (stgs && stgs.pinEnabled && stgs.pinHash) {
        setIsLocked(true);
      }
    } catch (err) {
      console.error('Error loading data from IndexedDB:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  // Transaction Actions
  const handleSaveTransaction = async (tx: Transaction) => {
    await saveTransaction(tx);
    await refreshData();
  };

  const handleDeleteTransaction = async (id: string) => {
    await deleteTransaction(id);
    await refreshData();
  };

  const handleEditTransaction = (tx: Transaction) => {
    if (tx.serviceType) {
      setEditingTx(tx);
      setCommissionModalType(tx.serviceType);
      setCommissionModalAccId(tx.accountId);
      setIsCommissionModalOpen(true);
      return;
    }
    setEditingTx(tx);
    setModalAccountId(tx.accountId);
    setModalLockAccount(false);
    setIsAddModalOpen(true);
  };

  // Customer Actions
  const handleSaveCustomer = async (cust: Customer) => {
    await saveCustomer(cust);
    await refreshData();
  };

  const handleDeleteCustomer = async (id: string) => {
    await deleteCustomer(id);
    await refreshData();
  };

  // Supplier Actions
  const handleSaveSupplier = async (supp: Supplier) => {
    await saveSupplier(supp);
    await refreshData();
  };

  const handleDeleteSupplier = async (id: string) => {
    await deleteSupplier(id);
    await refreshData();
  };

  // Settings Actions
  const handleUpdateSettings = async (newSettings: ShopSettings) => {
    await saveShopSettings(newSettings);
    setSettings(newSettings);
  };

  // Open Add Modal with specific type, category, account, and lock state
  const handleOpenAddModal = (
    type: TransactionType = 'IN',
    category?: string,
    accountId?: AccountId,
    lockAccount: boolean = false
  ) => {
    setEditingTx(null);
    setDefaultTxType(type);
    setDefaultCategory(category);
    setModalAccountId(accountId);
    setModalLockAccount(lockAccount);
    setIsAddModalOpen(true);
  };

  const handleOpenTransferModal = (fromAcc: AccountId = 'cash') => {
    setTransferFromAcc(fromAcc);
    setIsTransferModalOpen(true);
  };

  const handleOpenCommissionModal = (
    serviceType: CommissionServiceType = 'send_money',
    accountId?: AccountId
  ) => {
    setCommissionModalType(serviceType);
    setCommissionModalAccId(accountId && accountId !== 'cash' ? accountId : 'easypaisa');
    setIsCommissionModalOpen(true);
  };

  // Loading Screen
  if (loading || !settings) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-6 text-white text-center">
        <div className="w-16 h-16 rounded-2xl bg-emerald-600/20 border-2 border-emerald-500 flex items-center justify-center mb-4">
          <Store className="w-8 h-8 text-emerald-400" />
        </div>
        <h1 className="text-xl font-bold tracking-tight">{t('appTitle')}</h1>
        <p className="text-sm text-emerald-400 font-medium mt-1">
          {settings?.shopName || t('shopDefaultName')}
        </p>
        <div className="flex items-center gap-2 mt-6 text-xs text-slate-400">
          <Loader2 className="w-4 h-4 animate-spin text-emerald-400" />
          <span>{language === 'ur' ? 'ڈیٹا لوڈ ہو رہا ہے...' : 'Loading local data...'}</span>
        </div>
      </div>
    );
  }

  // PIN Lock Screen
  if (isLocked) {
    return (
      <PinLockScreen
        settings={settings}
        onUnlock={() => setIsLocked(false)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col text-slate-900">
      {/* HEADER */}
      <Header
        settings={settings}
        onLockApp={() => setIsLocked(true)}
        onOpenSettings={() => setActiveTab('settings')}
      />

      {/* MAIN CONTENT AREA */}
      <main className="flex-1">
        {selectedAccountId ? (
          (() => {
            const currentAcc = accounts.find((a) => a.id === selectedAccountId);
            if (!currentAcc) return null;
            return (
              <AccountDetailView
                account={currentAcc}
                transactions={transactions}
                allAccounts={accounts}
                onBack={() => setSelectedAccountId(null)}
                onOpenAddModal={(type, accId) => handleOpenAddModal(type, undefined, accId, true)}
                onOpenTransferModal={(fromAcc) => handleOpenTransferModal(fromAcc)}
                onOpenCommissionModal={handleOpenCommissionModal}
                onSelectTransaction={handleEditTransaction}
                onPrintReceipt={(tx) => setPrintTx(tx)}
              />
            );
          })()
        ) : (
          <>
            {activeTab === 'dashboard' && (
              <Dashboard
                accounts={accounts}
                transactions={transactions}
                customers={customers}
                suppliers={suppliers}
                onOpenAddModal={handleOpenAddModal}
                onOpenTransferModal={handleOpenTransferModal}
                onOpenCommissionModal={handleOpenCommissionModal}
                onSelectTransaction={handleEditTransaction}
                onNavigateToTab={(tab) => {
                  setSelectedAccountId(null);
                  setActiveTab(tab);
                }}
                onSelectAccount={(accId) => setSelectedAccountId(accId)}
              />
            )}

            {activeTab === 'transactions' && (
              <TransactionList
                transactions={transactions}
                accounts={accounts}
                onOpenAddModal={handleOpenAddModal}
                onEditTransaction={handleEditTransaction}
                onDeleteTransaction={handleDeleteTransaction}
                onPrintReceipt={(tx) => setPrintTx(tx)}
              />
            )}

            {activeTab === 'khata' && (
              <KhataManager
                customers={customers}
                suppliers={suppliers}
                transactions={transactions}
                accounts={accounts}
                settings={settings}
                onSaveCustomer={handleSaveCustomer}
                onDeleteCustomer={handleDeleteCustomer}
                onSaveSupplier={handleSaveSupplier}
                onDeleteSupplier={handleDeleteSupplier}
                onAddTransaction={handleSaveTransaction}
              />
            )}

            {activeTab === 'reports' && (
              <div className="space-y-4">
                <div className="max-w-5xl mx-auto px-4 pt-3 flex items-center justify-between">
                  <div className="flex gap-2">
                    <button
                      onClick={() => setActiveTab('reports')}
                      className="px-3.5 py-1.5 bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs"
                    >
                      {t('navReports')}
                    </button>
                    <button
                      onClick={() => setActiveTab('settings')}
                      className="px-3.5 py-1.5 bg-white text-slate-700 hover:bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold"
                    >
                      {t('navSettings')}
                    </button>
                  </div>
                </div>
                <ReportsView
                  transactions={transactions}
                  accounts={accounts}
                  customers={customers}
                  suppliers={suppliers}
                  settings={settings}
                />
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="space-y-4">
                <div className="max-w-5xl mx-auto px-4 pt-3 flex items-center justify-between">
                  <div className="flex gap-2">
                    <button
                      onClick={() => setActiveTab('reports')}
                      className="px-3.5 py-1.5 bg-white text-slate-700 hover:bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold"
                    >
                      {t('navReports')}
                    </button>
                    <button
                      onClick={() => setActiveTab('settings')}
                      className="px-3.5 py-1.5 bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs"
                    >
                      {t('navSettings')}
                    </button>
                  </div>
                </div>
                <SettingsAndBackup
                  settings={settings}
                  accounts={accounts}
                  transactions={transactions}
                  customers={customers}
                  suppliers={suppliers}
                  onUpdateSettings={handleUpdateSettings}
                  onRefreshData={refreshData}
                  onLockAppNow={() => setIsLocked(true)}
                />
              </div>
            )}
          </>
        )}
      </main>

      {/* MOBILE BOTTOM NAVIGATION */}
      <BottomNav
        activeTab={activeTab === 'settings' ? 'reports' : activeTab}
        onTabChange={(tab) => {
          setSelectedAccountId(null);
          setActiveTab(tab);
        }}
        onOpenAddModal={() => handleOpenAddModal('IN')}
      />

      {/* MODALS */}
      <TransactionModal
        isOpen={isAddModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingTx(null);
          setModalAccountId(undefined);
          setModalLockAccount(false);
        }}
        onSave={handleSaveTransaction}
        editingTransaction={editingTx}
        accounts={accounts}
        customers={customers}
        suppliers={suppliers}
        defaultType={defaultTxType}
        defaultCategory={defaultCategory}
        defaultAccountId={modalAccountId}
        lockAccountId={modalLockAccount}
      />

      <AccountTransferModal
        isOpen={isTransferModalOpen}
        onClose={() => setIsTransferModalOpen(false)}
        accounts={accounts}
        onTransfer={handleSaveTransaction}
        initialFromAccount={transferFromAcc}
      />

      <CommissionModal
        isOpen={isCommissionModalOpen}
        onClose={() => {
          setIsCommissionModalOpen(false);
          setEditingTx(null);
        }}
        onSave={handleSaveTransaction}
        editingTransaction={editingTx?.serviceType ? editingTx : null}
        accounts={accounts}
        settings={settings}
        initialServiceType={commissionModalType}
        initialAccountId={commissionModalAccId}
      />

      <PrintReceiptModal
        isOpen={!!printTx}
        onClose={() => setPrintTx(null)}
        transaction={printTx}
        settings={settings}
      />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}
