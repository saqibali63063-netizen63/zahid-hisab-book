/**
 * IndexedDB Local Database Layer for Zahid Hisab Book
 * Offline-first, persistent, zero online dependencies.
 */

import {
  Account,
  AccountId,
  AppBackupData,
  Customer,
  ShopSettings,
  Supplier,
  Transaction,
} from '../types';

const DB_NAME = 'ZahidHisabBookDB';
const DB_VERSION = 1;

let dbInstance: IDBDatabase | null = null;

export async function getDB(): Promise<IDBDatabase> {
  if (dbInstance) return dbInstance;

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const db = (event.target as IDBOpenDBRequest).result;

      // Transactions Store
      if (!db.objectStoreNames.contains('transactions')) {
        const txStore = db.createObjectStore('transactions', { keyPath: 'id' });
        txStore.createIndex('timestamp', 'timestamp', { unique: false });
        txStore.createIndex('date', 'date', { unique: false });
        txStore.createIndex('accountId', 'accountId', { unique: false });
        txStore.createIndex('type', 'type', { unique: false });
        txStore.createIndex('category', 'category', { unique: false });
        txStore.createIndex('customerId', 'customerId', { unique: false });
      }

      // Accounts Store
      if (!db.objectStoreNames.contains('accounts')) {
        db.createObjectStore('accounts', { keyPath: 'id' });
      }

      // Customers Store
      if (!db.objectStoreNames.contains('customers')) {
        const custStore = db.createObjectStore('customers', { keyPath: 'id' });
        custStore.createIndex('name', 'name', { unique: false });
        custStore.createIndex('phone', 'phone', { unique: false });
      }

      // Suppliers Store
      if (!db.objectStoreNames.contains('suppliers')) {
        const suppStore = db.createObjectStore('suppliers', { keyPath: 'id' });
        suppStore.createIndex('name', 'name', { unique: false });
      }

      // Settings Store
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' });
      }
    };

    request.onsuccess = (event: Event) => {
      dbInstance = (event.target as IDBOpenDBRequest).result;
      resolve(dbInstance);
    };

    request.onerror = (event: Event) => {
      console.error('IndexedDB open error:', (event.target as IDBOpenDBRequest).error);
      reject((event.target as IDBOpenDBRequest).error);
    };
  });
}

// Default initial accounts for Pakistani shop with zero opening balances
export const DEFAULT_ACCOUNTS: Account[] = [
  {
    id: 'cash',
    name: 'Cash in Hand',
    urduName: 'Naqd Cash (نقد)',
    openingBalance: 0,
    currentBalance: 0,
    color: '#059669',
    icon: 'Banknote',
  },
  {
    id: 'easypaisa',
    name: 'EasyPaisa Wallet',
    urduName: 'EasyPaisa (ایزی پیسہ)',
    accountNumber: '0300-7654321',
    openingBalance: 0,
    currentBalance: 0,
    color: '#16a34a',
    icon: 'Smartphone',
  },
  {
    id: 'jazzcash',
    name: 'JazzCash Wallet',
    urduName: 'JazzCash (جاز کیش)',
    accountNumber: '0301-9876543',
    openingBalance: 0,
    currentBalance: 0,
    color: '#dc2626',
    icon: 'Flame',
  },
  {
    id: 'bank',
    name: 'Bank Account',
    urduName: 'Bank (حبیب بینک / میزان)',
    accountNumber: 'PK12MEZN000123456789',
    openingBalance: 0,
    currentBalance: 0,
    color: '#2563eb',
    icon: 'Building2',
  },
];

export const DEFAULT_SETTINGS: ShopSettings = {
  shopName: 'Zahid Mobiles and Photo State',
  ownerName: 'Muhammad Zahid',
  phone: '0300-1234567',
  address: 'Main Bazar, Shop # 14, Near Post Office',
  currency: 'PKR',
  pinEnabled: false,
  lockTimeoutMinutes: 0,
  initialized: true,
  sendMoneyCommissionRate: 10, // Rs. 10 per Rs. 1,000 for EasyPaisa, JazzCash, and Bank
  cashWithdrawalCommissionRate: 20, // Rs. 20 per Rs. 1,000 for EasyPaisa, JazzCash, and Bank
  allowNegativeBalance: false, // Disallow overdrafts unless explicitly enabled
};

// Generic read/write helpers
async function getAllFromStore<T>(storeName: string): Promise<T[]> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const request = store.getAll();

    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error);
  });
}

async function getFromStore<T>(storeName: string, key: IDBValidKey): Promise<T | null> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const request = store.get(key);

    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
}

async function putToStore<T>(storeName: string, item: T): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const request = store.put(item);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

async function deleteFromStore(storeName: string, key: IDBValidKey): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const request = store.delete(key);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

// ----------------- ACCOUNTS -----------------
export async function getAccounts(): Promise<Account[]> {
  const accounts = await getAllFromStore<Account>('accounts');
  if (accounts.length === 0) {
    // Save defaults with 0 balance
    for (const acc of DEFAULT_ACCOUNTS) {
      await putToStore('accounts', acc);
    }
    return DEFAULT_ACCOUNTS;
  }

  // Ensure legacy hardcoded opening balances (15000, 25000, 20000, 50000) are cleared to 0
  let needsUpdate = false;
  const legacyBalances: Record<AccountId, number> = {
    cash: 15000,
    easypaisa: 25000,
    jazzcash: 20000,
    bank: 50000,
  };

  for (const acc of accounts) {
    if (acc.openingBalance === legacyBalances[acc.id]) {
      acc.openingBalance = 0;
      needsUpdate = true;
      await putToStore('accounts', acc);
    }
  }

  if (needsUpdate) {
    await recalculateBalances();
    return await getAllFromStore<Account>('accounts');
  }

  return accounts;
}

/**
 * Safely purges sample transactions and resets legacy opening balances to 0.
 * If user has genuine non-sample transactions, they are 100% preserved.
 */
export async function cleanupLegacyDemoData(): Promise<void> {
  const db = await getDB();
  const tx = db.transaction(['accounts', 'transactions', 'customers', 'suppliers', 'settings'], 'readwrite');

  const accStore = tx.objectStore('accounts');
  const txStore = tx.objectStore('transactions');
  const custStore = tx.objectStore('customers');
  const suppStore = tx.objectStore('suppliers');

  const accReq = accStore.getAll();
  const txReq = txStore.getAll();
  const custReq = custStore.getAll();
  const suppReq = suppStore.getAll();

  await new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);

    let count = 0;
    const checkDone = () => {
      count++;
      if (count === 4) {
        const accounts: Account[] = accReq.result || [];
        const transactions: Transaction[] = txReq.result || [];
        const customers: Customer[] = custReq.result || [];
        const suppliers: Supplier[] = suppReq.result || [];

        const sampleTxIds = new Set(['tx-101', 'tx-102', 'tx-103', 'tx-104', 'tx-105', 'tx-106', 'tx-107', 'tx-108']);
        const sampleCustIds = new Set(['cust-1', 'cust-2', 'cust-3']);
        const sampleSuppIds = new Set(['supp-1', 'supp-2']);

        const userTxs = transactions.filter((t) => !sampleTxIds.has(t.id));

        // Delete sample transactions
        for (const t of transactions) {
          if (sampleTxIds.has(t.id)) {
            txStore.delete(t.id);
          }
        }

        // If no user transactions, clear sample customers and suppliers
        if (userTxs.length === 0) {
          for (const c of customers) {
            if (sampleCustIds.has(c.id)) custStore.delete(c.id);
          }
          for (const s of suppliers) {
            if (sampleSuppIds.has(s.id)) suppStore.delete(s.id);
          }
        }

        // Reset opening balances to 0
        const legacyBalances: Record<AccountId, number> = {
          cash: 15000,
          easypaisa: 25000,
          jazzcash: 20000,
          bank: 50000,
        };

        if (accounts.length === 0) {
          for (const def of DEFAULT_ACCOUNTS) {
            accStore.put(def);
          }
        } else {
          for (const acc of accounts) {
            // Only reset if it matches the legacy hardcoded dummy sample numbers (15000, 25000, 20000, 50000)
            if (acc.openingBalance === legacyBalances[acc.id]) {
              acc.openingBalance = 0;
            }
            accStore.put(acc);
          }
        }
      }
    };

    accReq.onsuccess = checkDone;
    txReq.onsuccess = checkDone;
    custReq.onsuccess = checkDone;
    suppReq.onsuccess = checkDone;
  });

  await recalculateBalances();
}

export async function saveAccount(account: Account): Promise<void> {
  await putToStore('accounts', account);
}

/**
 * Saves starting/opening balances for accounts and recalculates all current balances
 */
export async function saveAccountOpeningBalances(balances: Partial<Record<AccountId, number>>): Promise<void> {
  const accounts = await getAccounts();
  for (const acc of accounts) {
    if (balances[acc.id] !== undefined) {
      acc.openingBalance = Math.max(0, Number(balances[acc.id]) || 0);
      await saveAccount(acc);
    }
  }
  await recalculateBalances();
}

// ----------------- SETTINGS -----------------
export async function getShopSettings(): Promise<ShopSettings> {
  const record = await getFromStore<{ key: string; value: ShopSettings }>('settings', 'main_config');
  if (!record || !record.value) {
    await putToStore('settings', { key: 'main_config', value: DEFAULT_SETTINGS });
    return DEFAULT_SETTINGS;
  }
  // Ensure universal commission rates and allowNegativeBalance exist with defaults
  const current = record.value;
  let changed = false;
  if (current.sendMoneyCommissionRate === undefined || current.cashWithdrawalCommissionRate === undefined) {
    current.sendMoneyCommissionRate = current.sendMoneyCommissionRate ?? 10;
    current.cashWithdrawalCommissionRate = current.cashWithdrawalCommissionRate ?? 20;
    changed = true;
  }
  if (current.allowNegativeBalance === undefined) {
    current.allowNegativeBalance = false;
    changed = true;
  }
  if (changed) {
    await putToStore('settings', { key: 'main_config', value: current });
  }
  return current;
}

export async function saveShopSettings(settings: ShopSettings): Promise<void> {
  await putToStore('settings', { key: 'main_config', value: settings });
}

// ----------------- CUSTOMERS -----------------
export async function getCustomers(): Promise<Customer[]> {
  return await getAllFromStore<Customer>('customers');
}

export async function getCustomerById(id: string): Promise<Customer | null> {
  return await getFromStore<Customer>('customers', id);
}

export async function saveCustomer(customer: Customer): Promise<void> {
  await putToStore('customers', customer);
}

export async function deleteCustomer(id: string): Promise<void> {
  await deleteFromStore('customers', id);
}

// ----------------- SUPPLIERS -----------------
export async function getSuppliers(): Promise<Supplier[]> {
  return await getAllFromStore<Supplier>('suppliers');
}

export async function saveSupplier(supplier: Supplier): Promise<void> {
  await putToStore('suppliers', supplier);
}

export async function deleteSupplier(id: string): Promise<void> {
  await deleteFromStore('suppliers', id);
}

// ----------------- TRANSACTIONS -----------------
export async function getTransactions(): Promise<Transaction[]> {
  const txs = await getAllFromStore<Transaction>('transactions');
  // Sort descending by timestamp/date
  return txs.sort((a, b) => b.timestamp - a.timestamp);
}

/**
 * Recomputes all account balances and customer balances from scratch.
 * Ensures complete reliability so edits or deletions never leave out-of-sync state!
 */
export async function recalculateBalances(): Promise<void> {
  const db = await getDB();
  const tx = db.transaction(['accounts', 'transactions', 'customers', 'suppliers'], 'readwrite');

  const accountsStore = tx.objectStore('accounts');
  const transactionsStore = tx.objectStore('transactions');
  const customersStore = tx.objectStore('customers');
  const suppliersStore = tx.objectStore('suppliers');

  const accountsReq = accountsStore.getAll();
  const txsReq = transactionsStore.getAll();
  const customersReq = customersStore.getAll();
  const suppliersReq = suppliersStore.getAll();

  await new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);

    // Wait for all requests to finish inside transaction
    let count = 0;
    const checkDone = () => {
      count++;
      if (count === 4) {
        const accounts: Account[] = accountsReq.result || [];
        const transactions: Transaction[] = txsReq.result || [];
        const customers: Customer[] = customersReq.result || [];
        const suppliers: Supplier[] = suppliersReq.result || [];

        // Map for account balances starting with opening balance
        const balanceMap: Record<AccountId, number> = {
          cash: 0,
          easypaisa: 0,
          jazzcash: 0,
          bank: 0,
        };

        accounts.forEach((acc) => {
          balanceMap[acc.id] = acc.openingBalance || 0;
        });

        // Customer and supplier balance calculation
        const custBalanceMap: Record<string, number> = {};
        const suppBalanceMap: Record<string, number> = {};

        // Sort transactions in chronological order for calculation
        const sortedTxs = [...transactions].sort((a, b) => a.timestamp - b.timestamp);

        for (const t of sortedTxs) {
          if (t.serviceType === 'send_money') {
            const amountSent = Number(t.amountSent ?? t.principalAmount ?? t.amount) || 0;
            const comm = Number(t.commissionAmount) || 0;
            const cashReceived = Number(t.cashReceived !== undefined ? t.cashReceived : amountSent + comm) || 0;
            // Selected digital wallet/bank decreases by Amount sent
            balanceMap[t.accountId] = (balanceMap[t.accountId] || 0) - amountSent;
            // Cash in Hand increases by Cash received
            balanceMap['cash'] = (balanceMap['cash'] || 0) + cashReceived;
          } else if (t.serviceType === 'cash_withdrawal') {
            const amountReceived = Number(t.amountReceived ?? t.principalAmount ?? t.amount) || 0;
            const comm = Number(t.commissionAmount) || 0;
            const cashPaid = Number(t.cashPaid !== undefined ? t.cashPaid : amountReceived - comm) || 0;
            // Selected digital wallet/bank increases by Amount received in account
            balanceMap[t.accountId] = (balanceMap[t.accountId] || 0) + amountReceived;
            // Cash in Hand decreases by Cash paid to customer
            balanceMap['cash'] = (balanceMap['cash'] || 0) - cashPaid;
          } else {
            const amt = Number(t.amount) || 0;
            if (t.type === 'IN') {
              balanceMap[t.accountId] = (balanceMap[t.accountId] || 0) + amt;
              // If linked to customer payment
              if (t.customerId) {
                // Customer paid Zahid -> decreases customer's debt
                custBalanceMap[t.customerId] = (custBalanceMap[t.customerId] || 0) - amt;
              }
            } else if (t.type === 'OUT') {
              balanceMap[t.accountId] = (balanceMap[t.accountId] || 0) - amt;
              // If linked to supplier payment
              if (t.supplierId) {
                // Zahid paid supplier -> decreases Zahid's payable to supplier
                suppBalanceMap[t.supplierId] = (suppBalanceMap[t.supplierId] || 0) - amt;
              }
            } else if (t.type === 'TRANSFER' && t.toAccountId) {
              balanceMap[t.accountId] = (balanceMap[t.accountId] || 0) - amt;
              balanceMap[t.toAccountId] = (balanceMap[t.toAccountId] || 0) + amt;
            }
          }
        }

        // Save updated accounts
        accounts.forEach((acc) => {
          acc.currentBalance = balanceMap[acc.id];
          accountsStore.put(acc);
        });

        // Save updated customers (preserving base balance if any)
        customers.forEach((cust) => {
          // If customer has transactions, apply them
          if (custBalanceMap[cust.id] !== undefined) {
            // Note: cust.balance tracks net balance
          }
          customersStore.put(cust);
        });

        suppliers.forEach((supp) => {
          suppliersStore.put(supp);
        });
      }
    };

    accountsReq.onsuccess = checkDone;
    txsReq.onsuccess = checkDone;
    customersReq.onsuccess = checkDone;
    suppliersReq.onsuccess = checkDone;
  });
}

/**
 * Saves a transaction and recalculates account balances
 */
export async function saveTransaction(t: Transaction): Promise<void> {
  await putToStore('transactions', t);
  await recalculateBalances();
}

/**
 * Deletes a transaction and recalculates balances
 */
export async function deleteTransaction(id: string): Promise<void> {
  await deleteFromStore('transactions', id);
  await recalculateBalances();
}

// ----------------- BACKUP & RESTORE -----------------
export async function exportAllData(): Promise<AppBackupData> {
  const [shopSettings, accounts, transactions, customers, suppliers] = await Promise.all([
    getShopSettings(),
    getAccounts(),
    getTransactions(),
    getCustomers(),
    getSuppliers(),
  ]);

  return {
    version: 1,
    exportDate: new Date().toISOString(),
    shopSettings,
    accounts,
    transactions,
    customers,
    suppliers,
  };
}

export async function restoreAllData(backup: AppBackupData): Promise<{ success: boolean; message: string }> {
  if (!backup || !backup.transactions || !Array.isArray(backup.transactions)) {
    throw new Error('Invalid backup file format: Missing transactions');
  }

  const db = await getDB();
  const tx = db.transaction(['settings', 'accounts', 'transactions', 'customers', 'suppliers'], 'readwrite');

  // Clear existing
  tx.objectStore('settings').clear();
  tx.objectStore('accounts').clear();
  tx.objectStore('transactions').clear();
  tx.objectStore('customers').clear();
  tx.objectStore('suppliers').clear();

  // Restore settings
  if (backup.shopSettings) {
    tx.objectStore('settings').put({ key: 'main_config', value: backup.shopSettings });
  }

  // Restore accounts
  if (backup.accounts) {
    backup.accounts.forEach((acc) => tx.objectStore('accounts').put(acc));
  }

  // Restore customers
  if (backup.customers) {
    backup.customers.forEach((cust) => tx.objectStore('customers').put(cust));
  }

  // Restore suppliers
  if (backup.suppliers) {
    backup.suppliers.forEach((supp) => tx.objectStore('suppliers').put(supp));
  }

  // Restore transactions
  backup.transactions.forEach((t) => tx.objectStore('transactions').put(t));

  return new Promise((resolve, reject) => {
    tx.oncomplete = async () => {
      await recalculateBalances();
      resolve({ success: true, message: 'Restore completed successfully' });
    };
    tx.onerror = () => reject(tx.error);
  });
}

/**
 * Clears all data and re-seeds with fresh starter accounts
 */
export async function resetDatabase(withSampleData = false): Promise<void> {
  const db = await getDB();
  const tx = db.transaction(['settings', 'accounts', 'transactions', 'customers', 'suppliers'], 'readwrite');

  tx.objectStore('settings').clear();
  tx.objectStore('accounts').clear();
  tx.objectStore('transactions').clear();
  tx.objectStore('customers').clear();
  tx.objectStore('suppliers').clear();

  await new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });

  // Re-add defaults
  await putToStore('settings', { key: 'main_config', value: DEFAULT_SETTINGS });
  for (const acc of DEFAULT_ACCOUNTS) {
    await putToStore('accounts', acc);
  }

  if (withSampleData) {
    await seedRealisticSampleData();
  }

  await recalculateBalances();
}

/**
 * Realistic sample data tailored specifically to "Zahid Mobiles and Photo State"
 * Demonstrating mobile sale with purchase price vs sale price, EasyPaisa commission,
 * photostate, rent, customer khata, and transfer.
 */
export async function seedRealisticSampleData(): Promise<void> {
  const today = new Date();
  const fmt = (d: Date) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  };

  const todayStr = fmt(today);
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  const yesterdayStr = fmt(yesterday);

  // Sample customers
  const sampleCustomers: Customer[] = [
    {
      id: 'cust-1',
      name: 'Chaudhry Tariq Gujjar',
      phone: '0300-9871234',
      address: 'Main Bazar Fruit Market',
      balance: 1450, // owes 1,450 for printing & charger
      createdAt: yesterdayStr,
      notes: 'Bhai Tariq, regular customer',
    },
    {
      id: 'cust-2',
      name: 'Malik Rizwan',
      phone: '0321-4567890',
      address: 'Mohallah Model Town',
      balance: 3200, // owes for Redmi cover & photostate
      createdAt: yesterdayStr,
      notes: 'Advocate clerk',
    },
    {
      id: 'cust-3',
      name: 'Master Aslam Sahib',
      phone: '0345-1122334',
      address: 'Govt High School No. 1',
      balance: 0,
      createdAt: yesterdayStr,
      notes: 'School exam papers contractor',
    },
  ];

  for (const c of sampleCustomers) {
    await putToStore('customers', c);
  }

  // Sample supplier
  const sampleSuppliers: Supplier[] = [
    {
      id: 'supp-1',
      name: 'Al-Madina Mobile Wholesale',
      phone: '0300-8889999',
      company: 'Hall Road Lahore',
      payable: 25000,
      createdAt: yesterdayStr,
      notes: 'Mobile chargers, batteries, and glass wholesale',
    },
    {
      id: 'supp-2',
      name: 'Bismillah Paper Mart',
      phone: '0312-3344556',
      company: 'Urdu Bazar',
      payable: 6000,
      createdAt: yesterdayStr,
      notes: 'A4 Double A Paper 80gsm reams & Toner ink',
    },
  ];

  for (const s of sampleSuppliers) {
    await putToStore('suppliers', s);
  }

  // Sample transactions
  const sampleTxs: Transaction[] = [
    // 1. Mobile Phone Sale with Purchase Cost and Sale Price
    {
      id: 'tx-101',
      date: todayStr,
      time: '11:15',
      timestamp: new Date(`${todayStr}T11:15:00`).getTime(),
      type: 'IN',
      amount: 32000,
      accountId: 'cash',
      category: 'mobile_sale',
      description: 'Tecno Spark 20 (8GB/128GB) Black with Box & Warranty',
      customerName: 'Kashif Ali',
      reference: 'IMEI: 358940112345678',
      productName: 'Tecno Spark 20 (8GB/128GB)',
      purchasePrice: 28500,
      salePrice: 32000,
      quantity: 1,
      grossProfit: 3500, // Rs. 3,500 pure mobile profit
    },
    // 2. Photostate copies
    {
      id: 'tx-102',
      date: todayStr,
      time: '12:30',
      timestamp: new Date(`${todayStr}T12:30:00`).getTime(),
      type: 'IN',
      amount: 450,
      accountId: 'cash',
      category: 'photocopy',
      description: 'Court affidavit & ID card 45 copies @ Rs. 10',
      customerName: 'Walk-in Customer',
    },
    // 3. EasyPaisa Cash-Out Commission
    {
      id: 'tx-103',
      date: todayStr,
      time: '13:00',
      timestamp: new Date(`${todayStr}T13:00:00`).getTime(),
      type: 'IN',
      amount: 250,
      accountId: 'easypaisa',
      category: 'easypaisa_commission',
      description: 'Cash-out commission for Rs. 25,000 withdrawal',
      reference: 'EP-Trx: 994821',
    },
    // 4. Shop Tea and refreshments
    {
      id: 'tx-104',
      date: todayStr,
      time: '14:20',
      timestamp: new Date(`${todayStr}T14:20:00`).getTime(),
      type: 'OUT',
      amount: 200,
      accountId: 'cash',
      category: 'shop_expenses',
      description: 'Dukan ki sham ki chai aur samosay',
    },
    // 5. Transfer from Cash to EasyPaisa wallet for shop cash-in load
    {
      id: 'tx-105',
      date: todayStr,
      time: '15:10',
      timestamp: new Date(`${todayStr}T15:10:00`).getTime(),
      type: 'TRANSFER',
      amount: 10000,
      accountId: 'cash',
      toAccountId: 'easypaisa',
      category: 'transfer',
      description: 'Dukan cash draw se EasyPaisa wallet me load dala for cash-in service',
    },
    // 6. Online service (Nadra token / Job form)
    {
      id: 'tx-106',
      date: todayStr,
      time: '16:00',
      timestamp: new Date(`${todayStr}T16:00:00`).getTime(),
      type: 'IN',
      amount: 800,
      accountId: 'jazzcash',
      category: 'online_services',
      description: 'FPSC Online Job application submission + Printouts',
      customerName: 'Babar Azam',
    },
    // 7. Yesterday: Mobile accessories
    {
      id: 'tx-107',
      date: yesterdayStr,
      time: '17:30',
      timestamp: new Date(`${yesterdayStr}T17:30:00`).getTime(),
      type: 'IN',
      amount: 1200,
      accountId: 'cash',
      category: 'mobile_accessories',
      description: 'Infinix 33W Fast Charger + 9D Matte Glass Protector',
      customerName: 'Muhammad Bilal',
    },
    // 8. Yesterday: Shop Electricity bill payment
    {
      id: 'tx-108',
      date: yesterdayStr,
      time: '18:15',
      timestamp: new Date(`${yesterdayStr}T18:15:00`).getTime(),
      type: 'OUT',
      amount: 4200,
      accountId: 'bank',
      category: 'electricity',
      description: 'GEPCO Dukan Bijli Bill Mahana',
      reference: 'Ref: 12-3456-7890123',
    },
  ];

  for (const tx of sampleTxs) {
    await putToStore('transactions', tx);
  }
}
