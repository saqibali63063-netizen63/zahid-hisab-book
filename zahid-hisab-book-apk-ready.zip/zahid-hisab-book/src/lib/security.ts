/**
 * Security helpers for Zahid Hisab Book
 * Stores hashed PIN using Web Crypto SHA-256 with salt.
 * Plain text PIN is NEVER persisted.
 */

export async function hashPin(pin: string, salt?: string): Promise<{ hash: string; salt: string }> {
  const chosenSalt = salt || generateSalt();
  const encoder = new TextEncoder();
  const data = encoder.encode(pin + ':' + chosenSalt);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
  return { hash: hashHex, salt: chosenSalt };
}

export async function verifyPin(pin: string, storedHash: string, storedSalt: string): Promise<boolean> {
  if (!pin || !storedHash || !storedSalt) return false;
  const { hash } = await hashPin(pin, storedSalt);
  return hash === storedHash;
}

function generateSalt(): string {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, (byte) => byte.toString(16).padStart(2, '0')).join('');
}
