/**
 * Formatters and Constants for Zahid Hisab Book
 * Language-aware formatting for 100% pure English and 100% pure Urdu.
 */

import { CategoryDef, CategoryId, AccountId } from '../types';
import { Language, TRANSLATIONS } from './translations';

export const ACCOUNT_DEFINITIONS: {
  id: AccountId;
  nameEn: string;
  nameUr: string;
  badgeEn: string;
  badgeUr: string;
  color: string;
  bgLight: string;
  borderColor: string;
  icon: string;
}[] = [
  {
    id: 'cash',
    nameEn: 'Cash in Hand',
    nameUr: 'نقد رقم',
    badgeEn: 'Cash',
    badgeUr: 'نقد',
    color: '#059669',
    bgLight: 'bg-emerald-50',
    borderColor: 'border-emerald-200',
    icon: 'Banknote',
  },
  {
    id: 'easypaisa',
    nameEn: 'EasyPaisa Wallet',
    nameUr: 'ایزی پیسہ والیٹ',
    badgeEn: 'EasyPaisa',
    badgeUr: 'ایزی پیسہ',
    color: '#16a34a',
    bgLight: 'bg-green-50',
    borderColor: 'border-green-200',
    icon: 'Smartphone',
  },
  {
    id: 'jazzcash',
    nameEn: 'JazzCash Wallet',
    nameUr: 'جاز کیش والیٹ',
    badgeEn: 'JazzCash',
    badgeUr: 'جاز کیش',
    color: '#dc2626',
    bgLight: 'bg-red-50',
    borderColor: 'border-red-200',
    icon: 'Flame',
  },
  {
    id: 'bank',
    nameEn: 'Bank Account',
    nameUr: 'بینک اکاؤنٹ',
    badgeEn: 'Bank',
    badgeUr: 'بینک',
    color: '#2563eb',
    bgLight: 'bg-blue-50',
    borderColor: 'border-blue-200',
    icon: 'Building2',
  },
];

export function getAccountName(accountId: AccountId, lang: Language = 'en'): string {
  const acc = ACCOUNT_DEFINITIONS.find((a) => a.id === accountId);
  if (!acc) return accountId;
  return lang === 'ur' ? acc.nameUr : acc.nameEn;
}

export function getAccountBadge(accountId: AccountId, lang: Language = 'en'): string {
  const acc = ACCOUNT_DEFINITIONS.find((a) => a.id === accountId);
  if (!acc) return accountId;
  return lang === 'ur' ? acc.badgeUr : acc.badgeEn;
}

export const CATEGORIES: CategoryDef[] = [
  // INCOMES & SERVICES
  {
    id: 'mobile_sale',
    label: 'Mobile Phone Sales',
    urduLabel: 'موبائل فون فروخت',
    type: 'IN',
    affectsProfit: true,
    iconName: 'Smartphone',
  },
  {
    id: 'mobile_accessories',
    label: 'Mobile Accessories',
    urduLabel: 'موبائل سامان',
    type: 'IN',
    affectsProfit: true,
    iconName: 'Headphones',
  },
  {
    id: 'photocopy',
    label: 'Photocopy',
    urduLabel: 'فوٹو کاپی',
    type: 'IN',
    affectsProfit: true,
    iconName: 'Copy',
  },
  {
    id: 'printing',
    label: 'Printing Services',
    urduLabel: 'پرنٹنگ سروس',
    type: 'IN',
    affectsProfit: true,
    iconName: 'Printer',
  },
  {
    id: 'online_services',
    label: 'Online Services',
    urduLabel: 'آن لائن سروسز',
    type: 'IN',
    affectsProfit: true,
    iconName: 'Globe',
  },
  {
    id: 'easypaisa_commission',
    label: 'EasyPaisa Commission',
    urduLabel: 'ایزی پیسہ کمیشن',
    type: 'IN',
    affectsProfit: true,
    iconName: 'Percent',
  },
  {
    id: 'jazzcash_commission',
    label: 'JazzCash Commission',
    urduLabel: 'جاز کیش کمیشن',
    type: 'IN',
    affectsProfit: true,
    iconName: 'Percent',
  },
  {
    id: 'bank_commission',
    label: 'Bank Commission',
    urduLabel: 'بینک کمیشن',
    type: 'IN',
    affectsProfit: true,
    iconName: 'Percent',
  },
  {
    id: 'print_photocopy',
    label: 'Print & Photocopy',
    urduLabel: 'پرنٹ و فوٹو کاپی',
    type: 'IN',
    affectsProfit: true,
    iconName: 'Printer',
  },
  {
    id: 'send_money',
    label: 'Send Money',
    urduLabel: 'رقم بھیجیں',
    type: 'IN',
    affectsProfit: true,
    iconName: 'Send',
  },
  {
    id: 'easypaisa_send_money',
    label: 'EasyPaisa Send Money',
    urduLabel: 'ایزی پیسہ رقم بھیجی',
    type: 'IN',
    affectsProfit: true,
    iconName: 'Send',
  },
  {
    id: 'jazzcash_send_money',
    label: 'JazzCash Send Money',
    urduLabel: 'جاز کیش رقم بھیجی',
    type: 'IN',
    affectsProfit: true,
    iconName: 'Send',
  },
  {
    id: 'bank_send_money',
    label: 'Bank Send Money',
    urduLabel: 'بینک رقم بھیجی',
    type: 'IN',
    affectsProfit: true,
    iconName: 'Send',
  },
  {
    id: 'cash_withdrawal',
    label: 'Cash Withdrawal',
    urduLabel: 'کیش نکلوانا',
    type: 'IN',
    affectsProfit: true,
    iconName: 'ArrowDownToLine',
  },
  {
    id: 'easypaisa_withdrawal',
    label: 'EasyPaisa Withdrawal',
    urduLabel: 'ایزی پیسہ کیش نکلوانا',
    type: 'IN',
    affectsProfit: true,
    iconName: 'ArrowDownToLine',
  },
  {
    id: 'jazzcash_withdrawal',
    label: 'JazzCash Withdrawal',
    urduLabel: 'جاز کیش کیش نکلوانا',
    type: 'IN',
    affectsProfit: true,
    iconName: 'ArrowDownToLine',
  },
  {
    id: 'bank_withdrawal',
    label: 'Bank Withdrawal',
    urduLabel: 'بینک کیش نکلوانا',
    type: 'IN',
    affectsProfit: true,
    iconName: 'ArrowDownToLine',
  },
  {
    id: 'customer_payment',
    label: 'Customer Debt Collection',
    urduLabel: 'گاہک سے ادھار وصولی',
    type: 'IN',
    affectsProfit: false,
    iconName: 'UserCheck',
  },
  {
    id: 'other_income',
    label: 'Other Income / Repairs',
    urduLabel: 'دیگر آمدنی / مرمت',
    type: 'IN',
    affectsProfit: true,
    iconName: 'Coins',
  },

  // EXPENSES
  {
    id: 'shop_expenses',
    label: 'Daily Shop Expenses',
    urduLabel: 'دکان کے روزمرہ اخراجات',
    type: 'OUT',
    affectsProfit: true,
    iconName: 'Coffee',
  },
  {
    id: 'electricity',
    label: 'Electricity Bill',
    urduLabel: 'بجلی کا بل',
    type: 'OUT',
    affectsProfit: true,
    iconName: 'Zap',
  },
  {
    id: 'rent',
    label: 'Shop Rent',
    urduLabel: 'دکان کا کرایہ',
    type: 'OUT',
    affectsProfit: true,
    iconName: 'Home',
  },
  {
    id: 'paper_toner',
    label: 'Paper & Toner Ink',
    urduLabel: 'کاغذ و انک',
    type: 'OUT',
    affectsProfit: true,
    iconName: 'Layers',
  },
  {
    id: 'supplier_payment',
    label: 'Supplier Payment',
    urduLabel: 'سپلائر کو ادائیگی',
    type: 'OUT',
    affectsProfit: false,
    iconName: 'Truck',
  },
  {
    id: 'other_expenses',
    label: 'Other Expenses',
    urduLabel: 'دیگر اخراجات',
    type: 'OUT',
    affectsProfit: true,
    iconName: 'Receipt',
  },

  // TRANSFER
  {
    id: 'transfer',
    label: 'Account Transfer',
    urduLabel: 'کھاتہ منتقلی',
    type: 'TRANSFER',
    affectsProfit: false,
    iconName: 'ArrowLeftRight',
  },
];

export function getCategoryDef(categoryId: string): CategoryDef {
  const found = CATEGORIES.find((c) => c.id === categoryId);
  if (found) return found;
  return {
    id: categoryId as CategoryId,
    label: categoryId.replace(/_/g, ' '),
    urduLabel: categoryId.replace(/_/g, ' '),
    type: 'IN',
    affectsProfit: true,
    iconName: 'Tag',
  };
}

export function getCategoryLabel(categoryId: string, lang: Language = 'en', accountId?: AccountId): string {
  if (categoryId === 'send_money' && accountId) {
    if (accountId === 'easypaisa') return lang === 'ur' ? 'ایزی پیسہ رقم بھیجی' : 'EasyPaisa Send Money';
    if (accountId === 'jazzcash') return lang === 'ur' ? 'جاز کیش رقم بھیجی' : 'JazzCash Send Money';
    if (accountId === 'bank') return lang === 'ur' ? 'بینک رقم بھیجی' : 'Bank Send Money';
  }
  if (categoryId === 'cash_withdrawal' && accountId) {
    if (accountId === 'easypaisa') return lang === 'ur' ? 'ایزی پیسہ کیش نکلوانا' : 'EasyPaisa Withdrawal';
    if (accountId === 'jazzcash') return lang === 'ur' ? 'جاز کیش کیش نکلوانا' : 'JazzCash Withdrawal';
    if (accountId === 'bank') return lang === 'ur' ? 'بینک کیش نکلوانا' : 'Bank Withdrawal';
  }
  const def = getCategoryDef(categoryId);
  return lang === 'ur' ? def.urduLabel : def.label;
}

export function formatPKR(amount: number | null | undefined, lang: Language = 'en'): string {
  if (amount === null || amount === undefined || isNaN(amount)) {
    return lang === 'ur' ? '0 روپے' : 'Rs. 0';
  }
  const isNegative = amount < 0;
  const absFormatted = Math.abs(Math.round(amount)).toLocaleString('en-PK');
  if (lang === 'ur') {
    return `${isNegative ? '-' : ''}${absFormatted} روپے`;
  }
  return `${isNegative ? '-' : ''}Rs. ${absFormatted}`;
}

export function formatPKRWithSign(amount: number, lang: Language = 'en'): string {
  const formatted = Math.abs(Math.round(amount)).toLocaleString('en-PK');
  if (amount > 0) {
    return lang === 'ur' ? `+${formatted} روپے` : `+Rs. ${formatted}`;
  }
  if (amount < 0) {
    return lang === 'ur' ? `-${formatted} روپے` : `-Rs. ${formatted}`;
  }
  return lang === 'ur' ? '0 روپے' : 'Rs. 0';
}

export function formatDate(dateStr: string, lang: Language = 'en'): string {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-');
  if (!year || !month || !day) return dateStr;

  const enMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const urMonths = ['جنوری', 'فروری', 'مارچ', 'اپریل', 'مئی', 'جون', 'جولائی', 'اگست', 'ستمبر', 'اکتوبر', 'نومبر', 'دسمبر'];

  const mIndex = parseInt(month, 10) - 1;
  const dayNum = parseInt(day, 10);

  if (lang === 'ur') {
    return `${dayNum} ${urMonths[mIndex] || month} ${year}`;
  }
  return `${dayNum} ${enMonths[mIndex] || month}, ${year}`;
}

export function formatTime(timeStr: string, lang: Language = 'en'): string {
  if (!timeStr) return '';
  const [hourStr, minStr] = timeStr.split(':');
  let hour = parseInt(hourStr, 10);
  const min = minStr || '00';
  const isPM = hour >= 12;
  hour = hour % 12 || 12;

  if (lang === 'ur') {
    const period = isPM ? 'شام' : 'صبح';
    return `${hour}:${min} ${period}`;
  }
  return `${hour}:${min} ${isPM ? 'PM' : 'AM'}`;
}

export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getCurrentTimeString(): string {
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  return `${hours}:${minutes}`;
}

export function generateWhatsAppReminderMessage(
  customerName: string,
  balance: number,
  shopName: string = 'Zahid Mobiles and Photo State',
  phone: string = '0300-1234567',
  lang: Language = 'en'
): string {
  const formattedBalance = Math.abs(Math.round(balance)).toLocaleString('en-PK');

  if (lang === 'ur') {
    return (
      `محترم ${customerName} صاحب،\n` +
      `السلام علیکم!\n\n` +
      `یہ پیغام "${shopName}" کی طرف سے ہے۔ آپ کا کل واجب الادا بقایا حساب:\n` +
      `👉 ${formattedBalance} روپے ہے\n\n` +
      `براہ کرم سہولت کے مطابق ادائیگی فرما دیں۔ اگر آپ ادا کر چکے ہیں تو مطلع فرما دیں۔\n` +
      `شکریہ!\n` +
      `دکان: ${shopName}\n` +
      `رابطہ: ${phone}`
    );
  }

  return (
    `Respected ${customerName},\n` +
    `Greetings!\n\n` +
    `This is a reminder from "${shopName}". Your current outstanding ledger balance is:\n` +
    `👉 Rs. ${formattedBalance}\n\n` +
    `Please clear this payment at your earliest convenience. If you have already paid, please let us know.\n` +
    `Thank you!\n` +
    `Shop: ${shopName}\n` +
    `Contact: ${phone}`
  );
}

/**
 * Calculates proportional commission for Send Money or Cash Withdrawal.
 * Universal rate applies to EasyPaisa, JazzCash, and Bank Account:
 * - Send Money: default Rs. 10 per Rs. 1,000
 * - Cash Withdrawal: default Rs. 20 per Rs. 1,000
 * Examples:
 * - Rs. 1,000 Send = Rs. 10
 * - Rs. 5,000 Send = Rs. 50
 * - Rs. 1,000 Withdrawal = Rs. 20
 * - Rs. 5,000 Withdrawal = Rs. 100
 */
export function calculateCommission(
  principal: number,
  serviceType: 'send_money' | 'cash_withdrawal',
  rates?: { sendMoneyCommissionRate?: number; cashWithdrawalCommissionRate?: number }
): number {
  if (!principal || principal <= 0) return 0;
  const ratePerThousand = serviceType === 'send_money'
    ? (rates?.sendMoneyCommissionRate ?? 10)
    : (rates?.cashWithdrawalCommissionRate ?? 20);

  return Math.round((principal / 1000) * ratePerThousand);
}
