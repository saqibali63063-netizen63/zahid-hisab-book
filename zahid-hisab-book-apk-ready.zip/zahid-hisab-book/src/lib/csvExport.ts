/**
 * CSV Export utility for Zahid Hisab Book
 */

import { Customer, Transaction } from '../types';
import { getCategoryDef } from './formatters';

export function exportTransactionsToCSV(transactions: Transaction[], filename: string = 'zahid_mobiles_transactions.csv'): void {
  const headers = [
    'Transaction ID',
    'Date',
    'Time',
    'Type',
    'Account',
    'Destination Account (if Transfer)',
    'Category',
    'Category Urdu',
    'Amount (PKR)',
    'Description',
    'Customer / Party',
    'Supplier',
    'Reference / Slip No',
    'Product Name',
    'Purchase Price',
    'Sale Price',
    'Quantity',
    'Gross Profit',
  ];

  const rows = transactions.map((t) => {
    const cat = getCategoryDef(t.category);
    return [
      escapeCSV(t.id),
      escapeCSV(t.date),
      escapeCSV(t.time),
      escapeCSV(t.type),
      escapeCSV(t.accountId),
      escapeCSV(t.toAccountId || ''),
      escapeCSV(cat.label),
      escapeCSV(cat.urduLabel),
      t.amount,
      escapeCSV(t.description),
      escapeCSV(t.customerName || ''),
      escapeCSV(t.supplierName || ''),
      escapeCSV(t.reference || ''),
      escapeCSV(t.productName || ''),
      t.purchasePrice || '',
      t.salePrice || '',
      t.quantity || '',
      t.grossProfit || '',
    ];
  });

  const csvContent = [headers.join(','), ...rows.map((row) => row.join(','))].join('\n');
  downloadBlob(csvContent, filename, 'text/csv;charset=utf-8;');
}

export function exportCustomersToCSV(customers: Customer[], filename: string = 'zahid_customer_khata.csv'): void {
  const headers = ['Customer ID', 'Customer Name', 'Phone Number', 'Address', 'Balance Owed (PKR)', 'Created Date', 'Notes'];

  const rows = customers.map((c) => [
    escapeCSV(c.id),
    escapeCSV(c.name),
    escapeCSV(c.phone),
    escapeCSV(c.address || ''),
    c.balance,
    escapeCSV(c.createdAt),
    escapeCSV(c.notes || ''),
  ]);

  const csvContent = [headers.join(','), ...rows.map((row) => row.join(','))].join('\n');
  downloadBlob(csvContent, filename, 'text/csv;charset=utf-8;');
}

function escapeCSV(val: string): string {
  if (val === null || val === undefined) return '""';
  const str = String(val).replace(/"/g, '""');
  return `"${str}"`;
}

function downloadBlob(content: string, filename: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
