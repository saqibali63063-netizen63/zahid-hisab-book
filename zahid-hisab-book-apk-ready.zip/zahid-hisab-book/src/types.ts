/**
 * Types for Zahid Hisab Book - Zahid Mobiles and Photo State
 */

export type AccountId = 'cash' | 'easypaisa' | 'jazzcash' | 'bank';

export type TransactionType = 'IN' | 'OUT' | 'TRANSFER';

export type CommissionServiceType = 'send_money' | 'cash_withdrawal';

export interface Account {
  id: AccountId;
  name: string;
  urduName: string;
  accountNumber?: string;
  openingBalance: number;
  currentBalance: number;
  color: string;
  icon: string;
}

export type CategoryId =
  | 'mobile_sale'
  | 'mobile_accessories'
  | 'printing'
  | 'photocopy'
  | 'print_photocopy'
  | 'online_services'
  | 'easypaisa_commission'
  | 'jazzcash_commission'
  | 'bank_commission'
  | 'send_money'
  | 'cash_withdrawal'
  | 'easypaisa_send_money'
  | 'jazzcash_send_money'
  | 'bank_send_money'
  | 'easypaisa_withdrawal'
  | 'jazzcash_withdrawal'
  | 'bank_withdrawal'
  | 'customer_payment'
  | 'other_income'
  | 'shop_expenses'
  | 'electricity'
  | 'rent'
  | 'paper_toner'
  | 'supplier_payment'
  | 'other_expenses'
  | 'transfer';

export interface CategoryDef {
  id: CategoryId;
  label: string;
  urduLabel: string;
  type: TransactionType;
  affectsProfit: boolean;
  iconName: string;
}

export interface Transaction {
  id: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  timestamp: number; // Unix timestamp in ms
  type: TransactionType;
  amount: number; // PKR: For regular txs = amount, for commission txs = principal amount
  accountId: AccountId;
  toAccountId?: AccountId; // Required when type === 'TRANSFER'
  category: CategoryId | string;
  description: string;
  customerName?: string;
  customerPhone?: string; // Change 1: Phone number sent to / received from
  customerId?: string;
  supplierName?: string;
  supplierId?: string;
  reference?: string; // Slip #, receipt #, or IMEI

  // Mobile sales & Itemized inventory fields for Profit & Loss
  productName?: string;
  purchasePrice?: number;
  salePrice?: number;
  quantity?: number;
  grossProfit?: number;

  // Accounting flag:
  isCreditSettlement?: boolean;

  // Digital Wallet & Bank Commission Service fields
  serviceType?: CommissionServiceType;
  principalAmount?: number;
  amountSent?: number; // Send Money: Amount sent to customer (wallet decreases)
  cashReceived?: number; // Send Money: Cash received from customer (cash increases)
  amountReceived?: number; // Cash Withdrawal: Amount received in account (wallet increases)
  cashPaid?: number; // Cash Withdrawal: Cash paid to customer (cash decreases)
  commissionAmount?: number;
  commissionRatePerThousand?: number;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  address?: string;
  balance: number; // Positive = Customer owes Zahid (Udhar / Receivable), Negative = Advance
  createdAt: string;
  notes?: string;
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  company?: string;
  payable: number; // Positive = Zahid owes supplier (Dena / Payable)
  createdAt: string;
  notes?: string;
}

export interface ShopSettings {
  shopName: string;
  ownerName: string;
  phone: string;
  address: string;
  currency: string;
  pinEnabled: boolean;
  pinHash?: string;
  pinSalt?: string;
  lockTimeoutMinutes: number;
  securityQuestion?: string;
  securityAnswerHash?: string;
  initialized: boolean;

  // Universal Commission Rates (per Rs. 1,000) for EasyPaisa, JazzCash, and Bank Account
  sendMoneyCommissionRate: number; // Default: Rs. 10 per Rs. 1,000
  cashWithdrawalCommissionRate: number; // Default: Rs. 20 per Rs. 1,000

  // Feature 5: Overdraft / Negative balance setting
  allowNegativeBalance?: boolean; // Default: false (prevents balance from dropping below 0)
}

export interface AppBackupData {
  version: number;
  exportDate: string;
  shopSettings: ShopSettings;
  accounts: Account[];
  transactions: Transaction[];
  customers: Customer[];
  suppliers: Supplier[];
}
