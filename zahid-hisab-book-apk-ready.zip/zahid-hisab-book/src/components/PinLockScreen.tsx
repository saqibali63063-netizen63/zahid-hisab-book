import React, { useState } from 'react';
import { Lock, Delete, Store, AlertCircle, ShieldCheck } from 'lucide-react';
import { verifyPin } from '../lib/security';
import { ShopSettings } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface PinLockScreenProps {
  settings: ShopSettings;
  onUnlock: () => void;
}

export const PinLockScreen: React.FC<PinLockScreenProps> = ({ settings, onUnlock }) => {
  const { t, language } = useLanguage();
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleKeyPress = async (num: string) => {
    if (pin.length >= 4) return;
    const newPin = pin + num;
    setPin(newPin);
    setError(false);
    setErrorMessage('');

    if (newPin.length === 4) {
      if (settings.pinHash && settings.pinSalt) {
        const isValid = await verifyPin(newPin, settings.pinHash, settings.pinSalt);
        if (isValid) {
          onUnlock();
        } else {
          setError(true);
          setErrorMessage(t('incorrectPinMsg'));
          setTimeout(() => {
            setPin('');
            setError(false);
          }, 800);
        }
      } else {
        // Fallback if not configured
        onUnlock();
      }
    }
  };

  const handleDelete = () => {
    setPin((prev) => prev.slice(0, -1));
    setError(false);
  };

  const handleClear = () => {
    setPin('');
    setError(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900 text-white flex flex-col justify-between items-center p-6 select-none" dir="ltr">
      {/* Top Shop branding */}
      <div className="w-full max-w-xs text-center pt-8">
        <div className="w-16 h-16 bg-emerald-600/30 border-2 border-emerald-500 rounded-2xl mx-auto flex items-center justify-center mb-3 shadow-lg">
          <Store className="w-8 h-8 text-emerald-400" />
        </div>
        <h2 className="text-xl font-bold tracking-tight text-white">
          {settings.shopName || t('shopDefaultName')}
        </h2>
        <p className="text-sm text-emerald-400 font-medium mt-1">
          {t('appTitle')}
        </p>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-800 rounded-full text-xs text-slate-300 border border-slate-700 mt-3">
          <Lock className="w-3.5 h-3.5 text-amber-400" />
          <span>{t('enterPinPrompt')}</span>
        </div>
      </div>

      {/* PIN Dots Display */}
      <div className="w-full max-w-xs flex flex-col items-center my-auto">
        <div className="flex items-center gap-5 my-4">
          {[0, 1, 2, 3].map((index) => {
            const isFilled = pin.length > index;
            return (
              <div
                key={index}
                className={`w-4 h-4 rounded-full transition-all duration-200 ${
                  error
                    ? 'bg-red-500 scale-110 animate-bounce'
                    : isFilled
                    ? 'bg-emerald-400 scale-125 shadow-md shadow-emerald-500/50'
                    : 'bg-slate-700 border border-slate-600'
                }`}
              />
            );
          })}
        </div>

        {errorMessage && (
          <div className="flex items-center gap-1.5 text-red-400 text-xs font-semibold mt-2 animate-pulse">
            <AlertCircle className="w-4 h-4" />
            <span>{errorMessage}</span>
          </div>
        )}
      </div>

      {/* Keypad */}
      <div className="w-full max-w-xs pb-6">
        <div className="grid grid-cols-3 gap-3">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
            <button
              key={num}
              onClick={() => handleKeyPress(String(num))}
              className="h-16 rounded-2xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 active:scale-95 text-2xl font-semibold flex items-center justify-center transition-all shadow-sm"
            >
              {num}
            </button>
          ))}
          <button
            onClick={handleClear}
            className="h-16 rounded-2xl bg-slate-800/40 hover:bg-slate-800 border border-slate-800 active:scale-95 text-xs font-medium text-slate-400 flex items-center justify-center"
          >
            {t('clearBtn')}
          </button>
          <button
            onClick={() => handleKeyPress('0')}
            className="h-16 rounded-2xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 active:scale-95 text-2xl font-semibold flex items-center justify-center transition-all shadow-sm"
          >
            0
          </button>
          <button
            onClick={handleDelete}
            className="h-16 rounded-2xl bg-slate-800/40 hover:bg-slate-800 border border-slate-800 active:scale-95 text-slate-300 flex items-center justify-center"
            title="Delete"
          >
            <Delete className="w-6 h-6" />
          </button>
        </div>

        <div className="text-center mt-6">
          <p className="text-[11px] text-slate-500 flex items-center justify-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>{t('offlineStatus')}</span>
          </p>
        </div>
      </div>
    </div>
  );
};
