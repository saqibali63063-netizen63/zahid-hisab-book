import React, { useState, useMemo } from 'react';
import {
  BarChart3,
  Calendar,
  Printer,
  FileSpreadsheet,
  TrendingUp,
  TrendingDown,
  Sparkles,
  PieChart,
  ShieldCheck,
  CheckCircle2,
  DollarSign,
  Smartphone,
  Info,
  Percent,
  Send,
  ArrowDownToLine,
  Building2,
  Flame,
} from 'lucide-react';
import { Account, Customer, ShopSettings, Supplier, Transaction } from '../types';
import {
  formatDate,
  formatPKR,
  getAccountName,
  getCategoryDef,
  getCategoryLabel,
  getTodayDateString,
} from '../lib/formatters';
import { exportTransactionsToCSV } from '../lib/csvExport';
import { useLanguage } from '../context/LanguageContext';

interface ReportsViewProps {
  transactions: Transaction[];
  accounts: Account[];
  customers: Customer[];
  suppliers: Supplier[];
  settings: ShopSettings;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  transactions,
  accounts,
  customers,
  suppliers,
  settings,
}) => {
  const { t, language } = useLanguage();
  const [rangeType, setRangeType] = useState<'TODAY' | 'WEEK' | 'MONTH' | 'ALL' | 'CUSTOM'>('TODAY');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');

  const todayStr = getTodayDateString();

  // Helper date calculators
  const sevenDaysAgo = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() - 7);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }, []);

  const monthStart = useMemo(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`;
  }, []);

  // Filtered transactions for the report
  const filteredTxs = useMemo(() => {
    return transactions.filter((tItem) => {
      if (rangeType === 'TODAY') return tItem.date === todayStr;
      if (rangeType === 'WEEK') return tItem.date >= sevenDaysAgo && tItem.date <= todayStr;
      if (rangeType === 'MONTH') return tItem.date >= monthStart && tItem.date <= todayStr;
      if (rangeType === 'CUSTOM') {
        if (customStart && tItem.date < customStart) return false;
        if (customEnd && tItem.date > customEnd) return false;
        return true;
      }
      return true; // ALL
    });
  }, [transactions, rangeType, todayStr, sevenDaysAgo, monthStart, customStart, customEnd]);

  // DAILY COMMISSION BREAKDOWN (for todayStr)
  const dailyCommissions = useMemo(() => {
    let easypaisaSend = 0;
    let easypaisaWithdraw = 0;
    let easypaisaOther = 0;

    let jazzcashSend = 0;
    let jazzcashWithdraw = 0;
    let jazzcashOther = 0;

    let bankSend = 0;
    let bankWithdraw = 0;
    let bankOther = 0;

    transactions
      .filter((tItem) => tItem.date === todayStr)
      .forEach((tItem) => {
        const comm = tItem.serviceType
          ? Number(tItem.commissionAmount) || 0
          : tItem.category.includes('commission')
          ? Number(tItem.amount) || 0
          : 0;

        if (comm <= 0) return;

        if (tItem.accountId === 'easypaisa' || tItem.category === 'easypaisa_commission') {
          if (tItem.serviceType === 'send_money') easypaisaSend += comm;
          else if (tItem.serviceType === 'cash_withdrawal') easypaisaWithdraw += comm;
          else easypaisaOther += comm;
        } else if (tItem.accountId === 'jazzcash' || tItem.category === 'jazzcash_commission') {
          if (tItem.serviceType === 'send_money') jazzcashSend += comm;
          else if (tItem.serviceType === 'cash_withdrawal') jazzcashWithdraw += comm;
          else jazzcashOther += comm;
        } else if (tItem.accountId === 'bank' || tItem.category === 'bank_commission') {
          if (tItem.serviceType === 'send_money') bankSend += comm;
          else if (tItem.serviceType === 'cash_withdrawal') bankWithdraw += comm;
          else bankOther += comm;
        }
      });

    const easypaisaTotal = easypaisaSend + easypaisaWithdraw + easypaisaOther;
    const jazzcashTotal = jazzcashSend + jazzcashWithdraw + jazzcashOther;
    const bankTotal = bankSend + bankWithdraw + bankOther;

    return {
      easypaisa: { send: easypaisaSend, withdraw: easypaisaWithdraw, total: easypaisaTotal },
      jazzcash: { send: jazzcashSend, withdraw: jazzcashWithdraw, total: jazzcashTotal },
      bank: { send: bankSend, withdraw: bankWithdraw, total: bankTotal },
      totalSend: easypaisaSend + jazzcashSend + bankSend,
      totalWithdraw: easypaisaWithdraw + jazzcashWithdraw + bankWithdraw,
      combined: easypaisaTotal + jazzcashTotal + bankTotal,
    };
  }, [transactions, todayStr]);

  // MONTHLY COMMISSION BREAKDOWN (for monthStart to todayStr)
  const monthlyCommissions = useMemo(() => {
    let easypaisaSend = 0;
    let easypaisaWithdraw = 0;
    let easypaisaOther = 0;

    let jazzcashSend = 0;
    let jazzcashWithdraw = 0;
    let jazzcashOther = 0;

    let bankSend = 0;
    let bankWithdraw = 0;
    let bankOther = 0;

    transactions
      .filter((tItem) => tItem.date >= monthStart && tItem.date <= todayStr)
      .forEach((tItem) => {
        const comm = tItem.serviceType
          ? Number(tItem.commissionAmount) || 0
          : tItem.category.includes('commission')
          ? Number(tItem.amount) || 0
          : 0;

        if (comm <= 0) return;

        if (tItem.accountId === 'easypaisa' || tItem.category === 'easypaisa_commission') {
          if (tItem.serviceType === 'send_money') easypaisaSend += comm;
          else if (tItem.serviceType === 'cash_withdrawal') easypaisaWithdraw += comm;
          else easypaisaOther += comm;
        } else if (tItem.accountId === 'jazzcash' || tItem.category === 'jazzcash_commission') {
          if (tItem.serviceType === 'send_money') jazzcashSend += comm;
          else if (tItem.serviceType === 'cash_withdrawal') jazzcashWithdraw += comm;
          else jazzcashOther += comm;
        } else if (tItem.accountId === 'bank' || tItem.category === 'bank_commission') {
          if (tItem.serviceType === 'send_money') bankSend += comm;
          else if (tItem.serviceType === 'cash_withdrawal') bankWithdraw += comm;
          else bankOther += comm;
        }
      });

    const easypaisaTotal = easypaisaSend + easypaisaWithdraw + easypaisaOther;
    const jazzcashTotal = jazzcashSend + jazzcashWithdraw + jazzcashOther;
    const bankTotal = bankSend + bankWithdraw + bankOther;

    return {
      easypaisa: { send: easypaisaSend, withdraw: easypaisaWithdraw, total: easypaisaTotal },
      jazzcash: { send: jazzcashSend, withdraw: jazzcashWithdraw, total: jazzcashTotal },
      bank: { send: bankSend, withdraw: bankWithdraw, total: bankTotal },
      totalSend: easypaisaSend + jazzcashSend + bankSend,
      totalWithdraw: easypaisaWithdraw + jazzcashWithdraw + bankWithdraw,
      combined: easypaisaTotal + jazzcashTotal + bankTotal,
    };
  }, [transactions, monthStart, todayStr]);

  // PERIOD COMMISSION BREAKDOWN (for current selected filter)
  const periodCommissions = useMemo(() => {
    let easypaisaSend = 0;
    let easypaisaWithdraw = 0;
    let easypaisaOther = 0;

    let jazzcashSend = 0;
    let jazzcashWithdraw = 0;
    let jazzcashOther = 0;

    let bankSend = 0;
    let bankWithdraw = 0;
    let bankOther = 0;

    filteredTxs.forEach((tItem) => {
      const comm = tItem.serviceType
        ? Number(tItem.commissionAmount) || 0
        : tItem.category.includes('commission')
        ? Number(tItem.amount) || 0
        : 0;

      if (comm <= 0) return;

      if (tItem.accountId === 'easypaisa' || tItem.category === 'easypaisa_commission') {
        if (tItem.serviceType === 'send_money') easypaisaSend += comm;
        else if (tItem.serviceType === 'cash_withdrawal') easypaisaWithdraw += comm;
        else easypaisaOther += comm;
      } else if (tItem.accountId === 'jazzcash' || tItem.category === 'jazzcash_commission') {
        if (tItem.serviceType === 'send_money') jazzcashSend += comm;
        else if (tItem.serviceType === 'cash_withdrawal') jazzcashWithdraw += comm;
        else jazzcashOther += comm;
      } else if (tItem.accountId === 'bank' || tItem.category === 'bank_commission') {
        if (tItem.serviceType === 'send_money') bankSend += comm;
        else if (tItem.serviceType === 'cash_withdrawal') bankWithdraw += comm;
        else bankOther += comm;
      }
    });

    const easypaisaTotal = easypaisaSend + easypaisaWithdraw + easypaisaOther;
    const jazzcashTotal = jazzcashSend + jazzcashWithdraw + jazzcashOther;
    const bankTotal = bankSend + bankWithdraw + bankOther;

    return {
      easypaisa: { send: easypaisaSend, withdraw: easypaisaWithdraw, total: easypaisaTotal },
      jazzcash: { send: jazzcashSend, withdraw: jazzcashWithdraw, total: jazzcashTotal },
      bank: { send: bankSend, withdraw: bankWithdraw, total: bankTotal },
      totalSend: easypaisaSend + jazzcashSend + bankSend,
      totalWithdraw: easypaisaWithdraw + jazzcashWithdraw + bankWithdraw,
      combined: easypaisaTotal + jazzcashTotal + bankTotal,
    };
  }, [filteredTxs]);

  // Core P&L Calculation:
  // 1. Mobile Sales Revenue & Mobile COGS (Purchase cost)
  // 2. Services Revenue (Photocopy, Printing, Online services, Accessories)
  // 3. Digital Commissions (EasyPaisa, JazzCash, Bank Account) -> ONLY commission is profit!
  // 4. Operating Expenses (Rent, Electricity, Tea, Paper, Misc)
  // 5. Pure Net Profit = (Mobile Margin) + Services + Commissions - Operating Expenses
  const pnl = useMemo(() => {
    let mobileSalesRevenue = 0;
    let mobileCostOfGoods = 0;
    let serviceRevenue = 0;
    let commissionsEarned = 0;
    let customerDebtCollected = 0;
    let totalInflow = 0;

    let operatingExpenses = 0;
    let supplierPaid = 0;
    let totalOutflow = 0;

    const categoryBreakdown: Record<string, { catId: string; amount: number; count: number; type: string }> = {};

    filteredTxs.forEach((tItem) => {
      const cat = tItem.category;

      if (!categoryBreakdown[cat]) {
        categoryBreakdown[cat] = {
          catId: cat,
          amount: 0,
          count: 0,
          type: tItem.type,
        };
      }

      if (tItem.serviceType) {
        // Send Money or Cash Withdrawal: ONLY commission counts as shop income/profit!
        const comm = Number(tItem.commissionAmount) || 0;
        commissionsEarned += comm;
        totalInflow += comm;
        categoryBreakdown[cat].amount += comm;
        categoryBreakdown[cat].count += 1;
      } else {
        const amt = Number(tItem.amount) || 0;
        categoryBreakdown[cat].amount += amt;
        categoryBreakdown[cat].count += 1;

        if (tItem.type === 'IN') {
          totalInflow += amt;
          if (cat === 'mobile_sale') {
            mobileSalesRevenue += amt;
            const cost = Number(tItem.purchasePrice) || 0;
            const qty = Number(tItem.quantity) || 1;
            mobileCostOfGoods += cost * qty;
          } else if (cat === 'easypaisa_commission' || cat === 'jazzcash_commission' || cat === 'bank_commission') {
            commissionsEarned += amt;
          } else if (cat === 'customer_payment') {
            customerDebtCollected += amt;
          } else {
            serviceRevenue += amt;
          }
        } else if (tItem.type === 'OUT') {
          totalOutflow += amt;
          if (cat === 'supplier_payment') {
            supplierPaid += amt;
          } else {
            operatingExpenses += amt;
          }
        }
      }
    });

    const mobileGrossProfit = mobileSalesRevenue - mobileCostOfGoods;
    const grossProfit = mobileGrossProfit + serviceRevenue + commissionsEarned;
    const netPureProfit = grossProfit - operatingExpenses;

    return {
      mobileSalesRevenue,
      mobileCostOfGoods,
      mobileGrossProfit,
      serviceRevenue,
      commissionsEarned,
      customerDebtCollected,
      totalInflow,
      operatingExpenses,
      supplierPaid,
      totalOutflow,
      grossProfit,
      netPureProfit,
      categoryBreakdown: Object.values(categoryBreakdown).sort((a, b) => b.amount - a.amount),
    };
  }, [filteredTxs]);

  // Account-wise movement for the period
  const accountStats = useMemo(() => {
    const stats: Record<string, { in: number; out: number; balance: number }> = {};
    accounts.forEach((acc) => {
      stats[acc.id] = { in: 0, out: 0, balance: acc.currentBalance };
    });

    filteredTxs.forEach((tItem) => {
      if (tItem.serviceType === 'send_money') {
        const principal = Number(tItem.principalAmount || tItem.amount) || 0;
        const comm = Number(tItem.commissionAmount) || 0;
        if (stats[tItem.accountId]) stats[tItem.accountId].out += principal;
        if (stats['cash']) stats['cash'].in += (principal + comm);
      } else if (tItem.serviceType === 'cash_withdrawal') {
        const principal = Number(tItem.principalAmount || tItem.amount) || 0;
        const comm = Number(tItem.commissionAmount) || 0;
        if (stats[tItem.accountId]) stats[tItem.accountId].in += principal;
        if (stats['cash']) stats['cash'].out += (principal - comm);
      } else {
        const amt = Number(tItem.amount) || 0;
        if (tItem.type === 'IN' && stats[tItem.accountId]) {
          stats[tItem.accountId].in += amt;
        } else if (tItem.type === 'OUT' && stats[tItem.accountId]) {
          stats[tItem.accountId].out += amt;
        } else if (tItem.type === 'TRANSFER' && tItem.toAccountId) {
          if (stats[tItem.accountId]) stats[tItem.accountId].out += amt;
          if (stats[tItem.toAccountId]) stats[tItem.toAccountId].in += amt;
        }
      }
    });

    return stats;
  }, [accounts, filteredTxs]);

  const totalReceivables = customers.reduce((sum, c) => sum + Math.max(0, c.balance || 0), 0);
  const totalPayables = suppliers.reduce((sum, s) => sum + Math.max(0, s.payable || 0), 0);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-4 pb-20 pt-2 px-3 sm:px-4 max-w-5xl mx-auto">
      {/* HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <span>{t('reportsTitle')}</span>
          </h2>
          <p className="text-xs text-slate-500">
            {t('reportsSubtitle')}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => exportTransactionsToCSV(filteredTxs, `zahid_hisab_report_${rangeType.toLowerCase()}.csv`)}
            className="flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 shadow-xs"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>{t('csvExportBtn')}</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold shadow-md active:scale-95 transition-all"
          >
            <Printer className="w-4 h-4 text-emerald-400" />
            <span>{t('printPdfBtn')}</span>
          </button>
        </div>
      </div>

      {/* DATE RANGE FILTER TABS */}
      <div className="bg-white p-2 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-1.5 overflow-x-auto text-xs">
        {(
          [
            { id: 'TODAY', label: t('today') },
            { id: 'WEEK', label: t('thisWeek') },
            { id: 'MONTH', label: t('thisMonth') },
            { id: 'ALL', label: t('all') },
            { id: 'CUSTOM', label: t('customRange') },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            onClick={() => setRangeType(tab.id)}
            className={`px-3 py-2 rounded-xl font-bold whitespace-nowrap transition-colors ${
              rangeType === tab.id
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {rangeType === 'CUSTOM' && (
        <div className="grid grid-cols-2 gap-2 p-3 bg-white rounded-2xl border border-slate-200 text-xs">
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
              {t('from')} ({t('date')})
            </label>
            <input
              type="date"
              value={customStart}
              onChange={(e) => setCustomStart(e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-lg text-xs"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
              {t('to')} ({t('date')})
            </label>
            <input
              type="date"
              value={customEnd}
              onChange={(e) => setCustomEnd(e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-lg text-xs"
            />
          </div>
        </div>
      )}

      {/* 1. SEPARATE & COMBINED COMMISSIONS REPORT CARD (DAILY & MONTHLY) */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden p-4 sm:p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Percent className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-slate-800">
                {rangeType === 'TODAY'
                  ? t('dailyCommissionSummary')
                  : rangeType === 'MONTH'
                  ? t('monthlyCommissionSummary')
                  : `${t('commission')} (${rangeType})`}
              </h3>
              <p className="text-[11px] text-slate-500">
                {t('universalCommissionDesc')}
              </p>
            </div>
          </div>

          <div className="bg-emerald-50 border border-emerald-200 px-3.5 py-1.5 rounded-2xl flex items-center gap-2">
            <span className="text-xs font-bold text-emerald-900">
              {rangeType === 'TODAY' ? t('todayTotalCommission') : rangeType === 'MONTH' ? t('monthlyTotalCommission') : t('combinedCommission')}:
            </span>
            <span className="text-base sm:text-lg font-black text-emerald-700 font-mono">
              +{formatPKR(periodCommissions.combined, language)}
            </span>
          </div>
        </div>

        {/* Service Type Split (Send Money vs Cash Withdrawal) */}
        <div className="grid grid-cols-2 gap-2.5">
          <div className="p-3 bg-emerald-50/80 rounded-2xl border border-emerald-200 flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-950">
              <Send className="w-4 h-4 text-emerald-700" />
              <span>{rangeType === 'TODAY' ? t('todaySendCommission') : t('monthlySendCommission')}</span>
            </div>
            <span className="font-black text-sm text-emerald-800 font-mono">
              +{formatPKR(periodCommissions.totalSend, language)}
            </span>
          </div>

          <div className="p-3 bg-blue-50/80 rounded-2xl border border-blue-200 flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-bold text-blue-950">
              <ArrowDownToLine className="w-4 h-4 text-blue-700" />
              <span>{rangeType === 'TODAY' ? t('todayWithdrawCommission') : t('monthlyWithdrawCommission')}</span>
            </div>
            <span className="font-black text-sm text-blue-800 font-mono">
              +{formatPKR(periodCommissions.totalWithdraw, language)}
            </span>
          </div>
        </div>

        {/* 3 Accounts Breakdown: EasyPaisa, JazzCash, Bank */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* EasyPaisa */}
          <div className="p-3.5 rounded-2xl border border-green-200 bg-gradient-to-b from-green-50/80 to-white space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-green-700" />
                <span className="font-bold text-xs text-green-950">EasyPaisa</span>
              </div>
              <span className="text-sm font-black text-green-800 font-mono">
                +{formatPKR(periodCommissions.easypaisa.total, language)}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-1 text-[11px] pt-1.5 border-t border-green-200/80">
              <div className="text-slate-600">
                <span>{t('sendMoney')}:</span>
                <div className="font-semibold text-green-800 font-mono">+{formatPKR(periodCommissions.easypaisa.send, language)}</div>
              </div>
              <div className="text-slate-600">
                <span>{t('cashWithdrawal')}:</span>
                <div className="font-semibold text-green-800 font-mono">+{formatPKR(periodCommissions.easypaisa.withdraw, language)}</div>
              </div>
            </div>
          </div>

          {/* JazzCash */}
          <div className="p-3.5 rounded-2xl border border-red-200 bg-gradient-to-b from-red-50/80 to-white space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Flame className="w-4 h-4 text-red-700" />
                <span className="font-bold text-xs text-red-950">JazzCash</span>
              </div>
              <span className="text-sm font-black text-red-800 font-mono">
                +{formatPKR(periodCommissions.jazzcash.total, language)}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-1 text-[11px] pt-1.5 border-t border-red-200/80">
              <div className="text-slate-600">
                <span>{t('sendMoney')}:</span>
                <div className="font-semibold text-red-800 font-mono">+{formatPKR(periodCommissions.jazzcash.send, language)}</div>
              </div>
              <div className="text-slate-600">
                <span>{t('cashWithdrawal')}:</span>
                <div className="font-semibold text-red-800 font-mono">+{formatPKR(periodCommissions.jazzcash.withdraw, language)}</div>
              </div>
            </div>
          </div>

          {/* Bank Account */}
          <div className="p-3.5 rounded-2xl border border-blue-200 bg-gradient-to-b from-blue-50/80 to-white space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-blue-700" />
                <span className="font-bold text-xs text-blue-950">Bank Account</span>
              </div>
              <span className="text-sm font-black text-blue-800 font-mono">
                +{formatPKR(periodCommissions.bank.total, language)}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-1 text-[11px] pt-1.5 border-t border-blue-200/80">
              <div className="text-slate-600">
                <span>{t('sendMoney')}:</span>
                <div className="font-semibold text-blue-800 font-mono">+{formatPKR(periodCommissions.bank.send, language)}</div>
              </div>
              <div className="text-slate-600">
                <span>{t('cashWithdrawal')}:</span>
                <div className="font-semibold text-blue-800 font-mono">+{formatPKR(periodCommissions.bank.withdraw, language)}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Comparison of Daily vs Monthly (when viewing periods) */}
        {rangeType !== 'TODAY' && (
          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="flex justify-between items-center p-2 bg-white rounded-xl border border-slate-200">
              <div>
                <span className="font-bold text-slate-800">{t('combinedDailyCommission')} (Today):</span>
                <p className="text-[10px] text-slate-400">EasyPaisa + JazzCash + Bank</p>
              </div>
              <span className="font-black text-emerald-700 font-mono text-sm">
                +{formatPKR(dailyCommissions.combined, language)}
              </span>
            </div>

            <div className="flex justify-between items-center p-2 bg-white rounded-xl border border-slate-200">
              <div>
                <span className="font-bold text-slate-800">{t('combinedMonthlyCommission')} (This Month):</span>
                <p className="text-[10px] text-slate-400">EasyPaisa + JazzCash + Bank</p>
              </div>
              <span className="font-black text-emerald-700 font-mono text-sm">
                +{formatPKR(monthlyCommissions.combined, language)}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* 2. PROFIT & LOSS STATEMENT CARD */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 to-slate-800 text-white flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <h3 className="font-bold text-base sm:text-lg">
                {t('pnlTitle')}
              </h3>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              {settings.shopName || t('shopDefaultName')}
            </p>
          </div>

          <div className="text-right">
            <div className="text-[10px] text-slate-300 uppercase font-semibold">
              {t('netProfitLabel')}
            </div>
            <div
              className={`text-xl sm:text-2xl font-black ${
                pnl.netPureProfit >= 0 ? 'text-amber-300' : 'text-rose-400'
              }`}
            >
              {formatPKR(pnl.netPureProfit, language)}
            </div>
          </div>
        </div>

        {/* Detailed Accounting Breakdown */}
        <div className="p-5 space-y-4">
          <div className="space-y-2 text-xs">
            {/* 1. Mobile Phone Sales Section */}
            <div className="p-3 bg-amber-50/70 border border-amber-200/80 rounded-2xl space-y-1.5">
              <div className="flex justify-between font-bold text-amber-950 text-sm">
                <span className="flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4 text-amber-600" />
                  <span>{t('mobileSalesHeading')}</span>
                </span>
                <span>+{formatPKR(pnl.mobileSalesRevenue, language)}</span>
              </div>
              <div className="flex justify-between text-slate-600 text-xs pl-6">
                <span>{t('costOfGoodsHeading')}</span>
                <span className="text-rose-600 font-semibold">
                  -{formatPKR(pnl.mobileCostOfGoods, language)}
                </span>
              </div>
              <div className="pt-1 border-t border-amber-200/60 flex justify-between font-bold text-amber-900 text-xs pl-6">
                <span>{t('mobileGrossProfitHeading')}</span>
                <span className="text-emerald-700">+{formatPKR(pnl.mobileGrossProfit, language)}</span>
              </div>
            </div>

            {/* 2. Shop Services & Commission */}
            <div className="p-3 bg-emerald-50/70 border border-emerald-200/80 rounded-2xl space-y-1.5">
              <div className="flex justify-between text-slate-700 font-semibold">
                <span>{t('servicesCommissionsHeading')}</span>
                <span className="text-emerald-700 font-bold">
                  +{formatPKR(pnl.serviceRevenue, language)}
                </span>
              </div>
              <div className="flex justify-between text-slate-700 font-semibold">
                <span>EasyPaisa, JazzCash & Bank Commissions (Net Profit):</span>
                <span className="text-emerald-700 font-bold">
                  +{formatPKR(pnl.commissionsEarned, language)}
                </span>
              </div>
              <div className="pt-1 border-t border-emerald-200/60 flex justify-between font-bold text-emerald-950 text-sm">
                <span>{t('pureProfit')}:</span>
                <span className="text-emerald-800">+{formatPKR(pnl.grossProfit, language)}</span>
              </div>
            </div>

            {/* 3. Operating Expenses */}
            <div className="p-3 bg-rose-50/70 border border-rose-200/80 rounded-2xl space-y-1.5">
              <div className="flex justify-between font-bold text-rose-950 text-sm">
                <span className="flex items-center gap-1.5">
                  <TrendingDown className="w-4 h-4 text-rose-600" />
                  <span>{t('operatingExpensesHeading')}</span>
                </span>
                <span className="text-rose-700 font-black">
                  -{formatPKR(pnl.operatingExpenses, language)}
                </span>
              </div>
              <p className="text-[10px] text-slate-500 pl-6">
                {t('operatingExpensesDesc')}
              </p>
            </div>

            {/* 4. NET PROFIT FINAL ROW */}
            <div className="p-4 bg-slate-900 text-white rounded-2xl flex items-center justify-between">
              <div>
                <div className="text-xs text-slate-300 font-bold uppercase">
                  {t('netProfitLabel')}
                </div>
                <div className="text-[10px] text-emerald-400">
                  {t('netProfitFormula')}
                </div>
              </div>
              <div
                className={`text-2xl font-black ${
                  pnl.netPureProfit >= 0 ? 'text-amber-300' : 'text-rose-400'
                }`}
              >
                {formatPKR(pnl.netPureProfit, language)}
              </div>
            </div>
          </div>

          {/* Educational Accounting Rule Note */}
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900 flex items-start gap-2">
            <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <strong className="font-bold">{t('accountingRuleTitle')}</strong>
              <p className="text-[11px] text-blue-800 mt-0.5">
                {t('onlyCommissionCountsNote')}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 3. ACCOUNT BALANCES & MOVEMENT */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <h3 className="font-bold text-sm text-slate-800 mb-3 flex items-center justify-between">
          <span>{t('accountMovementTitle')}</span>
          <span className="text-xs text-slate-500 font-normal">
            {t('periodMovement')}
          </span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {accounts.map((acc) => {
            const stat = accountStats[acc.id] || { in: 0, out: 0, balance: acc.currentBalance };
            return (
              <div key={acc.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-bold text-xs text-slate-800">{getAccountName(acc.id, language)}</span>
                  <span className="font-mono text-xs font-black text-slate-900">
                    {formatPKR(acc.currentBalance, language)}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px] pt-1.5 border-t border-slate-200">
                  <div className="text-emerald-700">
                    {t('inflowLabel')} +{formatPKR(stat.in, language)}
                  </div>
                  <div className="text-rose-700 text-right">
                    {t('outflowLabel')} -{formatPKR(stat.out, language)}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. CATEGORY BREAKDOWN TABLE */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-sm text-slate-800">
            {t('categoriesBreakdownTitle')}
          </h3>
          <span className="text-xs text-slate-500">
            {pnl.categoryBreakdown.length} {t('category')}
          </span>
        </div>

        <div className="divide-y divide-slate-100 text-xs">
          {pnl.categoryBreakdown.map((item, idx) => (
            <div key={idx} className="p-3 flex items-center justify-between hover:bg-slate-50">
              <div className="flex items-center gap-2">
                <span
                  className={`w-2 h-2 rounded-full ${
                    item.type === 'IN' ? 'bg-emerald-500' : 'bg-rose-500'
                  }`}
                />
                <span className="font-semibold text-slate-800">{getCategoryLabel(item.catId, language)}</span>
                <span className="text-[10px] text-slate-400">({item.count} {t('records')})</span>
              </div>
              <div
                className={`font-black ${
                  item.type === 'IN' ? 'text-emerald-700' : 'text-rose-600'
                }`}
              >
                {item.type === 'IN' ? '+' : '-'}
                {formatPKR(item.amount, language)}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 5. OUTSTANDING BALANCES SUMMARY */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-semibold">
            {t('totalCustomerReceivables')}
          </div>
          <div className="text-xl font-black text-amber-700 mt-1">
            {formatPKR(totalReceivables, language)}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            {customers.filter((c) => c.balance > 0).length} {language === 'ur' ? 'گاہکوں سے رقم وصول کرنی ہے' : 'customers with outstanding balances'}
          </p>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-semibold">
            {t('totalSupplierPayables')}
          </div>
          <div className="text-xl font-black text-rose-700 mt-1">
            {formatPKR(totalPayables, language)}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            {suppliers.filter((s) => s.payable > 0).length} {language === 'ur' ? 'سپلائرز کو رقم ادا کرنی ہے' : 'suppliers with payables due'}
          </p>
        </div>
      </div>
    </div>
  );
};
