import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Truck,
  Phone,
  MessageCircle,
  Search,
  Plus,
  ArrowDownLeft,
  ArrowUpRight,
  Printer,
  ChevronRight,
  X,
  CreditCard,
  Building,
  CheckCircle,
  FileSpreadsheet,
} from 'lucide-react';
import { Account, AccountId, Customer, ShopSettings, Supplier, Transaction } from '../types';
import {
  formatDate,
  formatPKR,
  formatTime,
  generateWhatsAppReminderMessage,
  getCurrentTimeString,
  getTodayDateString,
  getAccountName,
} from '../lib/formatters';
import { exportCustomersToCSV } from '../lib/csvExport';
import { useLanguage } from '../context/LanguageContext';

interface KhataManagerProps {
  customers: Customer[];
  suppliers: Supplier[];
  transactions: Transaction[];
  accounts: Account[];
  settings: ShopSettings;
  onSaveCustomer: (cust: Customer) => Promise<void>;
  onDeleteCustomer: (id: string) => Promise<void>;
  onSaveSupplier: (supp: Supplier) => Promise<void>;
  onDeleteSupplier: (id: string) => Promise<void>;
  onAddTransaction: (tx: Transaction) => Promise<void>;
}

export const KhataManager: React.FC<KhataManagerProps> = ({
  customers,
  suppliers,
  transactions,
  accounts,
  settings,
  onSaveCustomer,
  onDeleteCustomer,
  onSaveSupplier,
  onDeleteSupplier,
  onAddTransaction,
}) => {
  const { t, language } = useLanguage();
  const [activeSubTab, setActiveSubTab] = useState<'CUSTOMERS' | 'SUPPLIERS'>('CUSTOMERS');
  const [searchQuery, setSearchQuery] = useState('');

  // Selected for ledger drawer
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null);

  // Modals
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const [isAddSupplierOpen, setIsAddSupplierOpen] = useState(false);

  // Quick Action modal for customer: "Udhar Diya" or "Wasooli Ki"
  const [customerActionType, setCustomerActionType] = useState<'UDHAR_DIYA' | 'WASOOLI_KI' | null>(null);
  const [actionAmount, setActionAmount] = useState('');
  const [actionAccount, setActionAccount] = useState<AccountId>('cash');
  const [actionDescription, setActionDescription] = useState('');
  const [isSubmittingAction, setIsSubmittingAction] = useState(false);

  // Supplier action modal: "Stock Liya" or "Adaigi Ki"
  const [supplierActionType, setSupplierActionType] = useState<'STOCK_LIYA' | 'ADAIGI_KI' | null>(null);

  // New Customer Form State
  const [newCustName, setNewCustName] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newCustAddress, setNewCustAddress] = useState('');
  const [newCustOpeningBalance, setNewCustOpeningBalance] = useState('');
  const [newCustNotes, setNewCustNotes] = useState('');

  // New Supplier Form State
  const [newSuppName, setNewSuppName] = useState('');
  const [newSuppCompany, setNewSuppCompany] = useState('');
  const [newSuppPhone, setNewSuppPhone] = useState('');
  const [newSuppOpeningPayable, setNewSuppOpeningPayable] = useState('');
  const [newSuppNotes, setNewSuppNotes] = useState('');

  // Calculated totals
  const totalReceivables = customers.reduce((sum, c) => sum + Math.max(0, c.balance || 0), 0);
  const totalPayables = suppliers.reduce((sum, s) => sum + Math.max(0, s.payable || 0), 0);

  // Filtered lists
  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.phone.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.address?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredSuppliers = suppliers.filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.company?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.phone.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Customer transactions history
  const customerHistory = selectedCustomer
    ? transactions.filter((tItem) => tItem.customerId === selectedCustomer.id || tItem.customerName === selectedCustomer.name)
    : [];

  // Supplier transactions history
  const supplierHistory = selectedSupplier
    ? transactions.filter((tItem) => tItem.supplierId === selectedSupplier.id || tItem.supplierName === selectedSupplier.name)
    : [];

  // Handle Add Customer
  const handleCreateCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustName.trim()) return;

    const openingBal = parseFloat(newCustOpeningBalance) || 0;
    const newCust: Customer = {
      id: `cust-${Date.now()}`,
      name: newCustName.trim(),
      phone: newCustPhone.trim(),
      address: newCustAddress.trim() || undefined,
      balance: openingBal,
      createdAt: getTodayDateString(),
      notes: newCustNotes.trim() || undefined,
    };

    await onSaveCustomer(newCust);

    // If opening balance > 0, also create initial credit entry
    if (openingBal > 0) {
      const desc = language === 'ur'
        ? `سابقہ ادھار کھاتہ - ${newCust.name}`
        : `Opening Khata Balance - ${newCust.name}`;
      await onAddTransaction({
        id: `tx-init-cust-${Date.now()}`,
        date: getTodayDateString(),
        time: getCurrentTimeString(),
        timestamp: Date.now(),
        type: 'IN',
        amount: openingBal,
        accountId: 'cash',
        category: 'mobile_accessories',
        description: desc,
        customerId: newCust.id,
        customerName: newCust.name,
      });
    }

    setNewCustName('');
    setNewCustPhone('');
    setNewCustAddress('');
    setNewCustOpeningBalance('');
    setNewCustNotes('');
    setIsAddCustomerOpen(false);
  };

  // Handle Add Supplier
  const handleCreateSupplier = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSuppName.trim()) return;

    const openingPay = parseFloat(newSuppOpeningPayable) || 0;
    const newSupp: Supplier = {
      id: `supp-${Date.now()}`,
      name: newSuppName.trim(),
      company: newSuppCompany.trim() || undefined,
      phone: newSuppPhone.trim(),
      payable: openingPay,
      createdAt: getTodayDateString(),
      notes: newSuppNotes.trim() || undefined,
    };

    await onSaveSupplier(newSupp);
    setNewSuppName('');
    setNewSuppCompany('');
    setNewSuppPhone('');
    setNewSuppOpeningPayable('');
    setNewSuppNotes('');
    setIsAddSupplierOpen(false);
  };

  // Submit Customer Action (Udhar Diya OR Wasooli Ki)
  const handleSubmitCustomerAction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer || !customerActionType) return;
    const amt = parseFloat(actionAmount);
    if (isNaN(amt) || amt <= 0) return;

    setIsSubmittingAction(true);
    try {
      if (customerActionType === 'WASOOLI_KI') {
        const updatedCustomer: Customer = {
          ...selectedCustomer,
          balance: selectedCustomer.balance - amt,
        };
        await onSaveCustomer(updatedCustomer);
        setSelectedCustomer(updatedCustomer);

        const defaultDesc = language === 'ur'
          ? `گاہک ${selectedCustomer.name} سے رقم وصولی`
          : `Customer payment received from ${selectedCustomer.name}`;

        await onAddTransaction({
          id: `tx-wasooli-${Date.now()}`,
          date: getTodayDateString(),
          time: getCurrentTimeString(),
          timestamp: Date.now(),
          type: 'IN',
          amount: amt,
          accountId: actionAccount,
          category: 'customer_payment',
          description: actionDescription.trim() || defaultDesc,
          customerId: selectedCustomer.id,
          customerName: selectedCustomer.name,
          isCreditSettlement: true,
        });
      } else {
        const updatedCustomer: Customer = {
          ...selectedCustomer,
          balance: selectedCustomer.balance + amt,
        };
        await onSaveCustomer(updatedCustomer);
        setSelectedCustomer(updatedCustomer);

        const defaultDesc = language === 'ur'
          ? `ادھار سامان فروخت - ${selectedCustomer.name}`
          : `Credit sale - ${selectedCustomer.name}`;

        await onAddTransaction({
          id: `tx-udhar-${Date.now()}`,
          date: getTodayDateString(),
          time: getCurrentTimeString(),
          timestamp: Date.now(),
          type: 'IN',
          amount: amt,
          accountId: 'cash',
          category: 'mobile_accessories',
          description: actionDescription.trim() || defaultDesc,
          customerId: selectedCustomer.id,
          customerName: selectedCustomer.name,
        });
      }

      setCustomerActionType(null);
      setActionAmount('');
      setActionDescription('');
    } finally {
      setIsSubmittingAction(false);
    }
  };

  // Submit Supplier Action (Stock Liya OR Adaigi Ki)
  const handleSubmitSupplierAction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSupplier || !supplierActionType) return;
    const amt = parseFloat(actionAmount);
    if (isNaN(amt) || amt <= 0) return;

    setIsSubmittingAction(true);
    try {
      if (supplierActionType === 'ADAIGI_KI') {
        const updatedSupplier: Supplier = {
          ...selectedSupplier,
          payable: selectedSupplier.payable - amt,
        };
        await onSaveSupplier(updatedSupplier);
        setSelectedSupplier(updatedSupplier);

        const defaultDesc = language === 'ur'
          ? `سپلائر ${selectedSupplier.name} کو رقم ادائیگی`
          : `Payment made to supplier ${selectedSupplier.name}`;

        await onAddTransaction({
          id: `tx-supp-pay-${Date.now()}`,
          date: getTodayDateString(),
          time: getCurrentTimeString(),
          timestamp: Date.now(),
          type: 'OUT',
          amount: amt,
          accountId: actionAccount,
          category: 'supplier_payment',
          description: actionDescription.trim() || defaultDesc,
          supplierId: selectedSupplier.id,
          supplierName: selectedSupplier.name,
        });
      } else {
        const updatedSupplier: Supplier = {
          ...selectedSupplier,
          payable: selectedSupplier.payable + amt,
        };
        await onSaveSupplier(updatedSupplier);
        setSelectedSupplier(updatedSupplier);

        const defaultDesc = language === 'ur'
          ? `ہول سیل اسٹاک ادھار لیا - ${selectedSupplier.name}`
          : `Credit stock received from ${selectedSupplier.name}`;

        await onAddTransaction({
          id: `tx-stock-${Date.now()}`,
          date: getTodayDateString(),
          time: getCurrentTimeString(),
          timestamp: Date.now(),
          type: 'OUT',
          amount: amt,
          accountId: 'cash',
          category: 'supplier_payment',
          description: actionDescription.trim() || defaultDesc,
          supplierId: selectedSupplier.id,
          supplierName: selectedSupplier.name,
        });
      }

      setSupplierActionType(null);
      setActionAmount('');
      setActionDescription('');
    } finally {
      setIsSubmittingAction(false);
    }
  };

  // Open WhatsApp with reminder
  const sendWhatsAppReminder = (customer: Customer) => {
    const cleanPhone = customer.phone.replace(/[^0-9]/g, '');
    let formattedPhone = cleanPhone;
    if (formattedPhone.startsWith('0')) {
      formattedPhone = '92' + formattedPhone.slice(1);
    }
    const message = generateWhatsAppReminderMessage(
      customer.name,
      customer.balance,
      settings.shopName,
      settings.phone,
      language
    );
    const url = `https://wa.me/${formattedPhone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-4 pb-20 pt-2 px-3 sm:px-4 max-w-5xl mx-auto">
      {/* KHATA TABS (Customer vs Supplier) */}
      <div className="flex items-center justify-between">
        <div className="flex bg-slate-200/80 p-1 rounded-2xl">
          <button
            onClick={() => {
              setActiveSubTab('CUSTOMERS');
              setSelectedCustomer(null);
              setSelectedSupplier(null);
            }}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeSubTab === 'CUSTOMERS'
                ? 'bg-white text-emerald-800 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>{t('khataCustomerTab')} ({customers.length})</span>
          </button>

          <button
            onClick={() => {
              setActiveSubTab('SUPPLIERS');
              setSelectedCustomer(null);
              setSelectedSupplier(null);
            }}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeSubTab === 'SUPPLIERS'
                ? 'bg-white text-rose-800 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Truck className="w-4 h-4" />
            <span>{t('khataSupplierTab')} ({suppliers.length})</span>
          </button>
        </div>

        <button
          onClick={() =>
            activeSubTab === 'CUSTOMERS' ? setIsAddCustomerOpen(true) : setIsAddSupplierOpen(true)
          }
          className={`flex items-center gap-1.5 px-3 py-2 text-white rounded-xl text-xs font-bold shadow-md active:scale-95 transition-all ${
            activeSubTab === 'CUSTOMERS'
              ? 'bg-emerald-600 hover:bg-emerald-700'
              : 'bg-rose-600 hover:bg-rose-700'
          }`}
        >
          <UserPlus className="w-4 h-4" />
          <span>
            {activeSubTab === 'CUSTOMERS' ? t('newCustomerBtn') : t('newSupplierBtn')}
          </span>
        </button>
      </div>

      {/* SUMMARY BANNER */}
      {activeSubTab === 'CUSTOMERS' ? (
        <div className="bg-gradient-to-r from-emerald-800 to-teal-900 rounded-2xl p-4 text-white shadow-md flex items-center justify-between">
          <div>
            <div className="text-xs text-emerald-200 font-medium">
              {t('totalCustomerReceivables')}
            </div>
            <div className="text-2xl font-black mt-0.5 text-white tracking-tight">
              {formatPKR(totalReceivables, language)}
            </div>
            <div className="text-[11px] text-emerald-300 mt-1">
              {t('totalReceivablesSubtitle')}
            </div>
          </div>
          <button
            onClick={() => exportCustomersToCSV(customers)}
            className="p-2.5 bg-emerald-700/80 hover:bg-emerald-700 rounded-xl text-xs font-bold flex items-center gap-1.5 border border-emerald-600 shadow-inner"
            title={t('csvExportBtn')}
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
            <span className="hidden sm:inline">{t('csvExportBtn')}</span>
          </button>
        </div>
      ) : (
        <div className="bg-gradient-to-r from-rose-800 to-red-950 rounded-2xl p-4 text-white shadow-md flex items-center justify-between">
          <div>
            <div className="text-xs text-rose-200 font-medium">
              {t('totalSupplierPayables')}
            </div>
            <div className="text-2xl font-black mt-0.5 text-white tracking-tight">
              {formatPKR(totalPayables, language)}
            </div>
            <div className="text-[11px] text-rose-300 mt-1">
              {t('totalPayablesSubtitle')}
            </div>
          </div>
        </div>
      )}

      {/* SEARCH BOX */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
        <input
          type="text"
          placeholder={
            activeSubTab === 'CUSTOMERS'
              ? t('searchCustomerPlaceholder')
              : t('searchSupplierPlaceholder')
          }
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-9 pr-4 py-2 text-xs bg-white border border-slate-200 rounded-xl shadow-xs focus:ring-2 focus:ring-emerald-500"
        />
      </div>

      {/* CUSTOMER LIST / SUPPLIER LIST */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {activeSubTab === 'CUSTOMERS' ? (
          filteredCustomers.length === 0 ? (
            <div className="col-span-2 bg-white rounded-2xl p-10 text-center border border-slate-200">
              <Users className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-xs font-bold text-slate-700">
                {t('noCustomersFound')}
              </p>
              <button
                onClick={() => setIsAddCustomerOpen(true)}
                className="mt-3 text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200"
              >
                {t('addFirstCustomer')}
              </button>
            </div>
          ) : (
            filteredCustomers.map((c) => (
              <div
                key={c.id}
                onClick={() => setSelectedCustomer(c)}
                className="bg-white rounded-2xl p-4 border border-slate-200 hover:border-emerald-300 shadow-xs cursor-pointer transition-all flex items-center justify-between group"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-slate-900 truncate">
                      {c.name}
                    </span>
                    {c.balance > 0 && (
                      <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded-full">
                        {t('receivableDue')}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                    {c.phone && (
                      <span className="flex items-center gap-1 font-mono">
                        <Phone className="w-3 h-3 text-slate-400" />
                        {c.phone}
                      </span>
                    )}
                    {c.address && <span>• {c.address}</span>}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div
                    className={`text-base font-black ${
                      c.balance > 0
                        ? 'text-amber-700'
                        : c.balance < 0
                        ? 'text-blue-600'
                        : 'text-slate-500'
                    }`}
                  >
                    {formatPKR(c.balance, language)}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    {c.balance > 0 ? t('receivableDue') : c.balance < 0 ? t('advanceReceived') : t('settledClear')}
                  </div>
                </div>
              </div>
            ))
          )
        ) : filteredSuppliers.length === 0 ? (
          <div className="col-span-2 bg-white rounded-2xl p-10 text-center border border-slate-200">
            <Truck className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-xs font-bold text-slate-700">
              {t('noSuppliersFound')}
            </p>
            <button
              onClick={() => setIsAddSupplierOpen(true)}
              className="mt-3 text-xs font-bold text-rose-700 bg-rose-50 px-3 py-1.5 rounded-xl border border-rose-200"
            >
              {t('addFirstSupplier')}
            </button>
          </div>
        ) : (
          filteredSuppliers.map((s) => (
            <div
              key={s.id}
              onClick={() => setSelectedSupplier(s)}
              className="bg-white rounded-2xl p-4 border border-slate-200 hover:border-rose-300 shadow-xs cursor-pointer transition-all flex items-center justify-between group"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-slate-900 truncate">
                    {s.name}
                  </span>
                  {s.company && (
                    <span className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.2 rounded font-medium">
                      {s.company}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                  {s.phone && (
                    <span className="flex items-center gap-1 font-mono">
                      <Phone className="w-3 h-3 text-slate-400" />
                      {s.phone}
                    </span>
                  )}
                </div>
              </div>

              <div className="text-right shrink-0">
                <div className="text-base font-black text-rose-700">
                  {formatPKR(s.payable, language)}
                </div>
                <div className="text-[10px] text-slate-400">{t('payableDue')}</div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* CUSTOMER DETAIL LEDGER MODAL */}
      {selectedCustomer && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in duration-150">
            {/* Header */}
            <div className="px-5 py-4 bg-emerald-800 text-white flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base">{selectedCustomer.name}</h3>
                <p className="text-xs text-emerald-200">
                  {selectedCustomer.phone || (language === 'ur' ? 'فون درج نہیں' : 'No phone recorded')}{' '}
                  {selectedCustomer.address && `• ${selectedCustomer.address}`}
                </p>
              </div>
              <button
                onClick={() => setSelectedCustomer(null)}
                className="w-7 h-7 rounded-full bg-emerald-900 text-emerald-200 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Balance Banner & WhatsApp reminder */}
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <div className="text-[11px] text-slate-500 font-semibold">
                  {t('totalCustomerReceivables')}:
                </div>
                <div className="text-2xl font-black text-amber-700">
                  {formatPKR(selectedCustomer.balance, language)}
                </div>
              </div>

              <div className="flex items-center gap-2">
                {selectedCustomer.phone && selectedCustomer.balance > 0 && (
                  <button
                    onClick={() => sendWhatsAppReminder(selectedCustomer)}
                    className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all"
                    title={t('whatsappReminderBtn')}
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>{t('whatsappReminderBtn')}</span>
                  </button>
                )}
              </div>
            </div>

            {/* Quick Ledger Action Buttons */}
            <div className="p-3 bg-slate-100 border-b border-slate-200 grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  setCustomerActionType('WASOOLI_KI');
                  setActionAmount('');
                  setActionDescription('');
                }}
                className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm active:scale-95"
              >
                <ArrowDownLeft className="w-4 h-4" />
                <span>{t('collectPaymentBtn')}</span>
              </button>

              <button
                onClick={() => {
                  setCustomerActionType('UDHAR_DIYA');
                  setActionAmount('');
                  setActionDescription('');
                }}
                className="py-2.5 px-3 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm active:scale-95"
              >
                <ArrowUpRight className="w-4 h-4" />
                <span>{t('giveCreditBtn')}</span>
              </button>
            </div>

            {/* Transactions History Ledger */}
            <div className="p-4 flex-1 overflow-y-auto space-y-2">
              <h4 className="text-xs font-bold uppercase text-slate-500 mb-2">
                {t('ledgerHistoryTitle')}
              </h4>

              {customerHistory.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-400">
                  {t('noCustomerHistory')}
                </div>
              ) : (
                <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden bg-white">
                  {customerHistory.map((tItem) => (
                    <div key={tItem.id} className="p-2.5 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-semibold text-slate-800">
                          {tItem.description}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {formatDate(tItem.date, language)}{' '}
                          {tItem.time && `• ${formatTime(tItem.time, language)}`} •{' '}
                          {getAccountName(tItem.accountId, language)}
                        </div>
                      </div>
                      <div
                        className={`font-black ${
                          tItem.isCreditSettlement
                            ? 'text-emerald-700'
                            : 'text-amber-700'
                        }`}
                      >
                        {tItem.isCreditSettlement ? '-' : '+'}
                        {formatPKR(tItem.amount, language)}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
              <button
                onClick={async () => {
                  const confirmMsg = language === 'ur'
                    ? `کیا آپ واقعی ${selectedCustomer.name} کا کھاتہ حذف کرنا چاہتے ہیں؟`
                    : `Are you sure you want to delete ${selectedCustomer.name}?`;
                  if (confirm(confirmMsg)) {
                    await onDeleteCustomer(selectedCustomer.id);
                    setSelectedCustomer(null);
                  }
                }}
                className="text-xs text-red-600 hover:underline"
              >
                {t('deleteCustomerBtn')}
              </button>

              <button
                onClick={() => setSelectedCustomer(null)}
                className="px-4 py-1.5 text-xs font-bold bg-slate-200 text-slate-700 rounded-lg"
              >
                {t('close')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUPPLIER DETAIL LEDGER MODAL */}
      {selectedSupplier && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in duration-150">
            {/* Header */}
            <div className="px-5 py-4 bg-rose-800 text-white flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base">{selectedSupplier.name}</h3>
                <p className="text-xs text-rose-200">
                  {selectedSupplier.company || (language === 'ur' ? 'ہول سیل' : 'Wholesale')} •{' '}
                  {selectedSupplier.phone || (language === 'ur' ? 'فون درج نہیں' : 'No phone recorded')}
                </p>
              </div>
              <button
                onClick={() => setSelectedSupplier(null)}
                className="w-7 h-7 rounded-full bg-rose-900 text-rose-200 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Balance Banner */}
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <div className="text-[11px] text-slate-500 font-semibold">
                  {t('totalSupplierPayables')}:
                </div>
                <div className="text-2xl font-black text-rose-700">
                  {formatPKR(selectedSupplier.payable, language)}
                </div>
              </div>
            </div>

            {/* Quick Supplier Actions */}
            <div className="p-3 bg-slate-100 border-b border-slate-200 grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  setSupplierActionType('ADAIGI_KI');
                  setActionAmount('');
                  setActionDescription('');
                }}
                className="py-2.5 px-3 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm active:scale-95"
              >
                <ArrowUpRight className="w-4 h-4" />
                <span>{t('paySupplierBtn')}</span>
              </button>

              <button
                onClick={() => {
                  setSupplierActionType('STOCK_LIYA');
                  setActionAmount('');
                  setActionDescription('');
                }}
                className="py-2.5 px-3 bg-slate-700 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm active:scale-95"
              >
                <Truck className="w-4 h-4" />
                <span>{t('takeCreditStockBtn')}</span>
              </button>
            </div>

            {/* History */}
            <div className="p-4 flex-1 overflow-y-auto space-y-2">
              <h4 className="text-xs font-bold uppercase text-slate-500 mb-2">
                {t('supplierHistoryTitle')}
              </h4>

              {supplierHistory.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-400">
                  {t('noSupplierHistory')}
                </div>
              ) : (
                <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden bg-white">
                  {supplierHistory.map((tItem) => (
                    <div key={tItem.id} className="p-2.5 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-semibold text-slate-800">
                          {tItem.description}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {formatDate(tItem.date, language)} • {getAccountName(tItem.accountId, language)}
                        </div>
                      </div>
                      <div className="font-black text-rose-700">
                        {formatPKR(tItem.amount, language)}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
              <button
                onClick={async () => {
                  const confirmMsg = language === 'ur'
                    ? `کیا آپ واقعی ${selectedSupplier.name} کو حذف کرنا چاہتے ہیں؟`
                    : `Are you sure you want to delete supplier ${selectedSupplier.name}?`;
                  if (confirm(confirmMsg)) {
                    await onDeleteSupplier(selectedSupplier.id);
                    setSelectedSupplier(null);
                  }
                }}
                className="text-xs text-red-600 hover:underline"
              >
                {t('deleteSupplierBtn')}
              </button>

              <button
                onClick={() => setSelectedSupplier(null)}
                className="px-4 py-1.5 text-xs font-bold bg-slate-200 text-slate-700 rounded-lg"
              >
                {t('close')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CUSTOMER ACTION SUB-MODAL (Wasooli / Udhar Diya) */}
      {customerActionType && selectedCustomer && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl p-5 space-y-3">
            <div className="flex items-center justify-between border-b pb-2">
              <h4 className="font-bold text-sm text-slate-800">
                {customerActionType === 'WASOOLI_KI'
                  ? t('receivePaymentModalTitle')
                  : t('giveCreditModalTitle')}
              </h4>
              <button
                onClick={() => setCustomerActionType(null)}
                className="w-6 h-6 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <form onSubmit={handleSubmitCustomerAction} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('amountLabel')}
                </label>
                <input
                  type="number"
                  step="any"
                  min="1"
                  required
                  placeholder="0"
                  value={actionAmount}
                  onChange={(e) => setActionAmount(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-xl font-bold text-lg text-slate-900"
                />
              </div>

              {customerActionType === 'WASOOLI_KI' && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t('paymentAccountLabel')}
                  </label>
                  <select
                    value={actionAccount}
                    onChange={(e) => setActionAccount(e.target.value as AccountId)}
                    className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
                  >
                    {accounts.map((acc) => (
                      <option key={acc.id} value={acc.id}>
                        {getAccountName(acc.id, language)} ({formatPKR(acc.currentBalance, language)})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('descriptionLabel')}
                </label>
                <input
                  type="text"
                  placeholder={
                    customerActionType === 'WASOOLI_KI'
                      ? (language === 'ur' ? 'مثلاً: نقد رقم موصول' : 'e.g. Cash received by hand')
                      : (language === 'ur' ? 'مثلاً: فاسٹ چارجر، گلاس پروٹیکٹر' : 'e.g. 2 Fast Chargers, Glass protector')
                  }
                  value={actionDescription}
                  onChange={(e) => setActionDescription(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setCustomerActionType(null)}
                  className="px-3 py-2 text-xs font-bold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingAction}
                  className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md"
                >
                  {isSubmittingAction ? t('savingTransaction') : t('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SUPPLIER ACTION SUB-MODAL */}
      {supplierActionType && selectedSupplier && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl p-5 space-y-3">
            <div className="flex items-center justify-between border-b pb-2">
              <h4 className="font-bold text-sm text-slate-800">
                {supplierActionType === 'ADAIGI_KI'
                  ? t('paySupplierModalTitle')
                  : t('takeStockModalTitle')}
              </h4>
              <button
                onClick={() => setSupplierActionType(null)}
                className="w-6 h-6 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <form onSubmit={handleSubmitSupplierAction} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('amountLabel')}
                </label>
                <input
                  type="number"
                  step="any"
                  min="1"
                  required
                  placeholder="0"
                  value={actionAmount}
                  onChange={(e) => setActionAmount(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-xl font-bold text-lg text-slate-900"
                />
              </div>

              {supplierActionType === 'ADAIGI_KI' && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t('paymentAccountLabel')}
                  </label>
                  <select
                    value={actionAccount}
                    onChange={(e) => setActionAccount(e.target.value as AccountId)}
                    className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
                  >
                    {accounts.map((acc) => (
                      <option key={acc.id} value={acc.id}>
                        {getAccountName(acc.id, language)} ({formatPKR(acc.currentBalance, language)})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('descriptionLabel')}
                </label>
                <input
                  type="text"
                  placeholder={language === 'ur' ? 'مثلاً: بینک کے ذریعے ادائیگی، نقد ادا کی' : 'e.g. Bank transfer, Cash paid'}
                  value={actionDescription}
                  onChange={(e) => setActionDescription(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSupplierActionType(null)}
                  className="px-3 py-2 text-xs font-bold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingAction}
                  className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-md"
                >
                  {isSubmittingAction ? t('savingTransaction') : t('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD CUSTOMER MODAL */}
      {isAddCustomerOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-bold text-sm text-slate-800">
                {t('modalAddCustomerTitle')}
              </h3>
              <button
                onClick={() => setIsAddCustomerOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('custNameRequired')}
                </label>
                <input
                  type="text"
                  required
                  placeholder={language === 'ur' ? 'مثلاً: طارق محمود، آصف بھائی' : 'e.g. Tariq Mehmood, Asif Bhai'}
                  value={newCustName}
                  onChange={(e) => setNewCustName(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('phoneInputLabel')}
                </label>
                <input
                  type="tel"
                  placeholder="0300-1234567"
                  value={newCustPhone}
                  onChange={(e) => setNewCustPhone(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('addressInputLabel')}
                </label>
                <input
                  type="text"
                  placeholder={language === 'ur' ? 'مثلاً: مین بازار، دکان نمبر 5' : 'e.g. Main Bazar, Shop # 5'}
                  value={newCustAddress}
                  onChange={(e) => setNewCustAddress(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('openingDebtLabel')}
                </label>
                <input
                  type="number"
                  placeholder="0"
                  value={newCustOpeningBalance}
                  onChange={(e) => setNewCustOpeningBalance(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t">
                <button
                  type="button"
                  onClick={() => setIsAddCustomerOpen(false)}
                  className="px-3 py-2 text-xs font-bold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md"
                >
                  {t('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD SUPPLIER MODAL */}
      {isAddSupplierOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-bold text-sm text-slate-800">
                {t('modalAddSupplierTitle')}
              </h3>
              <button
                onClick={() => setIsAddSupplierOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSupplier} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('suppNameRequired')}
                </label>
                <input
                  type="text"
                  required
                  placeholder={language === 'ur' ? 'مثلاً: حاجی راشد، عمران موبائل' : 'e.g. Haji Rashid, Imran Mobile Wholesaler'}
                  value={newSuppName}
                  onChange={(e) => setNewSuppName(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('companyMarketLabel')}
                </label>
                <input
                  type="text"
                  placeholder={language === 'ur' ? 'مثلاً: ہال روڈ لاہور، پیپر مارکیٹ' : 'e.g. Hall Road Lahore, Paper Market'}
                  value={newSuppCompany}
                  onChange={(e) => setNewSuppCompany(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('phoneInputLabel')}
                </label>
                <input
                  type="tel"
                  placeholder="0300-9876543"
                  value={newSuppPhone}
                  onChange={(e) => setNewSuppPhone(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('openingPayableLabel')}
                </label>
                <input
                  type="number"
                  placeholder="0"
                  value={newSuppOpeningPayable}
                  onChange={(e) => setNewSuppOpeningPayable(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t">
                <button
                  type="button"
                  onClick={() => setIsAddSupplierOpen(false)}
                  className="px-3 py-2 text-xs font-bold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-md"
                >
                  {t('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
