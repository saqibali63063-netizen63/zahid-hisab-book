import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  Send,
  ArrowDownToLine,
  CheckCircle,
  HelpCircle,
  Smartphone,
  Flame,
  Building2,
  Calendar,
  Clock,
  User,
  Hash,
  Sparkles,
  Info,
  AlertTriangle,
  ArrowRight,
  ArrowLeft,
  Banknote,
  Receipt,
  FileText,
  Phone,
  Tag,
} from 'lucide-react';
import { Account, AccountId, CommissionServiceType, ShopSettings, Transaction } from '../types';
import {
  calculateCommission,
  formatDate,
  formatPKR,
  formatTime,
  getAccountBadge,
  getAccountName,
  getCategoryLabel,
  getCurrentTimeString,
  getTodayDateString,
} from '../lib/formatters';
import { useLanguage } from '../context/LanguageContext';

interface CommissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (tx: Transaction) => Promise<void>;
  editingTransaction?: Transaction | null;
  accounts: Account[];
  settings: ShopSettings;
  initialServiceType?: CommissionServiceType;
  initialAccountId?: AccountId;
  lockAccountId?: boolean;
}

export const CommissionModal: React.FC<CommissionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingTransaction,
  accounts,
  settings,
  initialServiceType = 'send_money',
  initialAccountId = 'easypaisa',
  lockAccountId = false,
}) => {
  const { t, language } = useLanguage();

  const [step, setStep] = useState<'input' | 'confirm'>('input');
  const [serviceType, setServiceType] = useState<CommissionServiceType>(initialServiceType);
  const [accountId, setAccountId] = useState<AccountId>(
    initialAccountId === 'cash' ? 'easypaisa' : initialAccountId
  );

  // Send Money Fields
  const [amountSent, setAmountSent] = useState<string>('');
  const [cashReceived, setCashReceived] = useState<string>('');

  // Cash Withdrawal Fields
  const [amountReceived, setAmountReceived] = useState<string>('');
  const [cashPaid, setCashPaid] = useState<string>('');

  // Manual Commission override
  const [isCommissionManuallyEdited, setIsCommissionManuallyEdited] = useState(false);
  const [customCommission, setCustomCommission] = useState<string>('');

  // Metadata
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [reference, setReference] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [date, setDate] = useState<string>(getTodayDateString());
  const [time, setTime] = useState<string>(getCurrentTimeString());

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string>('');

  // Active universal rate per 1,000 (applies universally to EasyPaisa, JazzCash, and Bank)
  const currentRate = serviceType === 'send_money'
    ? (settings.sendMoneyCommissionRate ?? 10)
    : (settings.cashWithdrawalCommissionRate ?? 20);

  // Change 2: Clean, single relevant category automatically determined by account and service
  const activeCategory = useMemo(() => {
    if (serviceType === 'send_money') {
      if (accountId === 'easypaisa') return 'easypaisa_send_money';
      if (accountId === 'jazzcash') return 'jazzcash_send_money';
      return 'bank_send_money';
    } else {
      if (accountId === 'easypaisa') return 'easypaisa_withdrawal';
      if (accountId === 'jazzcash') return 'jazzcash_withdrawal';
      return 'bank_withdrawal';
    }
  }, [serviceType, accountId]);

  // Synchronize state when modal opens or editingTransaction changes
  useEffect(() => {
    if (isOpen) {
      setStep('input');
      setError('');

      if (editingTransaction && editingTransaction.serviceType) {
        setServiceType(editingTransaction.serviceType);
        setAccountId(editingTransaction.accountId);
        if (editingTransaction.serviceType === 'send_money') {
          const sent = editingTransaction.amountSent ?? editingTransaction.principalAmount ?? editingTransaction.amount ?? 0;
          const comm = editingTransaction.commissionAmount ?? 0;
          const received = editingTransaction.cashReceived ?? (sent + comm);
          setAmountSent(String(sent));
          setCashReceived(String(received));
          setCustomCommission(String(comm));
          setAmountReceived('');
          setCashPaid('');
        } else {
          const received = editingTransaction.amountReceived ?? editingTransaction.principalAmount ?? editingTransaction.amount ?? 0;
          const comm = editingTransaction.commissionAmount ?? 0;
          const paid = editingTransaction.cashPaid ?? (received - comm);
          setAmountReceived(String(received));
          setCashPaid(String(paid));
          setCustomCommission(String(comm));
          setAmountSent('');
          setCashReceived('');
        }
        setIsCommissionManuallyEdited(true);
        setCustomerName(editingTransaction.customerName || '');
        setCustomerPhone(editingTransaction.customerPhone || '');
        setReference(editingTransaction.reference || '');
        setDescription(editingTransaction.description || '');
        setDate(editingTransaction.date || getTodayDateString());
        setTime(editingTransaction.time || getCurrentTimeString());
      } else {
        setServiceType(initialServiceType);
        const targetAcc = initialAccountId === 'cash' ? 'easypaisa' : initialAccountId;
        setAccountId(targetAcc);
        setAmountSent('');
        setCashReceived('');
        setAmountReceived('');
        setCashPaid('');
        setIsCommissionManuallyEdited(false);
        setCustomCommission('');
        setCustomerName('');
        setCustomerPhone('');
        setReference('');
        setDescription('');
        setDate(getTodayDateString());
        setTime(getCurrentTimeString());
      }
    }
  }, [isOpen, editingTransaction, initialServiceType, initialAccountId]);

  // Handle Amount Sent change for Send Money: Auto-calculates cash received using proportional rate
  const handleAmountSentChange = (val: string) => {
    setAmountSent(val);
    const sentNum = parseFloat(val);
    if (!isNaN(sentNum) && sentNum > 0) {
      if (!isCommissionManuallyEdited) {
        const comm = calculateCommission(sentNum, 'send_money', settings);
        setCashReceived(String(sentNum + comm));
      } else {
        const manualComm = parseFloat(customCommission) || 0;
        setCashReceived(String(sentNum + manualComm));
      }
    } else {
      setCashReceived('');
    }
  };

  // Handle Cash Received change for Send Money: Auto-calculates commission
  const handleCashReceivedChange = (val: string) => {
    setCashReceived(val);
    const receivedNum = parseFloat(val);
    const sentNum = parseFloat(amountSent) || 0;
    if (!isNaN(receivedNum) && sentNum > 0) {
      const diff = Math.max(0, receivedNum - sentNum);
      setCustomCommission(String(diff));
      setIsCommissionManuallyEdited(true);
    }
  };

  // Handle Cash Paid change for Cash Withdrawal: Auto-calculates account amount received using rate
  const handleCashPaidChange = (val: string) => {
    setCashPaid(val);
    const paidNum = parseFloat(val);
    if (!isNaN(paidNum) && paidNum > 0) {
      if (!isCommissionManuallyEdited) {
        const comm = calculateCommission(paidNum, 'cash_withdrawal', settings);
        setAmountReceived(String(paidNum + comm));
      } else {
        const manualComm = parseFloat(customCommission) || 0;
        setAmountReceived(String(paidNum + manualComm));
      }
    } else {
      setAmountReceived('');
    }
  };

  // Handle Account Amount Received change for Cash Withdrawal: Auto-calculates commission
  const handleAmountReceivedChange = (val: string) => {
    setAmountReceived(val);
    const receivedNum = parseFloat(val);
    const paidNum = parseFloat(cashPaid) || 0;
    if (!isNaN(receivedNum) && paidNum > 0) {
      const diff = Math.max(0, receivedNum - paidNum);
      setCustomCommission(String(diff));
      setIsCommissionManuallyEdited(true);
    }
  };

  // Quick Chips for Amount Sent (Send Money) or Cash Paid (Cash Withdrawal)
  const handleQuickAdd = (inc: number) => {
    if (serviceType === 'send_money') {
      const current = parseFloat(amountSent) || 0;
      handleAmountSentChange(String(current + inc));
    } else {
      const current = parseFloat(cashPaid) || 0;
      handleCashPaidChange(String(current + inc));
    }
  };

  const handleResetToAutoRate = () => {
    setIsCommissionManuallyEdited(false);
    if (serviceType === 'send_money') {
      const sentNum = parseFloat(amountSent) || 0;
      if (sentNum > 0) {
        const comm = calculateCommission(sentNum, 'send_money', settings);
        setCustomCommission(String(comm));
        setCashReceived(String(sentNum + comm));
      }
    } else {
      const paidNum = parseFloat(cashPaid) || 0;
      if (paidNum > 0) {
        const comm = calculateCommission(paidNum, 'cash_withdrawal', settings);
        setCustomCommission(String(comm));
        setAmountReceived(String(paidNum + comm));
      }
    }
  };

  // Calculated numbers
  const calculatedValues = useMemo(() => {
    if (serviceType === 'send_money') {
      const sent = parseFloat(amountSent) || 0;
      const received = parseFloat(cashReceived) || 0;
      // Formula: Commission = Cash received - Amount sent
      const comm = isCommissionManuallyEdited
        ? Math.max(0, parseFloat(customCommission) || (received - sent))
        : Math.max(0, received - sent);
      return {
        sent,
        received,
        paid: 0,
        comm,
        walletImpact: -sent,
        cashImpact: +received,
        netProfit: comm,
      };
    } else {
      const received = parseFloat(amountReceived) || 0;
      const paid = parseFloat(cashPaid) || 0;
      // Formula: Commission = Amount received in account - Cash paid to customer
      const comm = isCommissionManuallyEdited
        ? Math.max(0, parseFloat(customCommission) || (received - paid))
        : Math.max(0, received - paid);
      return {
        sent: 0,
        received,
        paid,
        comm,
        walletImpact: +received,
        cashImpact: -paid,
        netProfit: comm,
      };
    }
  }, [serviceType, amountSent, cashReceived, amountReceived, cashPaid, isCommissionManuallyEdited, customCommission]);

  const selectedAccount = accounts.find((a) => a.id === accountId);
  const cashAccount = accounts.find((a) => a.id === 'cash');

  // Validate inputs before moving to confirmation summary
  const handleProceedToReview = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (serviceType === 'send_money') {
      if (calculatedValues.sent <= 0) {
        setError(language === 'ur' ? 'بھیجنے کی رقم درج کریں' : 'Please enter the amount sent to customer.');
        return;
      }
      // FEATURE 5 VALIDATION 1: Cash received must not be less than amount sent
      if (calculatedValues.received < calculatedValues.sent) {
        setError(t('validationCashLessThanSent'));
        return;
      }
      // FEATURE 5 VALIDATION 3: Do not allow negative commission
      if (calculatedValues.comm < 0) {
        setError(t('validationNegativeCommission'));
        return;
      }
      // FEATURE 5 VALIDATION 4: Overdraft check on wallet/bank
      const allowOverdraft = settings.allowNegativeBalance ?? false;
      const currentWalletBal = selectedAccount?.currentBalance ?? 0;
      if (!allowOverdraft && currentWalletBal < calculatedValues.sent) {
        const accName = getAccountName(accountId, language);
        setError(
          language === 'ur'
            ? `${accName} میں رقم ناکافی ہے! دستیاب بیلنس: ${formatPKR(currentWalletBal, language)}، درکار: ${formatPKR(calculatedValues.sent, language)}۔ (اوور ڈرافٹ کی اجازت کے لیے ترتیبات میں "منفی بیلنس کی اجازت" آن کریں)۔`
            : `Insufficient balance in ${accName}! Available: ${formatPKR(currentWalletBal, language)}, required: ${formatPKR(calculatedValues.sent, language)}. (${t('overdraftErrorTip')})`
        );
        return;
      }
    } else {
      if (calculatedValues.paid <= 0) {
        setError(language === 'ur' ? 'ادا شدہ نقد رقم درج کریں' : 'Please enter the cash paid to customer.');
        return;
      }
      // FEATURE 5 VALIDATION 2: Account amount received must not be less than cash paid
      if (calculatedValues.received < calculatedValues.paid) {
        setError(t('validationAccountLessThanPaid'));
        return;
      }
      // FEATURE 5 VALIDATION 3: Do not allow negative commission
      if (calculatedValues.comm < 0) {
        setError(t('validationNegativeCommission'));
        return;
      }
      // FEATURE 5 VALIDATION 4: Overdraft check on Cash in Hand
      const allowOverdraft = settings.allowNegativeBalance ?? false;
      const currentCashBal = cashAccount?.currentBalance ?? 0;
      if (!allowOverdraft && currentCashBal < calculatedValues.paid) {
        setError(
          language === 'ur'
            ? `دکان پر نقد رقم (کیش ان ہینڈ) ناکافی ہے! دستیاب کیش: ${formatPKR(currentCashBal, language)}، ادا کرنے کی رقم: ${formatPKR(calculatedValues.paid, language)}۔ (${t('overdraftErrorTip')})`
            : `Insufficient Cash in Hand! Available cash: ${formatPKR(currentCashBal, language)}, paying: ${formatPKR(calculatedValues.paid, language)}. (${t('overdraftErrorTip')})`
        );
        return;
      }
    }

    // Validation passed -> proceed to confirmation summary step
    setStep('confirm');
  };

  // Final submission from confirmation summary
  const handleFinalConfirmSave = async () => {
    setIsSubmitting(true);
    setError('');

    try {
      const txId = editingTransaction ? editingTransaction.id : `tx-comm-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      const timestamp = editingTransaction?.timestamp || (new Date(`${date}T${time || '12:00'}:00`).getTime() || Date.now());

      let defaultDesc = '';
      if (serviceType === 'send_money') {
        defaultDesc = language === 'ur'
          ? `رقم بھیجی بذریعہ ${getAccountName(accountId, language)} (کمیشن: Rs. ${calculatedValues.comm})`
          : `Send Money via ${getAccountName(accountId, language)} (Comm: Rs. ${calculatedValues.comm})`;
      } else {
        defaultDesc = language === 'ur'
          ? `کیش نکلوایا بذریعہ ${getAccountName(accountId, language)} (کمیشن: Rs. ${calculatedValues.comm})`
          : `Cash Withdrawal via ${getAccountName(accountId, language)} (Comm: Rs. ${calculatedValues.comm})`;
      }

      const txToSave: Transaction = {
        id: txId,
        date: date || getTodayDateString(),
        time: time || getCurrentTimeString(),
        timestamp,
        type: 'IN', // Counts commission as shop income
        amount: serviceType === 'send_money' ? calculatedValues.sent : calculatedValues.received,
        accountId, // Digital account: EasyPaisa, JazzCash, or Bank
        category: activeCategory,
        description: description.trim() || defaultDesc,
        reference: reference.trim() || undefined,
        customerName: customerName.trim() || undefined,
        customerPhone: customerPhone.trim() || undefined,
        serviceType,
        principalAmount: serviceType === 'send_money' ? calculatedValues.sent : calculatedValues.paid,
        amountSent: serviceType === 'send_money' ? calculatedValues.sent : undefined,
        cashReceived: serviceType === 'send_money' ? calculatedValues.received : undefined,
        amountReceived: serviceType === 'cash_withdrawal' ? calculatedValues.received : undefined,
        cashPaid: serviceType === 'cash_withdrawal' ? calculatedValues.paid : undefined,
        commissionAmount: calculatedValues.comm,
        commissionRatePerThousand: currentRate,
      };

      await onSave(txToSave);
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Error saving transaction');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  const digitalAccounts = accounts.filter(
    (a) => a.id === 'easypaisa' || a.id === 'jazzcash' || a.id === 'bank'
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
      <div className="bg-white w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl shadow-2xl max-h-[94vh] flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom duration-200">
        
        {/* HEADER */}
        <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
              serviceType === 'send_money' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
            }`}>
              {serviceType === 'send_money' ? <Send className="w-5 h-5" /> : <ArrowDownToLine className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-800">
                {editingTransaction ? t('editTransactionCommTitle') : (serviceType === 'send_money' ? t('sendMoney') : t('cashWithdrawal'))}
              </h3>
              <p className="text-[11px] text-slate-500">
                {t('universalCommissionRates')} • Rs. {currentRate} {t('perThousandUnit')}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200 hover:bg-slate-300 text-slate-600 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* BODY */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {error && (
            <div className="p-3 bg-red-50 text-red-700 text-xs rounded-xl border border-red-200 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* STEP 1: INPUT FORM */}
          {step === 'input' && (
            <form onSubmit={handleProceedToReview} className="space-y-4">
              {/* Service Type Switcher */}
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl">
                <button
                  type="button"
                  onClick={() => {
                    setServiceType('send_money');
                    handleResetToAutoRate();
                  }}
                  className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                    serviceType === 'send_money'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Send className="w-4 h-4" />
                  <span>{t('sendMoney')}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setServiceType('cash_withdrawal');
                    handleResetToAutoRate();
                  }}
                  className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                    serviceType === 'cash_withdrawal'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <ArrowDownToLine className="w-4 h-4" />
                  <span>{t('cashWithdrawal')}</span>
                </button>
              </div>

              {/* 1. Account Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  {t('paymentAccountLabel')}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {digitalAccounts.map((acc) => {
                    const isSelected = accountId === acc.id;
                    return (
                      <button
                        key={acc.id}
                        type="button"
                        disabled={lockAccountId && accountId !== acc.id}
                        onClick={() => setAccountId(acc.id)}
                        className={`p-2.5 rounded-xl border text-left transition-all relative flex flex-col justify-between ${
                          isSelected
                            ? 'border-emerald-600 bg-emerald-50/60 ring-2 ring-emerald-500/20'
                            : 'border-slate-200 bg-white hover:bg-slate-50'
                        } ${lockAccountId && accountId !== acc.id ? 'opacity-40 cursor-not-allowed' : ''}`}
                      >
                        <div className="flex items-center gap-1.5">
                          {acc.id === 'easypaisa' && <Smartphone className="w-4 h-4 text-green-600" />}
                          {acc.id === 'jazzcash' && <Flame className="w-4 h-4 text-red-600" />}
                          {acc.id === 'bank' && <Building2 className="w-4 h-4 text-blue-600" />}
                          <span className="font-bold text-xs text-slate-800 truncate">
                            {getAccountName(acc.id, language)}
                          </span>
                        </div>
                        <div className="text-[11px] font-mono text-slate-500 mt-1">
                          {formatPKR(acc.currentBalance, language)}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Category Indicator: Selected option ke mutabiq sirf usi ki relevant category show ho */}
              <div className="flex items-center justify-between px-3 py-2 bg-slate-50 rounded-xl border border-slate-200">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
                  <Tag className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{t('activeCategory')}:</span>
                </div>
                <span className="text-xs font-black text-emerald-800 bg-white px-2.5 py-0.5 rounded-lg border border-slate-200 shadow-2xs">
                  {getCategoryLabel(activeCategory, language, accountId)}
                </span>
              </div>

              {/* 2. Primary Accounting Inputs */}
              {serviceType === 'send_money' ? (
                /* SEND MONEY FIELDS */
                <div className="space-y-3 p-3.5 bg-emerald-50/50 rounded-2xl border border-emerald-100">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-emerald-950 flex items-center gap-1">
                      <Send className="w-3.5 h-3.5 text-emerald-700" />
                      <span>{t('amountSentToCustomer')}</span>
                    </span>
                    <span className="text-[10px] text-emerald-800 font-medium">Wallet -</span>
                  </div>

                  <input
                    type="number"
                    step="any"
                    min="1"
                    required
                    placeholder="1000"
                    value={amountSent}
                    onChange={(e) => handleAmountSentChange(e.target.value)}
                    className="w-full p-2.5 bg-white border border-emerald-200 rounded-xl text-lg font-black text-slate-900 focus:ring-2 focus:ring-emerald-500"
                  />

                  {/* Quick Chips */}
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
                    {[1000, 2000, 5000, 10000, 25000].map((inc) => (
                      <button
                        key={inc}
                        type="button"
                        onClick={() => handleQuickAdd(inc)}
                        className="px-2 py-0.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 font-bold rounded-lg text-[10px] whitespace-nowrap active:scale-95"
                      >
                        +{inc.toLocaleString()}
                      </button>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-emerald-200/60">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-bold text-slate-800 flex items-center gap-1">
                        <Banknote className="w-3.5 h-3.5 text-emerald-700" />
                        <span>{t('cashReceivedFromCustomer')}</span>
                      </span>
                      <span className="text-[10px] text-emerald-800 font-medium">Cash +</span>
                    </div>

                    <input
                      type="number"
                      step="any"
                      min="1"
                      required
                      placeholder="1010"
                      value={cashReceived}
                      onChange={(e) => handleCashReceivedChange(e.target.value)}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-lg font-black text-emerald-800 focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>
              ) : (
                /* CASH WITHDRAWAL FIELDS */
                <div className="space-y-3 p-3.5 bg-blue-50/50 rounded-2xl border border-blue-100">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-blue-950 flex items-center gap-1">
                      <Banknote className="w-3.5 h-3.5 text-blue-700" />
                      <span>{t('cashPaidToCustomer')}</span>
                    </span>
                    <span className="text-[10px] text-rose-700 font-medium">Cash -</span>
                  </div>

                  <input
                    type="number"
                    step="any"
                    min="1"
                    required
                    placeholder="1000"
                    value={cashPaid}
                    onChange={(e) => handleCashPaidChange(e.target.value)}
                    className="w-full p-2.5 bg-white border border-blue-200 rounded-xl text-lg font-black text-slate-900 focus:ring-2 focus:ring-blue-500"
                  />

                  {/* Quick Chips */}
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
                    {[1000, 2000, 5000, 10000, 25000].map((inc) => (
                      <button
                        key={inc}
                        type="button"
                        onClick={() => handleQuickAdd(inc)}
                        className="px-2 py-0.5 bg-blue-100 hover:bg-blue-200 text-blue-800 font-bold rounded-lg text-[10px] whitespace-nowrap active:scale-95"
                      >
                        +{inc.toLocaleString()}
                      </button>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-blue-200/60">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-bold text-slate-800 flex items-center gap-1">
                        <ArrowDownToLine className="w-3.5 h-3.5 text-blue-700" />
                        <span>{t('amountReceivedInAccount')}</span>
                      </span>
                      <span className="text-[10px] text-blue-800 font-medium">Wallet +</span>
                    </div>

                    <input
                      type="number"
                      step="any"
                      min="1"
                      required
                      placeholder="1020"
                      value={amountReceived}
                      onChange={(e) => handleAmountReceivedChange(e.target.value)}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-lg font-black text-blue-800 focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              )}

              {/* 3. Auto Commission Formula & Display */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
                <div className="flex items-center justify-between">
                  <div className="text-[11px] font-bold text-slate-700">
                    {serviceType === 'send_money' ? t('commissionFormulaSend') : t('commissionFormulaWithdrawal')}
                  </div>
                  {isCommissionManuallyEdited && (
                    <button
                      type="button"
                      onClick={handleResetToAutoRate}
                      className="text-[10px] text-emerald-700 hover:underline font-bold"
                    >
                      Reset to Auto Rate
                    </button>
                  )}
                </div>

                <div className="flex items-center justify-between pt-1">
                  <div className="text-xs text-slate-600">
                    {t('commissionProfit')}:
                  </div>
                  <div className="font-black text-lg text-emerald-700 font-mono">
                    +{formatPKR(calculatedValues.comm, language)}
                  </div>
                </div>
              </div>

              {/* Change 1 Fields: Customer Name, Customer Phone Number, Reference ID */}
              <div className="space-y-2 pt-1">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {/* Customer Name */}
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 mb-0.5 flex items-center gap-1">
                      <User className="w-3 h-3 text-slate-500" />
                      <span>{t('customerNameLabel')}</span>
                      <span className="text-slate-400 font-normal text-[9px]">({t('optional')})</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Tariq Khan"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    />
                  </div>

                  {/* Customer Phone Number */}
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 mb-0.5 flex items-center gap-1">
                      <Phone className="w-3 h-3 text-emerald-600" />
                      <span>{serviceType === 'send_money' ? t('phoneSentToLabel') : t('phoneReceivedFromLabel')}</span>
                      <span className="text-slate-400 font-normal text-[9px]">({t('optional')})</span>
                    </label>
                    <input
                      type="tel"
                      placeholder="0300-1234567"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
                    />
                  </div>
                </div>

                {/* Reference ID / Slip # */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 mb-0.5 flex items-center gap-1">
                    <Hash className="w-3 h-3 text-slate-500" />
                    <span>{t('refLabel')}</span>
                    <span className="text-slate-400 font-normal text-[9px]">({t('optional')})</span>
                  </label>
                  <input
                    type="text"
                    placeholder="Trx ID / Slip #"
                    value={reference}
                    onChange={(e) => setReference(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center gap-1.5"
                >
                  <span>{language === 'ur' ? 'تفصیلات کی تصدیق کریں' : 'Review & Confirm'}</span>
                  <ArrowRight className="w-4 h-4 rtl:rotate-180" />
                </button>
              </div>
            </form>
          )}

          {/* STEP 2: FEATURE 5 CONFIRMATION SUMMARY */}
          {step === 'confirm' && (
            <div className="space-y-4">
              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-center">
                <div className="inline-flex p-2 bg-emerald-100 rounded-full text-emerald-700 mb-1">
                  <CheckCircle className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-sm text-slate-900">
                  {t('confirmationSummaryTitle')}
                </h4>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  {t('confirmationSummaryDesc')}
                </p>
              </div>

              {/* Transaction Summary Card */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3 text-xs">
                <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                  <span className="text-slate-500">{t('type')}:</span>
                  <span className="font-bold text-slate-900">
                    {serviceType === 'send_money' ? t('sendMoney') : t('cashWithdrawal')}
                  </span>
                </div>

                <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                  <span className="text-slate-500">{t('account')}:</span>
                  <span className="font-bold text-emerald-800">
                    {getAccountName(accountId, language)}
                  </span>
                </div>

                <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                  <span className="text-slate-500">{t('category')}:</span>
                  <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200">
                    {getCategoryLabel(activeCategory, language, accountId)}
                  </span>
                </div>

                {customerName && (
                  <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                    <span className="text-slate-500">{t('customerNameLabel')}:</span>
                    <span className="font-bold text-amber-900">{customerName}</span>
                  </div>
                )}

                {customerPhone && (
                  <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                    <span className="text-slate-500">{serviceType === 'send_money' ? t('phoneSentToLabel') : t('phoneReceivedFromLabel')}:</span>
                    <span className="font-mono font-bold text-emerald-800">{customerPhone}</span>
                  </div>
                )}

                {reference && (
                  <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                    <span className="text-slate-500">{t('refLabel')}:</span>
                    <span className="font-mono font-bold text-slate-800">{reference}</span>
                  </div>
                )}

                {serviceType === 'send_money' ? (
                  <>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-600">{t('amountSentToCustomer')}:</span>
                      <span className="font-bold text-rose-700">-{formatPKR(calculatedValues.sent, language)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-600">{t('cashReceivedFromCustomer')}:</span>
                      <span className="font-bold text-emerald-700">+{formatPKR(calculatedValues.received, language)}</span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-600">{t('cashPaidToCustomer')}:</span>
                      <span className="font-bold text-rose-700">-{formatPKR(calculatedValues.paid, language)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-600">{t('amountReceivedInAccount')}:</span>
                      <span className="font-bold text-emerald-700">+{formatPKR(calculatedValues.received, language)}</span>
                    </div>
                  </>
                )}

                <div className="p-2.5 bg-emerald-100/70 border border-emerald-300 rounded-xl flex justify-between items-center font-bold text-emerald-950">
                  <span>{t('pureProfit')} (Net Commission):</span>
                  <span className="text-base text-emerald-800 font-mono">+{formatPKR(calculatedValues.comm, language)}</span>
                </div>
              </div>

              {/* Balance Updates Preview */}
              <div className="p-3 bg-slate-900 text-white rounded-2xl space-y-2 text-xs">
                <div className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">
                  {language === 'ur' ? 'اکاؤنٹ بیلنس میں فوری تبدیلی' : 'Immediate Balance Updates'}
                </div>
                <div className="flex justify-between items-center text-slate-300 text-xs">
                  <span>{getAccountName(accountId, language)}:</span>
                  <span className={`font-mono font-bold ${calculatedValues.walletImpact >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {calculatedValues.walletImpact >= 0 ? '+' : ''}{formatPKR(calculatedValues.walletImpact, language)}
                  </span>
                </div>
                <div className="flex justify-between items-center text-slate-300 text-xs">
                  <span>{t('accountCash')}:</span>
                  <span className={`font-mono font-bold ${calculatedValues.cashImpact >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {calculatedValues.cashImpact >= 0 ? '+' : ''}{formatPKR(calculatedValues.cashImpact, language)}
                  </span>
                </div>
              </div>

              {/* Confirmation Buttons */}
              <div className="pt-2 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setStep('input')}
                  disabled={isSubmitting}
                  className="px-4 py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-100 rounded-xl flex items-center gap-1.5"
                >
                  <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
                  <span>{t('editBackBtn')}</span>
                </button>

                <button
                  type="button"
                  onClick={handleFinalConfirmSave}
                  disabled={isSubmitting}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center gap-1.5"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>{isSubmitting ? (language === 'ur' ? 'محفوظ ہو رہا ہے...' : 'Saving...') : t('confirmAndSaveBtn')}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
