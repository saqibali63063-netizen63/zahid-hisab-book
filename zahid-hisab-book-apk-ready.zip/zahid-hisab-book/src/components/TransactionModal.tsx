import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  Smartphone,
  CheckCircle,
  HelpCircle,
  Calendar,
  Clock,
  User,
  Truck,
  Hash,
  Lock,
  Phone,
  Tag,
} from 'lucide-react';
import {
  AccountId,
  Customer,
  Supplier,
  Transaction,
  TransactionType,
} from '../types';
import {
  ACCOUNT_DEFINITIONS,
  CATEGORIES,
  formatPKR,
  getAccountBadge,
  getAccountName,
  getCategoryLabel,
  getCurrentTimeString,
  getTodayDateString,
} from '../lib/formatters';
import { useLanguage } from '../context/LanguageContext';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (tx: Transaction) => Promise<void>;
  editingTransaction?: Transaction | null;
  accounts: { id: AccountId; name: string; currentBalance: number }[];
  customers: Customer[];
  suppliers: Supplier[];
  defaultType?: TransactionType;
  defaultCategory?: string;
  defaultAccountId?: AccountId;
  lockAccountId?: boolean;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingTransaction,
  accounts,
  customers,
  suppliers,
  defaultType = 'IN',
  defaultCategory,
  defaultAccountId,
  lockAccountId = false,
}) => {
  const { t, language } = useLanguage();
  const [type, setType] = useState<TransactionType>(defaultType);
  const [accountId, setAccountId] = useState<AccountId>('cash');
  const [toAccountId, setToAccountId] = useState<AccountId>('easypaisa');
  const [category, setCategory] = useState<string>('photocopy');
  const [amount, setAmount] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [reference, setReference] = useState<string>('');
  const [date, setDate] = useState<string>(getTodayDateString());
  const [time, setTime] = useState<string>(getCurrentTimeString());

  // Customer / Supplier links
  const [customerId, setCustomerId] = useState<string>('');
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [supplierId, setSupplierId] = useState<string>('');
  const [supplierName, setSupplierName] = useState<string>('');

  // Mobile Sale specific fields
  const [productName, setProductName] = useState<string>('');
  const [purchasePrice, setPurchasePrice] = useState<string>('');
  const [salePrice, setSalePrice] = useState<string>('');
  const [quantity, setQuantity] = useState<string>('1');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string>('');

  // Reset or populate on open
  useEffect(() => {
    if (editingTransaction) {
      setType(editingTransaction.type);
      setAccountId(editingTransaction.accountId);
      setToAccountId(editingTransaction.toAccountId || 'easypaisa');
      setCategory(editingTransaction.category);
      setAmount(String(editingTransaction.amount));
      setDescription(editingTransaction.description || '');
      setReference(editingTransaction.reference || '');
      setDate(editingTransaction.date);
      setTime(editingTransaction.time);
      setCustomerId(editingTransaction.customerId || '');
      setCustomerName(editingTransaction.customerName || '');
      setCustomerPhone(editingTransaction.customerPhone || '');
      setSupplierId(editingTransaction.supplierId || '');
      setSupplierName(editingTransaction.supplierName || '');
      setProductName(editingTransaction.productName || '');
      setPurchasePrice(editingTransaction.purchasePrice ? String(editingTransaction.purchasePrice) : '');
      setSalePrice(editingTransaction.salePrice ? String(editingTransaction.salePrice) : '');
      setQuantity(editingTransaction.quantity ? String(editingTransaction.quantity) : '1');
    } else {
      const initialAcc = defaultAccountId || 'cash';
      setType(defaultType);
      setAccountId(initialAcc);
      setToAccountId(initialAcc === 'cash' ? 'easypaisa' : 'cash');

      // Determine initial category matching selected option / account
      let initialCat = 'print_photocopy';
      if (defaultCategory) {
        initialCat = defaultCategory === 'photocopy' || defaultCategory === 'printing' ? 'print_photocopy' : defaultCategory;
      } else if (defaultType === 'TRANSFER') {
        initialCat = 'transfer';
      } else if (initialAcc === 'easypaisa') {
        initialCat = defaultType === 'IN' ? 'easypaisa_withdrawal' : 'easypaisa_send_money';
      } else if (initialAcc === 'jazzcash') {
        initialCat = defaultType === 'IN' ? 'jazzcash_withdrawal' : 'jazzcash_send_money';
      } else if (initialAcc === 'bank') {
        initialCat = defaultType === 'IN' ? 'bank_withdrawal' : 'bank_send_money';
      } else {
        initialCat = defaultType === 'IN' ? 'print_photocopy' : 'shop_expenses';
      }

      setCategory(initialCat);
      setAmount('');
      setDescription('');
      setReference('');
      setDate(getTodayDateString());
      setTime(getCurrentTimeString());
      setCustomerId('');
      setCustomerName('');
      setCustomerPhone('');
      setSupplierId('');
      setSupplierName('');
      setProductName('');
      setPurchasePrice('');
      setSalePrice('');
      setQuantity('1');
    }
    setError('');
  }, [editingTransaction, isOpen, defaultType, defaultCategory, defaultAccountId]);

  // Adjust category when type changes
  const handleTypeChange = (newType: TransactionType) => {
    setType(newType);
    if (newType === 'TRANSFER') {
      setCategory('transfer');
    } else if (accountId === 'easypaisa') {
      setCategory(newType === 'IN' ? 'easypaisa_withdrawal' : 'easypaisa_send_money');
    } else if (accountId === 'jazzcash') {
      setCategory(newType === 'IN' ? 'jazzcash_withdrawal' : 'jazzcash_send_money');
    } else if (accountId === 'bank') {
      setCategory(newType === 'IN' ? 'bank_withdrawal' : 'bank_send_money');
    } else {
      if (defaultCategory === 'mobile_sale') {
        setCategory('mobile_sale');
      } else {
        setCategory(newType === 'IN' ? 'print_photocopy' : 'shop_expenses');
      }
    }
  };

  const handleAccountChange = (newAccId: AccountId) => {
    setAccountId(newAccId);
    if (type === 'TRANSFER') return;
    if (newAccId === 'easypaisa') {
      setCategory(type === 'IN' ? 'easypaisa_withdrawal' : 'easypaisa_send_money');
    } else if (newAccId === 'jazzcash') {
      setCategory(type === 'IN' ? 'jazzcash_withdrawal' : 'jazzcash_send_money');
    } else if (newAccId === 'bank') {
      setCategory(type === 'IN' ? 'bank_withdrawal' : 'bank_send_money');
    } else {
      if (defaultCategory === 'mobile_sale') {
        setCategory('mobile_sale');
      } else {
        setCategory(type === 'IN' ? 'print_photocopy' : 'shop_expenses');
      }
    }
  };

  // Sync mobile sale amount
  useEffect(() => {
    if (category === 'mobile_sale' && salePrice && quantity) {
      const totalSale = (parseFloat(salePrice) || 0) * (parseInt(quantity, 10) || 1);
      if (totalSale > 0) {
        setAmount(String(totalSale));
      }
    }
  }, [category, salePrice, quantity]);

  if (!isOpen) return null;

  const pPrice = parseFloat(purchasePrice) || 0;
  const sPrice = parseFloat(salePrice) || 0;
  const qty = parseInt(quantity, 10) || 1;
  const computedGrossProfit = category === 'mobile_sale' ? (sPrice - pPrice) * qty : undefined;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setError(t('errorAmount'));
      return;
    }

    if (type === 'TRANSFER' && accountId === toAccountId) {
      setError(t('errorDifferentAccounts'));
      return;
    }

    if (category === 'mobile_sale') {
      if (!productName.trim()) {
        setError(t('errorMobileName'));
        return;
      }
      if (pPrice <= 0 || sPrice <= 0) {
        setError(t('errorMobilePrice'));
        return;
      }
    }

    setIsSubmitting(true);
    try {
      const txId = editingTransaction ? editingTransaction.id : `tx-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

      const newTx: Transaction = {
        id: txId,
        date: date || getTodayDateString(),
        time: time || getCurrentTimeString(),
        timestamp: new Date(`${date}T${time || '12:00'}:00`).getTime() || Date.now(),
        type,
        amount: numAmount,
        accountId,
        toAccountId: type === 'TRANSFER' ? toAccountId : undefined,
        category,
        description: description.trim() || (category === 'mobile_sale' ? `${productName} (${qty}x)` : getCategoryLabel(category, language, accountId)),
        reference: reference.trim() || undefined,
        customerId: customerId || undefined,
        customerName: customerName.trim() || (customerId ? customers.find((c) => c.id === customerId)?.name : undefined),
        customerPhone: customerPhone.trim() || undefined,
        supplierId: supplierId || undefined,
        supplierName: supplierName.trim() || (supplierId ? suppliers.find((s) => s.id === supplierId)?.name : undefined),
        productName: category === 'mobile_sale' ? productName.trim() : undefined,
        purchasePrice: category === 'mobile_sale' ? pPrice : undefined,
        salePrice: category === 'mobile_sale' ? sPrice : undefined,
        quantity: category === 'mobile_sale' ? qty : undefined,
        grossProfit: category === 'mobile_sale' ? computedGrossProfit : undefined,
        isCreditSettlement: category === 'customer_payment',
        serviceType: editingTransaction?.serviceType,
        principalAmount: editingTransaction?.principalAmount,
        commissionAmount: editingTransaction?.commissionAmount,
        commissionRatePerThousand: editingTransaction?.commissionRatePerThousand,
      };

      await onSave(newTx);
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error saving transaction';
      setError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Change 2: Clean, simplified relevant categories per selected option
  const filteredCategories = useMemo(() => {
    if (type === 'TRANSFER') {
      return CATEGORIES.filter((c) => c.id === 'transfer');
    }

    // Specific category option requested from quick action
    if (defaultCategory === 'print_photocopy' || defaultCategory === 'photocopy' || defaultCategory === 'printing') {
      return CATEGORIES.filter((c) => c.id === 'print_photocopy');
    }
    if (defaultCategory === 'mobile_sale') {
      return CATEGORIES.filter((c) => c.id === 'mobile_sale');
    }

    let relevantIds: string[] = [];

    if (accountId === 'easypaisa') {
      relevantIds = type === 'IN' ? ['easypaisa_withdrawal'] : ['easypaisa_send_money'];
    } else if (accountId === 'jazzcash') {
      relevantIds = type === 'IN' ? ['jazzcash_withdrawal'] : ['jazzcash_send_money'];
    } else if (accountId === 'bank') {
      relevantIds = type === 'IN' ? ['bank_withdrawal'] : ['bank_send_money'];
    } else {
      // Cash in Hand
      if (type === 'IN') {
        relevantIds = ['print_photocopy', 'mobile_sale', 'mobile_accessories', 'customer_payment', 'other_income'];
      } else {
        relevantIds = ['shop_expenses', 'electricity', 'rent', 'paper_toner', 'supplier_payment', 'other_expenses'];
      }
    }

    // Preserve existing category if editing legacy transaction
    if (editingTransaction && !relevantIds.includes(editingTransaction.category)) {
      relevantIds.push(editingTransaction.category);
    }

    return CATEGORIES.filter((c) => relevantIds.includes(c.id));
  }, [type, accountId, defaultCategory, editingTransaction]);

  // Keep category in sync with available relevant categories
  useEffect(() => {
    if (filteredCategories.length > 0) {
      const match = filteredCategories.some((c) => c.id === category);
      if (!match) {
        setCategory(filteredCategories[0].id);
      }
    }
  }, [filteredCategories, category]);

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
      <div className="bg-white w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl shadow-2xl max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div>
            <h3 className="font-bold text-lg text-slate-800">
              {editingTransaction ? t('editTransactionTitle') : t('newTransactionTitle')}
            </h3>
            <p className="text-xs text-slate-500">
              {t('shopDefaultName')}
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200 hover:bg-slate-300 text-slate-600 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* Transaction Type Tabs */}
          <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 rounded-xl">
            <button
              type="button"
              onClick={() => handleTypeChange('IN')}
              className={`py-2 px-2 text-xs font-bold rounded-lg flex items-center justify-center gap-1 transition-all ${
                type === 'IN'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ArrowDownLeft className="w-4 h-4" />
              <span>{t('typeIncome')}</span>
            </button>

            <button
              type="button"
              onClick={() => handleTypeChange('OUT')}
              className={`py-2 px-2 text-xs font-bold rounded-lg flex items-center justify-center gap-1 transition-all ${
                type === 'OUT'
                  ? 'bg-red-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ArrowUpRight className="w-4 h-4" />
              <span>{t('typeExpense')}</span>
            </button>

            <button
              type="button"
              onClick={() => handleTypeChange('TRANSFER')}
              className={`py-2 px-2 text-xs font-bold rounded-lg flex items-center justify-center gap-1 transition-all ${
                type === 'TRANSFER'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ArrowLeftRight className="w-4 h-4" />
              <span>{t('typeTransfer')}</span>
            </button>
          </div>

          {error && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
              <span className="font-bold">{language === 'ur' ? 'غلطی:' : 'Error:'}</span>
              <span>{error}</span>
            </div>
          )}

          {/* Amount Field */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t('amountLabel')}
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 font-bold text-sm rtl:right-0 rtl:left-auto rtl:pr-3.5">
                {t('pkr')}
              </div>
              <input
                type="number"
                step="any"
                min="1"
                required
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className={`w-full pl-12 pr-4 py-3 rounded-xl border text-xl font-bold transition-all focus:outline-hidden focus:ring-2 rtl:pr-12 rtl:pl-4 ${
                  type === 'IN'
                    ? 'border-emerald-300 text-emerald-800 focus:ring-emerald-500'
                    : type === 'OUT'
                    ? 'border-red-300 text-red-800 focus:ring-red-500'
                    : 'border-blue-300 text-blue-800 focus:ring-blue-500'
                }`}
              />
            </div>
          </div>

          {/* Account Selection */}
          {type === 'TRANSFER' ? (
            <div className="grid grid-cols-2 gap-3 p-3 bg-blue-50/60 rounded-xl border border-blue-100">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  {t('sourceAccount')}
                </label>
                <select
                  value={accountId}
                  onChange={(e) => setAccountId(e.target.value as AccountId)}
                  className="w-full text-xs font-medium p-2.5 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  {accounts.map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {getAccountName(acc.id, language)} ({formatPKR(acc.currentBalance, language)})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  {t('destinationAccount')}
                </label>
                <select
                  value={toAccountId}
                  onChange={(e) => setToAccountId(e.target.value as AccountId)}
                  className="w-full text-xs font-medium p-2.5 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  {accounts.map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {getAccountName(acc.id, language)} ({formatPKR(acc.currentBalance, language)})
                    </option>
                  ))}
                </select>
              </div>

              <div className="col-span-2 text-[11px] text-blue-700 bg-blue-100/70 p-2 rounded-lg flex items-start gap-1.5">
                <HelpCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{t('transferAccountingNote')}</span>
              </div>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700">
                  {t('paymentAccountLabel')}
                </label>
                {lockAccountId && (
                  <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    <Lock className="w-2.5 h-2.5" />
                    {t('accountLockedBadge')}
                  </span>
                )}
              </div>

              {lockAccountId ? (
                <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl flex items-center justify-between shadow-xs">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                      <Lock className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-black text-slate-900">
                        {getAccountName(accountId, language)}
                      </div>
                      <div className="text-[10px] text-emerald-800 font-medium">
                        {t('accountLockedNotice')}
                      </div>
                    </div>
                  </div>
                  <span className="text-xs font-black text-emerald-900 bg-white px-2.5 py-1 rounded-lg border border-emerald-200 shadow-2xs">
                    {formatPKR(accounts.find((a) => a.id === accountId)?.currentBalance || 0, language)}
                  </span>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {ACCOUNT_DEFINITIONS.map((acc) => {
                    const isSelected = accountId === acc.id;
                    const accData = accounts.find((a) => a.id === acc.id);
                    return (
                      <button
                        key={acc.id}
                        type="button"
                        onClick={() => handleAccountChange(acc.id)}
                        className={`p-2 rounded-xl border text-start transition-all ${
                          isSelected
                            ? 'border-emerald-600 bg-emerald-50 ring-2 ring-emerald-500/20'
                            : 'border-slate-200 bg-white hover:bg-slate-50'
                        }`}
                      >
                        <div className="text-xs font-bold text-slate-800 truncate">
                          {getAccountBadge(acc.id, language)}
                        </div>
                        <div className="text-[10px] text-slate-500 truncate">
                          {accData ? formatPKR(accData.currentBalance, language) : formatPKR(0, language)}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Change 2: Category Selector - only related category shown */}
          {type !== 'TRANSFER' && (
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t('category')} *
              </label>
              {filteredCategories.length === 1 ? (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-slate-800">
                    <Tag className="w-3.5 h-3.5 text-emerald-700" />
                    <span>{getCategoryLabel(filteredCategories[0].id, language, accountId)}</span>
                  </div>
                  <span className="text-[10px] text-emerald-800 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    {t('activeCategory')}
                  </span>
                </div>
              ) : (
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full text-sm font-medium p-2.5 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                >
                  {filteredCategories.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {getCategoryLabel(cat.id, language, accountId)}
                    </option>
                  ))}
                </select>
              )}
            </div>
          )}

          {/* Special Mobile Sale Section */}
          {category === 'mobile_sale' && type === 'IN' && (
            <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-2xl space-y-3">
              <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900">
                <Smartphone className="w-4 h-4 text-amber-600" />
                <span>{t('cat_mobile_sale')}</span>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {t('productNameLabel')}
                </label>
                <input
                  type="text"
                  placeholder="e.g. Infinix Hot 40, Vivo Y17s, Tecno Spark 20"
                  value={productName}
                  onChange={(e) => setProductName(e.target.value)}
                  className="w-full text-xs p-2 bg-white border border-amber-300 rounded-lg focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[10px] font-semibold text-slate-600 mb-0.5">
                    {t('purchasePriceLabel')}
                  </label>
                  <input
                    type="number"
                    placeholder="0"
                    value={purchasePrice}
                    onChange={(e) => setPurchasePrice(e.target.value)}
                    className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-semibold text-slate-600 mb-0.5">
                    {t('salePriceLabel')}
                  </label>
                  <input
                    type="number"
                    placeholder="0"
                    value={salePrice}
                    onChange={(e) => setSalePrice(e.target.value)}
                    className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg font-semibold text-emerald-800"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-semibold text-slate-600 mb-0.5">
                    {t('quantityLabel')}
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg text-center"
                  />
                </div>
              </div>

              {computedGrossProfit !== undefined && (
                <div className="flex items-center justify-between p-2.5 bg-emerald-100/80 border border-emerald-300 rounded-xl text-xs">
                  <span className="font-semibold text-emerald-900">
                    {t('grossProfitLabel')}
                  </span>
                  <span
                    className={`font-black text-sm ${
                      computedGrossProfit >= 0 ? 'text-emerald-700' : 'text-red-600'
                    }`}
                  >
                    {formatPKR(computedGrossProfit, language)}
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Customer Link */}
          {type === 'IN' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                  <User className="w-3.5 h-3.5 text-slate-400" />
                  <span>{t('customerNameLabel')}</span>
                </label>
                <span className="text-[10px] text-slate-400">{t('optional')}</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <select
                  value={customerId}
                  onChange={(e) => {
                    const selId = e.target.value;
                    setCustomerId(selId);
                    const cust = customers.find((c) => c.id === selId);
                    if (cust) {
                      setCustomerName(cust.name);
                      if (cust.phone) setCustomerPhone(cust.phone);
                    }
                  }}
                  className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-xl"
                >
                  <option value="">{t('selectExistingCustomer')}</option>
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({formatPKR(c.balance, language)})
                    </option>
                  ))}
                </select>

                <input
                  type="text"
                  placeholder={t('writeNewName')}
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-xl"
                />
              </div>

              {/* Customer Phone */}
              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-0.5 flex items-center gap-1">
                  <Phone className="w-3 h-3 text-emerald-600" />
                  <span>{t('customerPhoneLabel')}</span>
                  <span className="text-[9px] text-slate-400 font-normal">({t('optional')})</span>
                </label>
                <input
                  type="tel"
                  placeholder="0300-1234567"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-xl font-mono"
                />
              </div>
            </div>
          )}

          {/* Supplier Link */}
          {type === 'OUT' && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-slate-400" />
                  <span>{t('supplierNameLabel')}</span>
                </label>
                <span className="text-[10px] text-slate-400">{t('optional')}</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <select
                  value={supplierId}
                  onChange={(e) => {
                    const selId = e.target.value;
                    setSupplierId(selId);
                    const supp = suppliers.find((s) => s.id === selId);
                    if (supp) setSupplierName(supp.name);
                  }}
                  className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-xl"
                >
                  <option value="">{t('selectExistingSupplier')}</option>
                  {suppliers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({formatPKR(s.payable, language)})
                    </option>
                  ))}
                </select>

                <input
                  type="text"
                  placeholder={t('writeNewName')}
                  value={supplierName}
                  onChange={(e) => setSupplierName(e.target.value)}
                  className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-xl"
                />
              </div>
            </div>
          )}

          {/* Description & Reference */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t('descriptionLabel')}
              </label>
              <input
                type="text"
                placeholder={language === 'ur' ? 'تفصیل درج کریں...' : 'e.g. Photocopies, charger, bill...'}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Hash className="w-3 h-3 text-slate-400" />
                <span>{t('refLabel')}</span>
              </label>
              <input
                type="text"
                placeholder="Slip # 104, IMEI..."
                value={reference}
                onChange={(e) => setReference(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-xl"
              />
            </div>
          </div>

          {/* Date & Time */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>{t('date')}</span>
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>{t('time')}</span>
              </label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-xl"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
            >
              {t('cancel')}
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className={`px-6 py-2.5 text-xs font-bold text-white rounded-xl shadow-md active:scale-95 transition-all flex items-center gap-1.5 ${
                type === 'IN'
                  ? 'bg-emerald-600 hover:bg-emerald-700'
                  : type === 'OUT'
                  ? 'bg-red-600 hover:bg-red-700'
                  : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              <CheckCircle className="w-4 h-4" />
              <span>{isSubmitting ? t('savingTransaction') : t('saveTransactionBtn')}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
