import React from 'react';
import { Lock, ShieldCheck, WifiOff, Store, Languages } from 'lucide-react';
import { ShopSettings } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface HeaderProps {
  settings: ShopSettings;
  onLockApp: () => void;
  onOpenSettings: () => void;
}

export const Header: React.FC<HeaderProps> = ({ settings, onLockApp, onOpenSettings }) => {
  const { language, toggleLanguage, t } = useLanguage();

  return (
    <header className="bg-emerald-800 text-white shadow-md sticky top-0 z-30 border-b border-emerald-900">
      <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3 cursor-pointer" onClick={onOpenSettings}>
          <div className="w-10 h-10 rounded-xl bg-emerald-700 border border-emerald-600 flex items-center justify-center shadow-inner text-amber-300">
            <Store className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-base sm:text-lg tracking-tight leading-none text-white">
                {settings.shopName || (language === 'ur' ? 'ذاہد موبائلز اینڈ فوٹو اسٹیٹ' : 'Zahid Mobiles and Photo State')}
              </h1>
            </div>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xs font-medium text-emerald-200">
                {language === 'ur' ? 'ذاہد حساب بک' : 'Zahid Hisab Book'}
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-900/80 text-emerald-300 px-1.5 py-0.5 rounded-full border border-emerald-700">
                <WifiOff className="w-2.5 h-2.5" />
                {t('offlineStatus')}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Prominent Language Switch Button */}
          <button
            onClick={toggleLanguage}
            title={language === 'en' ? 'اردو زبان منتخب کریں' : 'Switch to English'}
            className="flex items-center gap-1.5 text-xs font-black bg-amber-400 hover:bg-amber-300 text-emerald-950 px-3 py-1.5 rounded-xl shadow-sm active:scale-95 transition-all border border-amber-300"
          >
            <Languages className="w-4 h-4" />
            <span>{language === 'en' ? 'اردو' : 'English'}</span>
          </button>

          {settings.pinEnabled && (
            <button
              onClick={onLockApp}
              title={t('lockApp')}
              className="flex items-center gap-1 text-xs bg-emerald-900 hover:bg-emerald-950 text-emerald-200 px-2.5 py-1.5 rounded-xl border border-emerald-700 active:scale-95 transition-all shadow-sm"
            >
              <Lock className="w-3.5 h-3.5 text-amber-300" />
              <span className="hidden sm:inline">{t('lockApp')}</span>
            </button>
          )}

          <div className="hidden md:flex items-center gap-1 text-xs text-emerald-200 bg-emerald-900/60 px-2.5 py-1.5 rounded-xl border border-emerald-700/60">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>IndexedDB</span>
          </div>
        </div>
      </div>
    </header>
  );
};
