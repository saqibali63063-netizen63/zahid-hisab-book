import React from 'react';
import { LayoutDashboard, BookOpen, PlusCircle, Users, BarChart3 } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export type TabType = 'dashboard' | 'transactions' | 'khata' | 'reports';

interface BottomNavProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  onOpenAddModal: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onTabChange,
  onOpenAddModal,
}) => {
  const { t, language } = useLanguage();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-30 shadow-lg safe-area-pb">
      <div className="max-w-md mx-auto px-3 py-1.5 flex items-center justify-around">
        {/* Dashboard */}
        <button
          onClick={() => onTabChange('dashboard')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all ${
            activeTab === 'dashboard'
              ? 'text-emerald-700 font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <LayoutDashboard className={`w-5 h-5 ${activeTab === 'dashboard' ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
          <span className="text-[11px] mt-1 tracking-tight leading-none">
            {t('navDashboard')}
          </span>
        </button>

        {/* Transactions */}
        <button
          onClick={() => onTabChange('transactions')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all ${
            activeTab === 'transactions'
              ? 'text-emerald-700 font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <BookOpen className={`w-5 h-5 ${activeTab === 'transactions' ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
          <span className="text-[11px] mt-1 tracking-tight leading-none">
            {t('navTransactions')}
          </span>
        </button>

        {/* Center Prominent Add Button */}
        <button
          onClick={onOpenAddModal}
          className="flex flex-col items-center justify-center -mt-5 group"
          title={t('navAddEntry')}
        >
          <div className="w-13 h-13 rounded-full bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white flex items-center justify-center shadow-lg border-4 border-white transition-transform">
            <PlusCircle className="w-7 h-7 stroke-[2.2]" />
          </div>
          <span className="text-[11px] font-black text-emerald-800 mt-1 tracking-tight leading-none">
            {language === 'ur' ? '+ اندراج' : '+ Add'}
          </span>
        </button>

        {/* Khata / Customer Ledger */}
        <button
          onClick={() => onTabChange('khata')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all ${
            activeTab === 'khata'
              ? 'text-emerald-700 font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className={`w-5 h-5 ${activeTab === 'khata' ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
          <span className="text-[11px] mt-1 tracking-tight leading-none">
            {t('navKhata')}
          </span>
        </button>

        {/* Reports */}
        <button
          onClick={() => onTabChange('reports')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all ${
            activeTab === 'reports'
              ? 'text-emerald-700 font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <BarChart3 className={`w-5 h-5 ${activeTab === 'reports' ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
          <span className="text-[11px] mt-1 tracking-tight leading-none">
            {t('navReports')}
          </span>
        </button>
      </div>
    </nav>
  );
};
