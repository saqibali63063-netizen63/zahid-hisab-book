import React from 'react';
import {
  Banknote,
  Smartphone,
  Flame,
  Building2,
  TrendingUp,
  TrendingDown,
  Sparkles,
  ArrowLeftRight,
  ArrowDownLeft,
  ArrowUpRight,
  PlusCircle,
  ChevronRight,
  Send,
  ArrowDownToLine,
  Percent,
  Printer,
  Phone,
} from 'lucide-react';
import { Account, AccountId, CommissionServiceType, Customer, Supplier, Transaction } from '../types';
import {
  ACCOUNT_DEFINITIONS,
  formatDate,
  formatPKR,
  formatTime,
  getAccountBadge,
  getAccountName,
  getCategoryLabel,
  getTodayDateString,
} from '../lib/formatters';
import { useLanguage } from '../context/LanguageContext';

interface DashboardProps {
  accounts: Account[];
  transactions: Transaction[];
  customers: Customer[];
  suppliers: Supplier[];
  onOpenAddModal: (type?: 'IN' | 'OUT' | 'TRANSFER', category?: string) => void;
  onOpenTransferModal: (fromAcc?: AccountId) => void;
  onOpenCommissionModal?: (serviceType?: CommissionServiceType, accountId?: AccountId) => void;
  onSelectTransaction: (tx: Transaction) => void;
  onNavigateToTab: (tab: 'transactions' | 'khata' | 'reports') => void;
  onSelectAccount: (accountId: AccountId) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  accounts,
  transactions,
  customers,
  suppliers,
  onOpenAddModal,
  onOpenTransferModal,
  onOpenCommissionModal,
  onSelectTransaction,
  onNavigateToTab,
  onSelectAccount,
}) => {
  const { t, language } = useLanguage();
  const todayStr = getTodayDateString();

  // Filter today's transactions
  const todayTxs = transactions.filter((t) => t.date === todayStr);

  // Today's Commission Calculations
  let todaySendMoneyComm = 0;
  let todayWithdrawComm = 0;
  let todayEasyPaisaComm = 0;
  let todayJazzCashComm = 0;
  let todayBankComm = 0;

  let todayIncome = 0;
  let todayExpenses = 0;
  let todayGrossProfit = 0;

  for (const t of todayTxs) {
    if (t.serviceType) {
      // Send Money or Cash Withdrawal: ONLY commission counts as income/profit!
      const comm = Number(t.commissionAmount) || 0;
      todayIncome += comm;
      todayGrossProfit += comm;

      if (t.serviceType === 'send_money') todaySendMoneyComm += comm;
      else if (t.serviceType === 'cash_withdrawal') todayWithdrawComm += comm;

      if (t.accountId === 'easypaisa') todayEasyPaisaComm += comm;
      else if (t.accountId === 'jazzcash') todayJazzCashComm += comm;
      else if (t.accountId === 'bank') todayBankComm += comm;
    } else if (t.category === 'easypaisa_commission' || t.category === 'jazzcash_commission' || t.category === 'bank_commission') {
      const comm = Number(t.amount) || 0;
      todayIncome += comm;
      todayGrossProfit += comm;
      if (t.accountId === 'easypaisa' || t.category === 'easypaisa_commission') todayEasyPaisaComm += comm;
      else if (t.accountId === 'jazzcash' || t.category === 'jazzcash_commission') todayJazzCashComm += comm;
      else if (t.accountId === 'bank' || t.category === 'bank_commission') todayBankComm += comm;
    } else if (t.type === 'IN') {
      const amt = Number(t.amount) || 0;
      todayIncome += amt;
      if (t.category === 'mobile_sale') {
        todayGrossProfit += Number(t.grossProfit) || 0;
      } else if (t.category === 'customer_payment') {
        // Debt settlement
      } else {
        todayGrossProfit += amt;
      }
    } else if (t.type === 'OUT') {
      const amt = Number(t.amount) || 0;
      if (t.category !== 'supplier_payment') {
        todayExpenses += amt;
      }
    }
  }

  const todayCombinedComm = todayEasyPaisaComm + todayJazzCashComm + todayBankComm;
  const todayNetProfit = todayGrossProfit - todayExpenses;

  // Receivables & Payables
  const totalReceivables = customers.reduce((sum, c) => sum + Math.max(0, c.balance || 0), 0);
  const totalPayables = suppliers.reduce((sum, s) => sum + Math.max(0, s.payable || 0), 0);

  // Recent 6 transactions
  const recentTxs = transactions.slice(0, 6);

  const getAccountIcon = (id: AccountId) => {
    switch (id) {
      case 'cash':
        return <Banknote className="w-5 h-5 text-emerald-600" />;
      case 'easypaisa':
        return <Smartphone className="w-5 h-5 text-green-600" />;
      case 'jazzcash':
        return <Flame className="w-5 h-5 text-red-600" />;
      case 'bank':
        return <Building2 className="w-5 h-5 text-blue-600" />;
    }
  };

  return (
    <div className="space-y-4 pb-24 pt-2 px-3 sm:px-4 max-w-5xl mx-auto">
      {/* TODAY SUMMARY BANNER */}
      <div className="bg-gradient-to-br from-emerald-900 via-emerald-800 to-slate-900 rounded-3xl p-4 sm:p-5 text-white shadow-xl border border-emerald-700/40 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between mb-3 border-b border-emerald-700/50 pb-2.5">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <h2 className="text-xs sm:text-sm font-semibold tracking-wide text-emerald-100 uppercase">
              {t('todayOverview')}
            </h2>
          </div>
          <span className="text-[11px] text-emerald-200/90 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-700">
            {formatDate(todayStr, language)}
          </span>
        </div>

        {/* 3 Metric Pillars */}
        <div className="grid grid-cols-3 gap-2 text-center pt-1 pb-2">
          {/* Income */}
          <div className="bg-emerald-950/40 rounded-2xl p-2.5 border border-emerald-700/40">
            <div className="flex items-center justify-center gap-1 text-[11px] text-emerald-300 mb-0.5 font-medium">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              <span>{t('todayIncome')}</span>
            </div>
            <div className="text-sm sm:text-lg font-black text-white truncate">
              {formatPKR(todayIncome, language)}
            </div>
          </div>

          {/* Expense */}
          <div className="bg-emerald-950/40 rounded-2xl p-2.5 border border-emerald-700/40">
            <div className="flex items-center justify-center gap-1 text-[11px] text-red-300 mb-0.5 font-medium">
              <TrendingDown className="w-3.5 h-3.5 text-red-400" />
              <span>{t('todayExpenses')}</span>
            </div>
            <div className="text-sm sm:text-lg font-black text-white truncate">
              {formatPKR(todayExpenses, language)}
            </div>
          </div>

          {/* Net Profit */}
          <div className="bg-emerald-950/60 rounded-2xl p-2.5 border border-amber-500/40 shadow-inner">
            <div className="flex items-center justify-center gap-1 text-[11px] text-amber-300 mb-0.5 font-bold">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>{t('todayNetProfit')}</span>
            </div>
            <div
              className={`text-sm sm:text-lg font-black truncate ${
                todayNetProfit >= 0 ? 'text-amber-300' : 'text-red-400'
              }`}
            >
              {formatPKR(todayNetProfit, language)}
            </div>
          </div>
        </div>

        {/* Receivables & Payables mini bar */}
        <div className="mt-3 pt-2.5 border-t border-emerald-700/40 grid grid-cols-2 gap-2 text-xs">
          <div
            onClick={() => onNavigateToTab('khata')}
            className="flex items-center justify-between bg-emerald-950/50 hover:bg-emerald-950/80 px-2.5 py-1.5 rounded-xl cursor-pointer border border-emerald-800 transition-colors"
          >
            <div className="text-[11px] text-slate-300 truncate">
              {t('customerReceivables')}:
            </div>
            <div className="font-bold text-amber-300 text-xs shrink-0">
              {formatPKR(totalReceivables, language)}
            </div>
          </div>

          <div
            onClick={() => onNavigateToTab('khata')}
            className="flex items-center justify-between bg-emerald-950/50 hover:bg-emerald-950/80 px-2.5 py-1.5 rounded-xl cursor-pointer border border-emerald-800 transition-colors"
          >
            <div className="text-[11px] text-slate-300 truncate">
              {t('supplierPayables')}:
            </div>
            <div className="font-bold text-rose-300 text-xs shrink-0">
              {formatPKR(totalPayables, language)}
            </div>
          </div>
        </div>
      </div>

      {/* TODAY'S DIGITAL COMMISSION SUMMARY CARD */}
      <div className="bg-gradient-to-r from-amber-500/10 via-emerald-500/10 to-blue-500/10 border border-amber-200/80 bg-white rounded-2xl p-3.5 shadow-xs space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Percent className="w-4 h-4 text-emerald-700" />
            <span className="font-bold text-xs text-slate-800">
              {t('dailyCommissionSummary')}
            </span>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-slate-500 font-medium">
              {t('todayTotalCommission')}:
            </span>
            <span className="font-black text-emerald-700 text-sm ml-1.5 font-mono">
              +{formatPKR(todayCombinedComm, language)}
            </span>
          </div>
        </div>

        {/* Send Money vs Cash Withdrawal split */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="bg-emerald-50/90 p-2 rounded-xl border border-emerald-200 flex items-center justify-between">
            <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-900">
              <Send className="w-3.5 h-3.5 text-emerald-700" />
              <span>{t('todaySendCommission')}</span>
            </div>
            <div className="font-black text-xs text-emerald-800 font-mono">
              +{formatPKR(todaySendMoneyComm, language)}
            </div>
          </div>

          <div className="bg-blue-50/90 p-2 rounded-xl border border-blue-200 flex items-center justify-between">
            <div className="flex items-center gap-1 text-[11px] font-bold text-blue-900">
              <ArrowDownToLine className="w-3.5 h-3.5 text-blue-700" />
              <span>{t('todayWithdrawCommission')}</span>
            </div>
            <div className="font-black text-xs text-blue-800 font-mono">
              +{formatPKR(todayWithdrawComm, language)}
            </div>
          </div>
        </div>

        {/* 3 Digital Accounts breakdown */}
        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          <div className="bg-green-50/80 p-2 rounded-xl border border-green-200">
            <div className="text-[10px] text-green-700 font-bold truncate">
              EasyPaisa
            </div>
            <div className="font-black text-xs sm:text-sm text-green-900 font-mono mt-0.5">
              +{formatPKR(todayEasyPaisaComm, language)}
            </div>
          </div>

          <div className="bg-red-50/80 p-2 rounded-xl border border-red-200">
            <div className="text-[10px] text-red-700 font-bold truncate">
              JazzCash
            </div>
            <div className="font-black text-xs sm:text-sm text-red-900 font-mono mt-0.5">
              +{formatPKR(todayJazzCashComm, language)}
            </div>
          </div>

          <div className="bg-blue-50/80 p-2 rounded-xl border border-blue-200">
            <div className="text-[10px] text-blue-700 font-bold truncate">
              Bank
            </div>
            <div className="font-black text-xs sm:text-sm text-blue-900 font-mono mt-0.5">
              +{formatPKR(todayBankComm, language)}
            </div>
          </div>
        </div>
      </div>

      {/* QUICK ACTIONS BUTTONS */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
        {/* Send Money Action */}
        <button
          onClick={() => onOpenCommissionModal ? onOpenCommissionModal('send_money') : onOpenAddModal('IN', 'send_money')}
          className="flex flex-col items-center justify-center p-2.5 bg-gradient-to-b from-emerald-50 to-emerald-100 hover:from-emerald-100 hover:to-emerald-200 border border-emerald-300 rounded-2xl shadow-xs active:scale-95 transition-all text-emerald-950 group"
        >
          <div className="w-8 h-8 rounded-xl bg-emerald-700 text-white flex items-center justify-center mb-1 shadow-xs group-hover:scale-105 transition-transform">
            <Send className="w-4 h-4" />
          </div>
          <span className="text-[11px] font-bold tracking-tight text-center">
            {t('sendMoney')}
          </span>
          <span className="text-[9px] text-emerald-700 font-semibold">
            Rs. 10/1k
          </span>
        </button>

        {/* Cash Withdrawal Action */}
        <button
          onClick={() => onOpenCommissionModal ? onOpenCommissionModal('cash_withdrawal') : onOpenAddModal('IN', 'cash_withdrawal')}
          className="flex flex-col items-center justify-center p-2.5 bg-gradient-to-b from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 border border-blue-300 rounded-2xl shadow-xs active:scale-95 transition-all text-blue-950 group"
        >
          <div className="w-8 h-8 rounded-xl bg-blue-700 text-white flex items-center justify-center mb-1 shadow-xs group-hover:scale-105 transition-transform">
            <ArrowDownToLine className="w-4 h-4" />
          </div>
          <span className="text-[11px] font-bold tracking-tight text-center">
            {t('cashWithdrawal')}
          </span>
          <span className="text-[9px] text-blue-700 font-semibold">
            Rs. 20/1k
          </span>
        </button>

        {/* Mobile Sale */}
        <button
          onClick={() => onOpenAddModal('IN', 'mobile_sale')}
          className="flex flex-col items-center justify-center p-2.5 bg-gradient-to-b from-amber-50 to-amber-100 hover:from-amber-100 hover:to-amber-200 border border-amber-300 rounded-2xl shadow-xs active:scale-95 transition-all text-amber-900 group"
        >
          <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center mb-1 shadow-xs group-hover:scale-105 transition-transform">
            <Smartphone className="w-4 h-4" />
          </div>
          <span className="text-[11px] font-bold tracking-tight text-center">
            {t('mobileSaleAction')}
          </span>
          <span className="text-[9px] text-amber-700 font-semibold">
            Phones
          </span>
        </button>

        {/* Services Income */}
        <button
          onClick={() => onOpenAddModal('IN', 'photocopy')}
          className="flex flex-col items-center justify-center p-2.5 bg-gradient-to-b from-teal-50 to-teal-100 hover:from-teal-100 hover:to-teal-200 border border-teal-300 rounded-2xl shadow-xs active:scale-95 transition-all text-teal-900 group"
        >
          <div className="w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center mb-1 shadow-xs group-hover:scale-105 transition-transform">
            <ArrowDownLeft className="w-4 h-4" />
          </div>
          <span className="text-[11px] font-bold tracking-tight text-center">
            {t('incomeAction')}
          </span>
          <span className="text-[9px] text-teal-700 font-semibold">
            Copy/Print
          </span>
        </button>

        {/* Expense */}
        <button
          onClick={() => onOpenAddModal('OUT', 'shop_expenses')}
          className="flex flex-col items-center justify-center p-2.5 bg-gradient-to-b from-rose-50 to-rose-100 hover:from-rose-100 hover:to-rose-200 border border-rose-300 rounded-2xl shadow-xs active:scale-95 transition-all text-rose-900 group"
        >
          <div className="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center mb-1 shadow-xs group-hover:scale-105 transition-transform">
            <ArrowUpRight className="w-4 h-4" />
          </div>
          <span className="text-[11px] font-bold tracking-tight text-center">
            {t('expenseAction')}
          </span>
          <span className="text-[9px] text-rose-700 font-semibold">
            Bill/Rent
          </span>
        </button>

        {/* Transfer */}
        <button
          onClick={() => onOpenTransferModal()}
          className="flex flex-col items-center justify-center p-2.5 bg-gradient-to-b from-indigo-50 to-indigo-100 hover:from-indigo-100 hover:to-indigo-200 border border-indigo-300 rounded-2xl shadow-xs active:scale-95 transition-all text-indigo-900 group"
        >
          <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center mb-1 shadow-xs group-hover:scale-105 transition-transform">
            <ArrowLeftRight className="w-4 h-4" />
          </div>
          <span className="text-[11px] font-bold tracking-tight text-center">
            {t('transferAction')}
          </span>
          <span className="text-[9px] text-indigo-700 font-semibold">
            Wallets
          </span>
        </button>
      </div>

      {/* 4 PAYMENT ACCOUNTS LEDGERS */}
      <div>
        <div className="flex items-center justify-between mb-2 px-1">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600">
            {t('accountsTitle')}
          </h3>
          <button
            onClick={() => onOpenTransferModal()}
            className="text-[11px] font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1"
          >
            <ArrowLeftRight className="w-3.5 h-3.5" />
            <span>{t('transferMoney')}</span>
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {ACCOUNT_DEFINITIONS.map((def) => {
            const acc = accounts.find((a) => a.id === def.id);
            const balance = acc ? acc.currentBalance : 0;
            return (
              <div
                key={def.id}
                onClick={() => onSelectAccount(def.id)}
                className="bg-white rounded-2xl p-3 border border-slate-200 shadow-xs hover:border-emerald-500 hover:shadow-md cursor-pointer active:scale-98 transition-all flex flex-col justify-between group"
                role="button"
                tabIndex={0}
                title={`${getAccountName(def.id, language)}`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="w-8 h-8 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center group-hover:scale-105 transition-transform">
                    {getAccountIcon(def.id)}
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenTransferModal(def.id);
                      }}
                      title={t('transferMoney')}
                      className="p-1 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                    >
                      <ArrowLeftRight className="w-3.5 h-3.5" />
                    </button>
                    <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-emerald-600 group-hover:translate-x-0.5 transition-all rtl:rotate-180" />
                  </div>
                </div>

                <div>
                  <div className="text-xs font-bold text-slate-800 truncate group-hover:text-emerald-800 transition-colors">
                    {getAccountName(def.id, language)}
                  </div>
                  <div className="text-[10px] text-slate-400 mb-1 truncate">
                    {getAccountBadge(def.id, language)}
                  </div>
                  <div className="text-base font-black text-slate-900 tracking-tight">
                    {formatPKR(balance, language)}
                  </div>
                  <div className="text-[10px] text-emerald-700 font-bold mt-1 flex items-center gap-0.5 opacity-90 group-hover:opacity-100">
                    <span>{t('viewLedger')}</span>
                    <span className="rtl:rotate-180">→</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* RECENT TRANSACTIONS */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-3.5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-xs sm:text-sm text-slate-800">
              {t('recentTransactions')}
            </h3>
            <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-semibold">
              {transactions.length} {t('records')}
            </span>
          </div>

          <button
            onClick={() => onNavigateToTab('transactions')}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-900 flex items-center gap-0.5"
          >
            <span>{t('viewFullRegister')}</span>
            <ChevronRight className="w-4 h-4 rtl:rotate-180" />
          </button>
        </div>

        {recentTxs.length === 0 ? (
          <div className="p-8 text-center text-slate-400">
            <PlusCircle className="w-10 h-10 mx-auto text-slate-300 mb-2 stroke-[1.5]" />
            <p className="text-xs font-semibold text-slate-600">
              {t('noTransactionsYet')}
            </p>
            <p className="text-[11px] text-slate-400 mt-1">
              {t('noTransactionsSub')}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {recentTxs.map((tItem) => {
              const isIn = tItem.type === 'IN';
              const isOut = tItem.type === 'OUT';
              const isTransfer = tItem.type === 'TRANSFER';
              const isCommService = Boolean(tItem.serviceType);

              return (
                <div
                  key={tItem.id}
                  onClick={() => onSelectTransaction(tItem)}
                  className="p-3 sm:px-4 hover:bg-slate-50 transition-colors cursor-pointer flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                        isCommService
                          ? tItem.serviceType === 'send_money'
                            ? 'bg-emerald-50 text-emerald-600 border border-emerald-200'
                            : 'bg-blue-50 text-blue-600 border border-blue-200'
                          : isIn
                          ? 'bg-emerald-50 text-emerald-600 border border-emerald-200'
                          : isOut
                          ? 'bg-rose-50 text-rose-600 border border-rose-200'
                          : 'bg-blue-50 text-blue-600 border border-blue-200'
                      }`}
                    >
                      {tItem.serviceType === 'send_money' && <Send className="w-5 h-5" />}
                      {tItem.serviceType === 'cash_withdrawal' && <ArrowDownToLine className="w-5 h-5" />}
                      {!tItem.serviceType && isIn && <ArrowDownLeft className="w-5 h-5" />}
                      {!tItem.serviceType && isOut && <ArrowUpRight className="w-5 h-5" />}
                      {!tItem.serviceType && isTransfer && <ArrowLeftRight className="w-5 h-5" />}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-bold text-slate-800 truncate">
                          {tItem.description || getCategoryLabel(tItem.category, language)}
                        </span>
                        {tItem.commissionAmount !== undefined && (
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded-full font-bold">
                            {t('commission')}: +{formatPKR(tItem.commissionAmount, language)}
                          </span>
                        )}
                        {tItem.grossProfit !== undefined && (
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded-full font-bold">
                            {t('pureProfit')}: {formatPKR(tItem.grossProfit, language)}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-0.5">
                        <span className="font-semibold text-slate-700">
                          {getAccountBadge(tItem.accountId, language)}
                        </span>
                        {tItem.toAccountId && (
                          <>
                            <span className="rtl:rotate-180">→</span>
                            <span className="font-semibold text-blue-700">
                              {getAccountBadge(tItem.toAccountId, language)}
                            </span>
                          </>
                        )}
                        <span>•</span>
                        <span>{formatDate(tItem.date, language)}</span>
                        <span>•</span>
                        <span>{formatTime(tItem.time, language)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div
                      className={`text-sm sm:text-base font-black ${
                        isCommService
                          ? 'text-slate-900 font-mono'
                          : isIn
                          ? 'text-emerald-700'
                          : isOut
                          ? 'text-rose-600'
                          : 'text-blue-700'
                      }`}
                    >
                      {formatPKR(tItem.amount, language)}
                    </div>
                    <div className="text-[10px] text-slate-400 capitalize">
                      {tItem.serviceType
                        ? tItem.serviceType === 'send_money'
                          ? t('sendMoney')
                          : t('cashWithdrawal')
                        : getCategoryLabel(tItem.category, language)}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
