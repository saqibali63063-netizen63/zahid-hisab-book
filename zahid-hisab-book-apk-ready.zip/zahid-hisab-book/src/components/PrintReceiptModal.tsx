import React from 'react';
import { X, Printer, Store, Phone, MapPin, Calendar, Clock, CheckCircle } from 'lucide-react';
import { ShopSettings, Transaction } from '../types';
import { formatDate, formatPKR, formatTime, getAccountName, getCategoryLabel } from '../lib/formatters';
import { useLanguage } from '../context/LanguageContext';

interface PrintReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: Transaction | null;
  settings: ShopSettings;
}

export const PrintReceiptModal: React.FC<PrintReceiptModalProps> = ({
  isOpen,
  onClose,
  transaction,
  settings,
}) => {
  const { t, language } = useLanguage();
  if (!isOpen || !transaction) return null;

  const handlePrint = () => {
    window.print();
  };

  const catLabel = getCategoryLabel(transaction.category, language);

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl overflow-hidden animate-in fade-in duration-150">
        <div className="p-3 bg-slate-100 border-b flex items-center justify-between no-print">
          <span className="text-xs font-bold text-slate-700">{t('receiptPreviewTitle')}</span>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{t('receiptPrintBtn')}</span>
            </button>
            <button
              onClick={onClose}
              className="w-6 h-6 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* PRINTABLE SLIP CONTENT */}
        <div id="printable-slip" className="p-6 bg-white text-slate-900 font-mono text-xs space-y-4">
          {/* Shop Header */}
          <div className="text-center border-b-2 border-dashed border-slate-300 pb-3">
            <h2 className="text-base font-bold font-sans tracking-tight uppercase">
              {settings.shopName || t('shopDefaultName')}
            </h2>
            <p className="text-[10px] text-slate-500 font-sans mt-0.5">
              {language === 'ur'
                ? 'موبائل فونز، سامان اور تمام فوٹو اسٹیٹ سروسز'
                : 'Mobile Phones, Accessories & All Photo State Services'}
            </p>
            {settings.phone && (
              <p className="text-[10px] text-slate-600 font-mono mt-0.5">
                📞 {settings.phone}
              </p>
            )}
            {settings.address && (
              <p className="text-[9px] text-slate-400 font-sans mt-0.5">
                📍 {settings.address}
              </p>
            )}
          </div>

          {/* Slip Meta */}
          <div className="flex justify-between text-[11px] border-b border-dashed border-slate-200 pb-2">
            <div>
              <div>{t('reference')}: {transaction.reference || transaction.id.slice(-6).toUpperCase()}</div>
              <div>{t('date')}: {formatDate(transaction.date, language)}</div>
              <div>{t('time')}: {formatTime(transaction.time, language)}</div>
            </div>
            <div className="text-right">
              <div>{t('type')}: {transaction.type === 'IN' ? t('typeIncome') : transaction.type === 'OUT' ? t('typeExpense') : t('typeTransfer')}</div>
              <div>{t('account')}: {getAccountName(transaction.accountId, language)}</div>
              {transaction.customerName && <div>{t('customerNameLabel')}: {transaction.customerName}</div>}
            </div>
          </div>

          {/* Itemized Table */}
          {transaction.serviceType ? (
            <div className="space-y-2 border-b-2 border-dashed border-slate-300 pb-3">
              <div className="flex justify-between font-bold border-b border-slate-200 pb-1">
                <span>{t('description')}</span>
                <span>{t('amount')}</span>
              </div>

              <div className="flex justify-between pt-1">
                <span className="font-sans font-bold">
                  {transaction.serviceType === 'send_money' ? t('sendMoney') : t('cashWithdrawal')}
                  {' '}({getAccountName(transaction.accountId, language)})
                </span>
                <span className="font-bold">
                  {formatPKR(transaction.principalAmount || transaction.amount, language)}
                </span>
              </div>

              <div className="flex justify-between text-[11px] text-slate-600">
                <span>{t('commissionFee')} ({transaction.commissionRatePerThousand || (transaction.serviceType === 'send_money' ? 10 : 20)}/1k):</span>
                <span>+{formatPKR(transaction.commissionAmount || 0, language)}</span>
              </div>

              {transaction.reference && (
                <div className="text-[10px] text-slate-500">
                  {t('refLabel')}: {transaction.reference}
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-1.5 border-b-2 border-dashed border-slate-300 pb-3">
              <div className="flex justify-between font-bold border-b border-slate-200 pb-1">
                <span>{t('description')}</span>
                <span>{t('amount')}</span>
              </div>

              <div className="flex justify-between pt-1">
                <span className="font-sans font-medium">
                  {transaction.productName || transaction.description || catLabel}
                  {transaction.quantity && transaction.quantity > 1 ? ` (${transaction.quantity}x)` : ''}
                </span>
                <span className="font-bold">{formatPKR(transaction.amount, language)}</span>
              </div>

              {transaction.reference && (
                <div className="text-[10px] text-slate-500">
                  {t('refLabel')}: {transaction.reference}
                </div>
              )}
            </div>
          )}

          {/* Total */}
          <div className="flex justify-between items-center text-sm font-black pt-1">
            <span>
              {transaction.serviceType
                ? (transaction.serviceType === 'send_money'
                    ? (language === 'ur' ? 'کل نقد وصول:' : 'TOTAL CASH RECEIVED:')
                    : (language === 'ur' ? 'کل نقد ادائیگی:' : 'TOTAL CASH PAID:'))
                : `${t('total').toUpperCase()}:`}
            </span>
            <span className="text-base">
              {transaction.serviceType
                ? formatPKR(
                    transaction.serviceType === 'send_money'
                      ? (transaction.principalAmount || transaction.amount) + (transaction.commissionAmount || 0)
                      : (transaction.principalAmount || transaction.amount) - (transaction.commissionAmount || 0),
                    language
                  )
                : formatPKR(transaction.amount, language)}
            </span>
          </div>

          {/* Footer note */}
          <div className="text-center text-[10px] text-slate-500 pt-3 border-t border-dashed border-slate-200">
            <p className="font-sans">{t('thankYouVisit')}</p>
            <p className="text-[8px] text-slate-400 mt-2">
              {t('poweredByOffline')}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
