import React, { useState } from 'react';
import { X, ArrowLeftRight, CheckCircle, HelpCircle } from 'lucide-react';
import { Account, AccountId, Transaction } from '../types';
import {
  formatPKR,
  getAccountName,
  getCurrentTimeString,
  getTodayDateString,
} from '../lib/formatters';
import { useLanguage } from '../context/LanguageContext';

interface AccountTransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  accounts: Account[];
  onTransfer: (tx: Transaction) => Promise<void>;
  initialFromAccount?: AccountId;
}

export const AccountTransferModal: React.FC<AccountTransferModalProps> = ({
  isOpen,
  onClose,
  accounts,
  onTransfer,
  initialFromAccount = 'cash',
}) => {
  const { t, language } = useLanguage();
  const [fromAccount, setFromAccount] = useState<AccountId>(initialFromAccount);
  const [toAccount, setToAccount] = useState<AccountId>(
    initialFromAccount === 'cash' ? 'easypaisa' : 'cash'
  );
  const [amount, setAmount] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string>('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const numAmt = parseFloat(amount);
    if (isNaN(numAmt) || numAmt <= 0) {
      setError(t('errorAmount'));
      return;
    }

    if (fromAccount === toAccount) {
      setError(t('errorDifferentAccounts'));
      return;
    }

    setIsSubmitting(true);
    try {
      const tx: Transaction = {
        id: `transfer-${Date.now()}`,
        date: getTodayDateString(),
        time: getCurrentTimeString(),
        timestamp: Date.now(),
        type: 'TRANSFER',
        amount: numAmt,
        accountId: fromAccount,
        toAccountId: toAccount,
        category: 'transfer',
        description:
          description.trim() ||
          `${getAccountName(fromAccount, language)} → ${getAccountName(toAccount, language)}`,
      };

      await onTransfer(tx);
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Transfer error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden animate-in fade-in duration-200">
        <div className="px-5 py-4 bg-blue-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ArrowLeftRight className="w-5 h-5 text-blue-200" />
            <div>
              <h3 className="font-bold text-base">{t('transferModalTitle')}</h3>
              <p className="text-[11px] text-blue-200">{t('transferModalSubtitle')}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-blue-800 hover:bg-blue-900 text-blue-200 flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {error && (
            <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl font-medium">
              {error}
            </div>
          )}

          {/* Amount */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t('transferAmountLabel')}
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 font-bold text-sm rtl:right-0 rtl:left-auto rtl:pr-3.5">
                {t('pkr')}
              </span>
              <input
                type="number"
                step="any"
                min="1"
                required
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full pl-12 pr-4 py-2.5 rounded-xl border border-blue-300 text-lg font-bold text-blue-900 focus:ring-2 focus:ring-blue-500 rtl:pr-12 rtl:pl-4"
              />
            </div>
          </div>

          {/* From -> To */}
          <div className="grid grid-cols-2 gap-3 p-3 bg-blue-50/50 rounded-xl border border-blue-100">
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                {t('sourceAccount')}
              </label>
              <select
                value={fromAccount}
                onChange={(e) => setFromAccount(e.target.value as AccountId)}
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg font-medium"
              >
                {accounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {getAccountName(acc.id, language)} ({formatPKR(acc.currentBalance, language)})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                {t('destinationAccount')}
              </label>
              <select
                value={toAccount}
                onChange={(e) => setToAccount(e.target.value as AccountId)}
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg font-medium"
              >
                {accounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {getAccountName(acc.id, language)} ({formatPKR(acc.currentBalance, language)})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t('descriptionLabel')}
            </label>
            <input
              type="text"
              placeholder={language === 'ur' ? 'تفصیل...' : 'e.g. Cash drawer to wallet transfer'}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
            />
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-[11px] text-slate-600 flex items-start gap-2">
            <HelpCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <span>{t('transferAccountingNote')}</span>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 active:scale-95 rounded-xl shadow-md flex items-center gap-1.5"
            >
              <CheckCircle className="w-4 h-4" />
              <span>{isSubmitting ? t('transferring') : t('transferButton')}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
