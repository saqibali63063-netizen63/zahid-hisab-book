import React, { useState } from 'react';
import {
  Settings,
  Shield,
  Download,
  Upload,
  RefreshCw,
  FileSpreadsheet,
  Smartphone,
  Save,
  CheckCircle,
  AlertTriangle,
  Lock,
  Unlock,
  KeyRound,
  ExternalLink,
  Copy,
  Info,
  Percent,
  Banknote,
} from 'lucide-react';
import { Account, AccountId, AppBackupData, Customer, ShopSettings, Supplier, Transaction } from '../types';
import { hashPin } from '../lib/security';
import { exportAllData, resetDatabase, restoreAllData, cleanupLegacyDemoData, saveAccountOpeningBalances } from '../lib/db';
import { exportCustomersToCSV, exportTransactionsToCSV } from '../lib/csvExport';
import { formatPKR, getAccountName } from '../lib/formatters';
import { useLanguage } from '../context/LanguageContext';

interface SettingsAndBackupProps {
  settings: ShopSettings;
  accounts: Account[];
  transactions: Transaction[];
  customers: Customer[];
  suppliers: Supplier[];
  onUpdateSettings: (newSettings: ShopSettings) => Promise<void>;
  onRefreshData: () => Promise<void>;
  onLockAppNow: () => void;
}

export const SettingsAndBackup: React.FC<SettingsAndBackupProps> = ({
  settings,
  accounts,
  transactions,
  customers,
  suppliers,
  onUpdateSettings,
  onRefreshData,
  onLockAppNow,
}) => {
  const { t, language } = useLanguage();

  // Shop details form
  const [shopName, setShopName] = useState(settings.shopName);
  const [ownerName, setOwnerName] = useState(settings.ownerName);
  const [phone, setPhone] = useState(settings.phone);
  const [address, setAddress] = useState(settings.address);
  const [isSavingShop, setIsSavingShop] = useState(false);
  const [shopSaveSuccess, setShopSaveSuccess] = useState(false);

  // Universal Commission Rates (EasyPaisa, JazzCash, Bank)
  const [sendMoneyRate, setSendMoneyRate] = useState(String(settings.sendMoneyCommissionRate ?? 10));
  const [cashWithdrawalRate, setCashWithdrawalRate] = useState(String(settings.cashWithdrawalCommissionRate ?? 20));
  const [isSavingCommission, setIsSavingCommission] = useState(false);
  const [commissionSaveSuccess, setCommissionSaveSuccess] = useState(false);

  // Feature 5: Overdraft / Allow Negative Balance
  const [allowNegative, setAllowNegative] = useState(Boolean(settings.allowNegativeBalance));

  // Account Starting / Opening Balances
  const [cashOpening, setCashOpening] = useState(String(accounts.find((a) => a.id === 'cash')?.openingBalance ?? 0));
  const [easypaisaOpening, setEasypaisaOpening] = useState(String(accounts.find((a) => a.id === 'easypaisa')?.openingBalance ?? 0));
  const [jazzcashOpening, setJazzcashOpening] = useState(String(accounts.find((a) => a.id === 'jazzcash')?.openingBalance ?? 0));
  const [bankOpening, setBankOpening] = useState(String(accounts.find((a) => a.id === 'bank')?.openingBalance ?? 0));
  const [isSavingOpening, setIsSavingOpening] = useState(false);
  const [openingSaveSuccess, setOpeningSaveSuccess] = useState(false);

  // PIN security setup
  const [pinEnabled, setPinEnabled] = useState(settings.pinEnabled);
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [pinError, setPinError] = useState('');
  const [pinSuccess, setPinSuccess] = useState('');
  const [isSavingPin, setIsSavingPin] = useState(false);

  // Backup & Restore
  const [isExporting, setIsExporting] = useState(false);
  const [restoreError, setRestoreError] = useState('');
  const [restoreSuccess, setRestoreSuccess] = useState('');
  const [restoreWarningOpen, setRestoreWarningOpen] = useState(false);
  const [pendingRestoreData, setPendingRestoreData] = useState<AppBackupData | null>(null);

  // Android build guide modal / expansion
  const [showAndroidGuide, setShowAndroidGuide] = useState(false);
  const [copiedSnippet, setCopiedSnippet] = useState(false);

  // Handle Save Shop Profile
  const handleSaveShopProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingShop(true);
    try {
      const updated: ShopSettings = {
        ...settings,
        shopName: shopName.trim() || t('shopDefaultName'),
        ownerName: ownerName.trim(),
        phone: phone.trim(),
        address: address.trim(),
      };
      await onUpdateSettings(updated);
      setShopSaveSuccess(true);
      setTimeout(() => setShopSaveSuccess(false), 3000);
    } finally {
      setIsSavingShop(false);
    }
  };

  // Handle Save Universal Commission Rates
  const handleSaveCommissionRates = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingCommission(true);
    try {
      const sRate = parseFloat(sendMoneyRate);
      const wRate = parseFloat(cashWithdrawalRate);
      if (isNaN(sRate) || sRate < 0 || isNaN(wRate) || wRate < 0) {
        return;
      }
      const updated: ShopSettings = {
        ...settings,
        sendMoneyCommissionRate: sRate,
        cashWithdrawalCommissionRate: wRate,
      };
      await onUpdateSettings(updated);
      setCommissionSaveSuccess(true);
      setTimeout(() => setCommissionSaveSuccess(false), 3000);
    } finally {
      setIsSavingCommission(false);
    }
  };

  // Feature 5 & 7: Starting / Opening Balances Handlers
  const handleSaveOpeningBalances = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingOpening(true);
    try {
      await saveAccountOpeningBalances({
        cash: parseFloat(cashOpening) || 0,
        easypaisa: parseFloat(easypaisaOpening) || 0,
        jazzcash: parseFloat(jazzcashOpening) || 0,
        bank: parseFloat(bankOpening) || 0,
      });
      await onRefreshData();
      setOpeningSaveSuccess(true);
      setTimeout(() => setOpeningSaveSuccess(false), 3000);
    } finally {
      setIsSavingOpening(false);
    }
  };

  const handleApplyTestStartingBalances = async () => {
    setCashOpening('30000');
    setEasypaisaOpening('20000');
    setJazzcashOpening('10000');
    setBankOpening('15000');
    setIsSavingOpening(true);
    try {
      await saveAccountOpeningBalances({
        cash: 30000,
        easypaisa: 20000,
        jazzcash: 10000,
        bank: 15000,
      });
      await onRefreshData();
      setOpeningSaveSuccess(true);
      setTimeout(() => setOpeningSaveSuccess(false), 3000);
    } finally {
      setIsSavingOpening(false);
    }
  };

  const handleToggleAllowNegative = async () => {
    const nextVal = !allowNegative;
    setAllowNegative(nextVal);
    await onUpdateSettings({ ...settings, allowNegativeBalance: nextVal });
  };

  // Handle Save PIN Setup
  const handleSavePinSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    setPinError('');
    setPinSuccess('');

    if (!pinEnabled) {
      // Disabling PIN
      setIsSavingPin(true);
      try {
        const updated: ShopSettings = {
          ...settings,
          pinEnabled: false,
          pinHash: undefined,
          pinSalt: undefined,
        };
        await onUpdateSettings(updated);
        setPinSuccess(t('pinDisabledSuccess'));
      } finally {
        setIsSavingPin(false);
      }
      return;
    }

    // Enabling or changing PIN
    if (newPin.length !== 4 || !/^\d{4}$/.test(newPin)) {
      setPinError(t('pinError4Digits'));
      return;
    }

    if (newPin !== confirmPin) {
      setPinError(t('pinErrorMismatch'));
      return;
    }

    setIsSavingPin(true);
    try {
      const { hash, salt } = await hashPin(newPin);
      const updated: ShopSettings = {
        ...settings,
        pinEnabled: true,
        pinHash: hash,
        pinSalt: salt,
      };
      await onUpdateSettings(updated);
      setNewPin('');
      setConfirmPin('');
      setPinSuccess(t('pinSuccessSaved'));
    } finally {
      setIsSavingPin(false);
    }
  };

  // Export Full JSON Backup
  const handleExportBackup = async () => {
    setIsExporting(true);
    try {
      const data = await exportAllData();
      const jsonString = JSON.stringify(data, null, 2);
      const today = new Date().toISOString().slice(0, 10);
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `zahid_hisab_book_backup_${today}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } finally {
      setIsExporting(false);
    }
  };

  // File picker for restoring
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setRestoreError('');
    setRestoreSuccess('');

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content) as AppBackupData;

        // Validation
        if (!parsed.transactions || !Array.isArray(parsed.transactions)) {
          setRestoreError(language === 'ur' ? 'غلط بیک اپ فائل: ٹرانزیکشنز کا ڈیٹا نہیں ملا۔' : 'Invalid Backup File: Transactions data not found.');
          return;
        }

        setPendingRestoreData(parsed);
        setRestoreWarningOpen(true);
      } catch (err) {
        setRestoreError(language === 'ur' ? 'فائل پڑھنے میں غلطی ہوئی۔ درست JSON بیک اپ فائل منتخب کریں۔' : 'Error reading file. Please select a valid JSON backup file.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const confirmRestore = async () => {
    if (!pendingRestoreData) return;
    try {
      await restoreAllData(pendingRestoreData);
      await onRefreshData();
      setRestoreWarningOpen(false);
      setPendingRestoreData(null);
      setRestoreSuccess(language === 'ur' ? 'بیک اپ کامیابی سے بحال ہو گیا ہے!' : 'Backup successfully restored!');
      setTimeout(() => setRestoreSuccess(''), 4000);
    } catch (err: unknown) {
      setRestoreError(err instanceof Error ? err.message : 'Restore failed.');
    }
  };

  // Copy Android build instructions
  const copyAndroidInstructions = () => {
    const text = `# Zahid Hisab Book - Android APK Build Instructions (Capacitor)
# Step 1: Install Capacitor in project directory
npm install @capacitor/core @capacitor/cli @capacitor/android

# Step 2: Initialize Capacitor Android Project
npx cap init "Zahid Hisab Book" "com.zahidmobiles.hisabbook" --web-dir dist

# Step 3: Build Web Production Files
npm run build

# Step 4: Add Android Platform & Copy Web Assets
npx cap add android
npx cap copy android

# Step 5: Open Android Studio to Build Signed/Unsigned APK
npx cap open android

# In Android Studio:
# Click Build -> Build Bundle(s) / APK(s) -> Build APK(s)
# The output APK will be generated at:
# android/app/build/outputs/apk/debug/app-debug.apk
# Install this APK on any Android phone (enable Install Unknown Apps)!`;

    navigator.clipboard.writeText(text);
    setCopiedSnippet(true);
    setTimeout(() => setCopiedSnippet(false), 3000);
  };

  return (
    <div className="space-y-5 pb-24 pt-2 px-3 sm:px-4 max-w-5xl mx-auto">
      {/* HEADER */}
      <div>
        <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
          <Settings className="w-5 h-5 text-emerald-700" />
          <span>{t('settingsTitle')}</span>
        </h2>
        <p className="text-xs text-slate-500">
          {t('settingsSubtitle')}
        </p>
      </div>

      {/* 1. SHOP PROFILE */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs">
        <h3 className="font-bold text-sm text-slate-800 mb-3 flex items-center gap-2">
          <span>{t('shopProfileTitle')}</span>
        </h3>

        <form onSubmit={handleSaveShopProfile} className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                {t('shopNameLabel')}
              </label>
              <input
                type="text"
                required
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                {t('ownerNameLabel')}
              </label>
              <input
                type="text"
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                {t('shopPhoneLabel')}
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-300 rounded-xl font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                {t('shopAddressLabel')}
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            {shopSaveSuccess && (
              <span className="text-xs text-emerald-600 font-bold flex items-center gap-1">
                <CheckCircle className="w-4 h-4" />
                {t('profileSavedSuccess')}
              </span>
            )}
            <div className="ml-auto">
              <button
                type="submit"
                disabled={isSavingShop}
                className="px-5 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl shadow-xs flex items-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                <span>{t('save')}</span>
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* 2. UNIVERSAL COMMISSION RATES (EasyPaisa, JazzCash, Bank Account) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <Percent className="w-5 h-5 text-emerald-700" />
          <div>
            <h3 className="font-bold text-sm text-slate-800">
              {t('universalCommissionRates')}
            </h3>
            <p className="text-[11px] text-slate-500">
              {t('universalCommissionDesc')}
            </p>
          </div>
        </div>

        <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
          <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold">{t('futureTransactionsOnlyNotice')}</span>
            <p className="text-[10px] text-amber-800 mt-0.5">
              {t('onlyCommissionCountsNote')}
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveCommissionRates} className="space-y-3 pt-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Send Money Rate */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <label className="block text-xs font-bold text-slate-700">
                1. {t('sendMoneyRateLabel')} ({t('perThousandUnit')}) *
              </label>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-500">Rs.</span>
                <input
                  type="number"
                  step="any"
                  min="0"
                  required
                  value={sendMoneyRate}
                  onChange={(e) => setSendMoneyRate(e.target.value)}
                  className="w-full text-base font-black text-slate-900 p-2 bg-white border border-slate-300 rounded-lg"
                />
              </div>
              <div className="text-[10px] text-slate-500 pt-1">
                {language === 'ur'
                  ? `مثال: Rs. 1,000 بھیجنے پر = Rs. ${parseFloat(sendMoneyRate) || 0} کمیشن | Rs. 5,000 پر = Rs. ${(parseFloat(sendMoneyRate) || 0) * 5}`
                  : `Example: Rs. 1,000 Send = Rs. ${parseFloat(sendMoneyRate) || 0} | Rs. 5,000 Send = Rs. ${(parseFloat(sendMoneyRate) || 0) * 5}`}
              </div>
            </div>

            {/* Cash Withdrawal Rate */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <label className="block text-xs font-bold text-slate-700">
                2. {t('cashWithdrawalRateLabel')} ({t('perThousandUnit')}) *
              </label>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-500">Rs.</span>
                <input
                  type="number"
                  step="any"
                  min="0"
                  required
                  value={cashWithdrawalRate}
                  onChange={(e) => setCashWithdrawalRate(e.target.value)}
                  className="w-full text-base font-black text-slate-900 p-2 bg-white border border-slate-300 rounded-lg"
                />
              </div>
              <div className="text-[10px] text-slate-500 pt-1">
                {language === 'ur'
                  ? `مثال: Rs. 1,000 نکلوانے پر = Rs. ${parseFloat(cashWithdrawalRate) || 0} کمیشن | Rs. 5,000 پر = Rs. ${(parseFloat(cashWithdrawalRate) || 0) * 5}`
                  : `Example: Rs. 1,000 Withdrawal = Rs. ${parseFloat(cashWithdrawalRate) || 0} | Rs. 5,000 Withdrawal = Rs. ${(parseFloat(cashWithdrawalRate) || 0) * 5}`}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            {commissionSaveSuccess && (
              <span className="text-xs text-emerald-600 font-bold flex items-center gap-1">
                <CheckCircle className="w-4 h-4" />
                {t('commissionRatesSavedMsg')}
              </span>
            )}
            <div className="ml-auto">
              <button
                type="submit"
                disabled={isSavingCommission}
                className="px-5 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl shadow-xs flex items-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                <span>{t('saveCommissionRatesBtn')}</span>
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* 3. ACCOUNT STARTING BALANCES & OVERDRAFT (Features 5 & 7) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2">
              <Banknote className="w-5 h-5 text-emerald-700" />
              <span>{t('accountOpeningBalancesTitle')}</span>
            </h3>
            <p className="text-[11px] text-slate-500">
              {t('accountOpeningBalancesSub')}
            </p>
          </div>
          <button
            type="button"
            onClick={handleApplyTestStartingBalances}
            className="px-3 py-1.5 text-[11px] font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-xl transition-all cursor-pointer"
            title="Set test case balances: Cash Rs. 30,000, EasyPaisa Rs. 20,000, JazzCash Rs. 10,000, Bank Rs. 15,000"
          >
            {language === 'ur'
              ? 'ٹیسٹ بیلنس سیٹ کریں (30K, 20K, 10K, 15K)'
              : 'Set Test Balances (30K, 20K, 10K, 15K)'}
          </button>
        </div>

        <form onSubmit={handleSaveOpeningBalances} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Cash in Hand */}
            <div className="p-3 bg-emerald-50/60 border border-emerald-200 rounded-xl space-y-1">
              <label className="block text-xs font-bold text-emerald-950">
                {t('accountCash')}
              </label>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-slate-500">Rs.</span>
                <input
                  type="number"
                  step="any"
                  value={cashOpening}
                  onChange={(e) => setCashOpening(e.target.value)}
                  className="w-full text-base font-black text-slate-900 p-2 bg-white border border-slate-300 rounded-lg"
                  placeholder="0"
                />
              </div>
              <div className="text-[10px] text-slate-500">
                {language === 'ur' ? 'موجودہ بیلنس:' : 'Current balance:'}{' '}
                <span className="font-bold text-slate-700">
                  {formatPKR(accounts.find((a) => a.id === 'cash')?.currentBalance ?? 0)}
                </span>
              </div>
            </div>

            {/* EasyPaisa Wallet */}
            <div className="p-3 bg-emerald-50/60 border border-emerald-200 rounded-xl space-y-1">
              <label className="block text-xs font-bold text-emerald-950">
                {t('accountEasyPaisa')}
              </label>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-slate-500">Rs.</span>
                <input
                  type="number"
                  step="any"
                  value={easypaisaOpening}
                  onChange={(e) => setEasypaisaOpening(e.target.value)}
                  className="w-full text-base font-black text-slate-900 p-2 bg-white border border-slate-300 rounded-lg"
                  placeholder="0"
                />
              </div>
              <div className="text-[10px] text-slate-500">
                {language === 'ur' ? 'موجودہ بیلنس:' : 'Current balance:'}{' '}
                <span className="font-bold text-slate-700">
                  {formatPKR(accounts.find((a) => a.id === 'easypaisa')?.currentBalance ?? 0)}
                </span>
              </div>
            </div>

            {/* JazzCash Wallet */}
            <div className="p-3 bg-orange-50/60 border border-orange-200 rounded-xl space-y-1">
              <label className="block text-xs font-bold text-orange-950">
                {t('accountJazzCash')}
              </label>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-slate-500">Rs.</span>
                <input
                  type="number"
                  step="any"
                  value={jazzcashOpening}
                  onChange={(e) => setJazzcashOpening(e.target.value)}
                  className="w-full text-base font-black text-slate-900 p-2 bg-white border border-slate-300 rounded-lg"
                  placeholder="0"
                />
              </div>
              <div className="text-[10px] text-slate-500">
                {language === 'ur' ? 'موجودہ بیلنس:' : 'Current balance:'}{' '}
                <span className="font-bold text-slate-700">
                  {formatPKR(accounts.find((a) => a.id === 'jazzcash')?.currentBalance ?? 0)}
                </span>
              </div>
            </div>

            {/* Bank Account */}
            <div className="p-3 bg-blue-50/60 border border-blue-200 rounded-xl space-y-1">
              <label className="block text-xs font-bold text-blue-950">
                {t('accountBank')}
              </label>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-slate-500">Rs.</span>
                <input
                  type="number"
                  step="any"
                  value={bankOpening}
                  onChange={(e) => setBankOpening(e.target.value)}
                  className="w-full text-base font-black text-slate-900 p-2 bg-white border border-slate-300 rounded-lg"
                  placeholder="0"
                />
              </div>
              <div className="text-[10px] text-slate-500">
                {language === 'ur' ? 'موجودہ بیلنس:' : 'Current balance:'}{' '}
                <span className="font-bold text-slate-700">
                  {formatPKR(accounts.find((a) => a.id === 'bank')?.currentBalance ?? 0)}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            {openingSaveSuccess && (
              <span className="text-xs text-emerald-600 font-bold flex items-center gap-1">
                <CheckCircle className="w-4 h-4" />
                {t('openingBalancesSavedSuccess')}
              </span>
            )}
            <div className="ml-auto">
              <button
                type="submit"
                disabled={isSavingOpening}
                className="px-5 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>{t('saveOpeningBalancesBtn')}</span>
              </button>
            </div>
          </div>
        </form>

        {/* Feature 5: Overdraft / Allow Negative Balance Switch */}
        <div className="pt-3 border-t border-slate-200 flex items-center justify-between p-3 bg-slate-50 rounded-xl">
          <div>
            <span className="text-xs font-bold text-slate-800 block">
              {t('allowNegativeBalanceLabel')}
            </span>
            <p className="text-[11px] text-slate-500">
              {t('allowNegativeBalanceSub')}
            </p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={allowNegative}
              onChange={handleToggleAllowNegative}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600" />
          </label>
        </div>
      </div>

      {/* 4. SECURITY & PIN LOCK */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-emerald-700" />
            <div>
              <h3 className="font-bold text-sm text-slate-800">
                {t('securityTitle')}
              </h3>
              <p className="text-[11px] text-slate-500">
                {t('securitySubtitle')}
              </p>
            </div>
          </div>

          {settings.pinEnabled && (
            <button
              onClick={onLockAppNow}
              className="px-3 py-1.5 text-xs font-bold text-amber-900 bg-amber-100 hover:bg-amber-200 rounded-xl border border-amber-300 flex items-center gap-1"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{t('lockAppNowBtn')}</span>
            </button>
          )}
        </div>

        <form onSubmit={handleSavePinSetup} className="space-y-3 pt-1">
          {pinError && (
            <div className="p-2.5 bg-red-50 text-red-700 text-xs rounded-xl border border-red-200">
              {pinError}
            </div>
          )}

          {pinSuccess && (
            <div className="p-2.5 bg-emerald-50 text-emerald-700 text-xs rounded-xl border border-emerald-200 flex items-center gap-1.5 font-bold">
              <CheckCircle className="w-4 h-4" />
              <span>{pinSuccess}</span>
            </div>
          )}

          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div>
              <span className="text-xs font-bold text-slate-800">
                {t('enablePinToggle')}
              </span>
              <p className="text-[10px] text-slate-500">
                {t('enablePinSub')}
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={pinEnabled}
                onChange={(e) => setPinEnabled(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600" />
            </label>
          </div>

          {pinEnabled && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-emerald-50/50 rounded-xl border border-emerald-100">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('newPinLabel')}
                </label>
                <input
                  type="password"
                  maxLength={4}
                  placeholder="1234"
                  value={newPin}
                  onChange={(e) => setNewPin(e.target.value.replace(/[^0-9]/g, ''))}
                  className="w-full text-sm font-bold tracking-widest text-center p-2.5 bg-white border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('confirmPinLabel')}
                </label>
                <input
                  type="password"
                  maxLength={4}
                  placeholder="1234"
                  value={confirmPin}
                  onChange={(e) => setConfirmPin(e.target.value.replace(/[^0-9]/g, ''))}
                  className="w-full text-sm font-bold tracking-widest text-center p-2.5 bg-white border border-slate-300 rounded-xl"
                />
              </div>
            </div>
          )}

          <div className="flex justify-end pt-1">
            <button
              type="submit"
              disabled={isSavingPin}
              className="px-5 py-2 text-xs font-bold text-white bg-slate-800 hover:bg-slate-900 rounded-xl shadow-xs"
            >
              {t('savePinBtn')}
            </button>
          </div>
        </form>
      </div>

      {/* 3. BACKUP AND RESTORE */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs space-y-4">
        <div>
          <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2">
            <Save className="w-5 h-5 text-emerald-700" />
            <span>{t('backupTitle')}</span>
          </h3>
          <p className="text-xs text-slate-500">
            {t('backupSubtitle')}
          </p>
        </div>

        {restoreError && (
          <div className="p-3 bg-red-50 text-red-700 text-xs rounded-xl border border-red-200">
            {restoreError}
          </div>
        )}

        {restoreSuccess && (
          <div className="p-3 bg-emerald-50 text-emerald-700 text-xs rounded-xl border border-emerald-200 font-bold flex items-center gap-1.5">
            <CheckCircle className="w-4 h-4" />
            <span>{restoreSuccess}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Export JSON Button */}
          <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl flex flex-col justify-between">
            <div>
              <div className="font-bold text-xs text-emerald-900 mb-1 flex items-center gap-1.5">
                <Download className="w-4 h-4 text-emerald-700" />
                <span>{t('exportJsonBtn')}</span>
              </div>
              <p className="text-[11px] text-emerald-700 mb-3">
                {t('exportJsonDesc')}
              </p>
            </div>
            <button
              onClick={handleExportBackup}
              disabled={isExporting}
              className="w-full py-2.5 px-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all flex items-center justify-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              <span>{isExporting ? (language === 'ur' ? 'فائل تیار ہو رہی ہے...' : 'Generating...') : t('downloadJsonBtn')}</span>
            </button>
          </div>

          {/* Restore JSON Button */}
          <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-2xl flex flex-col justify-between">
            <div>
              <div className="font-bold text-xs text-amber-900 mb-1 flex items-center gap-1.5">
                <Upload className="w-4 h-4 text-amber-700" />
                <span>{t('restoreJsonTitle')}</span>
              </div>
              <p className="text-[11px] text-amber-800 mb-3">
                {t('restoreJsonDesc')}
              </p>
            </div>
            <label className="w-full py-2.5 px-3 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer text-center">
              <Upload className="w-4 h-4" />
              <span>{t('selectBackupFileBtn')}</span>
              <input
                type="file"
                accept=".json,application/json"
                onChange={handleFileSelect}
                className="hidden"
              />
            </label>
          </div>
        </div>

        {/* CSV EXPORTS */}
        <div className="pt-2 border-t border-slate-100 flex items-center justify-between flex-wrap gap-2 text-xs">
          <span className="font-semibold text-slate-600">
            {t('spreadsheetExports')}
          </span>
          <div className="flex gap-2">
            <button
              onClick={() => exportTransactionsToCSV(transactions)}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl flex items-center gap-1"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>{t('transactionsCsv')}</span>
            </button>

            <button
              onClick={() => exportCustomersToCSV(customers)}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl flex items-center gap-1"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>{t('customerKhataCsv')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4. ANDROID APK PACKAGING GUIDE */}
      <div className="bg-gradient-to-r from-slate-900 to-emerald-950 text-white rounded-2xl p-5 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-800/80 border border-emerald-600 flex items-center justify-center text-emerald-300">
              <Smartphone className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base">
                {t('androidPackagingTitle')}
              </h3>
              <p className="text-xs text-emerald-300">
                {t('androidPackagingSubtitle')}
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowAndroidGuide(!showAndroidGuide)}
            className="px-3 py-1.5 text-xs font-bold bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl transition-all"
          >
            {showAndroidGuide ? t('hideGuideBtn') : t('viewGuideBtn')}
          </button>
        </div>

        {showAndroidGuide && (
          <div className="p-4 bg-slate-800/90 rounded-xl border border-slate-700 space-y-3 text-xs animate-in fade-in">
            <div className="flex items-center justify-between">
              <span className="font-bold text-amber-300">
                Terminal Commands (Android Studio & Capacitor):
              </span>
              <button
                onClick={copyAndroidInstructions}
                className="px-2.5 py-1 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg text-[11px] font-bold flex items-center gap-1"
              >
                <Copy className="w-3 h-3" />
                <span>{copiedSnippet ? 'Copied!' : 'Copy Commands'}</span>
              </button>
            </div>

            <pre className="bg-slate-950 p-3 rounded-lg overflow-x-auto text-[11px] font-mono text-emerald-400 leading-relaxed border border-slate-800" dir="ltr">
{`# 1. Install Capacitor packages:
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. Build the project:
npm run build

# 3. Add Android platform & copy files:
npx cap add android
npx cap copy android

# 4. Open in Android Studio:
npx cap open android

# 5. In Android Studio:
# Go to Menu -> Build -> Build Bundle(s) / APK(s) -> Build APK(s)
# Your APK will be created at:
# android/app/build/outputs/apk/debug/app-debug.apk`}
            </pre>

            <div className="p-2.5 bg-emerald-950/70 border border-emerald-800 rounded-lg text-emerald-200 text-[11px]">
              <strong>{language === 'ur' ? 'خصوصیت:' : 'Feature:'}</strong> {language === 'ur' ? 'یہ ایپ 100% آف لائن بغیر انٹرنیٹ کے مکمل کام کرتی ہے۔' : 'This app works 100% offline without any internet connection.'}
            </div>
          </div>
        )}
      </div>

      {/* 5. DATABASE RESET & SAMPLE DATA */}
      <div className="bg-white rounded-2xl border border-red-200 p-4 shadow-xs">
        <h4 className="font-bold text-xs text-red-700 uppercase tracking-wider mb-1">
          {t('dangerZoneTitle')}
        </h4>
        <p className="text-xs text-slate-500 mb-3">
          {t('dangerZoneDesc')}
        </p>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={async () => {
              const confirmMsg = language === 'ur'
                ? 'کیا آپ ڈیمو ٹرانزیکشنز اور نمونہ بیلنس صاف کرنا چاہتے ہیں؟ (آپ کا اپنا درج شدہ ڈیٹا محفوظ رہے گا)'
                : 'Do you want to clean legacy sample demo data? (Your real entered data will remain safe)';
              if (confirm(confirmMsg)) {
                await cleanupLegacyDemoData();
                await onRefreshData();
                alert(language === 'ur' ? 'ڈیمو ڈیٹا صاف ہو گیا اور تمام کھاتے ری کیلوکولیٹ ہو گئے۔' : 'Demo data cleaned successfully and accounts recalculated.');
              }
            }}
            className="px-3.5 py-2 bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold text-xs rounded-xl flex items-center gap-1.5 border border-amber-300"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{t('purgeDemoDataBtn')}</span>
          </button>

          <button
            onClick={async () => {
              const warnMsg = language === 'ur'
                ? 'خبردار: کیا آپ تمام ریکارڈز ڈیلیٹ کر کے بالکل صفر (Rs. 0) سے شروع کرنا چاہتے ہیں؟'
                : 'WARNING: Are you sure you want to delete all records and reset all accounts to zero (Rs. 0)?';
              if (confirm(warnMsg)) {
                await resetDatabase(false);
                await onRefreshData();
                alert(language === 'ur' ? 'ڈیٹا بیس بالکل صاف ہو گیا اور تمام اکاؤنٹس 0 سے شروع ہو گئے۔' : 'Database cleaned. All accounts reset to Rs. 0.');
              }
            }}
            className="px-3.5 py-2 bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs rounded-xl flex items-center gap-1.5 border border-red-200"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>{t('zeroStateResetBtn')}</span>
          </button>
        </div>
      </div>

      {/* RESTORE WARNING MODAL */}
      {restoreWarningOpen && pendingRestoreData && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl p-5 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-700 mx-auto flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center">
              <h3 className="font-bold text-base text-slate-800">
                {t('restoreWarningTitle')}
              </h3>
              <p className="text-xs text-slate-600 mt-1">
                {t('restoreWarningDesc')}
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl text-xs space-y-1 border border-slate-200">
              <div className="flex justify-between">
                <span className="text-slate-500">{t('restoreBackupDate')}</span>
                <span className="font-semibold text-slate-800">
                  {pendingRestoreData.exportDate ? new Date(pendingRestoreData.exportDate).toLocaleString() : 'Unknown'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">{t('navTransactions')}:</span>
                <span className="font-semibold text-slate-800">
                  {pendingRestoreData.transactions?.length || 0}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">{t('khataCustomerTab')}:</span>
                <span className="font-semibold text-slate-800">
                  {pendingRestoreData.customers?.length || 0}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => {
                  setRestoreWarningOpen(false);
                  setPendingRestoreData(null);
                }}
                className="py-2.5 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl"
              >
                {t('cancel')}
              </button>

              <button
                onClick={confirmRestore}
                className="py-2.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-md"
              >
                {t('restoreConfirmBtn')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
