import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Download,
  Trash2,
  Edit2,
  Calendar,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  Smartphone,
  Copy,
  Printer,
  FileSpreadsheet,
  Plus,
  Receipt,
  X,
  AlertTriangle,
  Send,
  ArrowDownToLine,
  Percent,
} from 'lucide-react';
import { Account, AccountId, Transaction, TransactionType } from '../types';
import {
  ACCOUNT_DEFINITIONS,
  CATEGORIES,
  formatDate,
  formatPKR,
  formatTime,
  getAccountName,
  getCategoryDef,
  getCategoryLabel,
  getTodayDateString,
} from '../lib/formatters';
import { exportTransactionsToCSV } from '../lib/csvExport';
import { useLanguage } from '../context/LanguageContext';

interface TransactionListProps {
  transactions: Transaction[];
  accounts: Account[];
  onOpenAddModal: (type?: TransactionType) => void;
  onEditTransaction: (tx: Transaction) => void;
  onDeleteTransaction: (id: string) => Promise<void>;
  onPrintReceipt: (tx: Transaction) => void;
}

export const TransactionList: React.FC<TransactionListProps> = ({
  transactions,
  accounts,
  onOpenAddModal,
  onEditTransaction,
  onDeleteTransaction,
  onPrintReceipt,
}) => {
  const { t, language } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAccount, setSelectedAccount] = useState<string>('ALL');
  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [dateFilter, setDateFilter] = useState<'ALL' | 'TODAY' | 'YESTERDAY' | 'WEEK' | 'MONTH' | 'CUSTOM'>('ALL');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');

  // Selected transaction for detailed bottom sheet / dialog
  const [viewTx, setViewTx] = useState<Transaction | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Compute date ranges
  const todayStr = getTodayDateString();
  const yesterdayDate = new Date();
  yesterdayDate.setDate(yesterdayDate.getDate() - 1);
  const yStr = `${yesterdayDate.getFullYear()}-${String(yesterdayDate.getMonth() + 1).padStart(2, '0')}-${String(yesterdayDate.getDate()).padStart(2, '0')}`;

  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
  const weekStartStr = `${sevenDaysAgo.getFullYear()}-${String(sevenDaysAgo.getMonth() + 1).padStart(2, '0')}-${String(sevenDaysAgo.getDate()).padStart(2, '0')}`;

  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  const monthStartStr = `${thirtyDaysAgo.getFullYear()}-${String(thirtyDaysAgo.getMonth() + 1).padStart(2, '0')}-${String(thirtyDaysAgo.getDate()).padStart(2, '0')}`;

  const filteredTransactions = useMemo(() => {
    return transactions.filter((t) => {
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchDesc = t.description?.toLowerCase().includes(q);
        const matchCust = t.customerName?.toLowerCase().includes(q);
        const matchSupp = t.supplierName?.toLowerCase().includes(q);
        const matchRef = t.reference?.toLowerCase().includes(q);
        const matchProduct = t.productName?.toLowerCase().includes(q);
        const matchAmt = String(t.amount).includes(q);
        if (!matchDesc && !matchCust && !matchSupp && !matchRef && !matchProduct && !matchAmt) {
          return false;
        }
      }

      // Account
      if (selectedAccount !== 'ALL') {
        if (t.accountId !== selectedAccount && t.toAccountId !== selectedAccount) {
          return false;
        }
      }

      // Type
      if (selectedType !== 'ALL') {
        if (t.type !== selectedType) return false;
      }

      // Category
      if (selectedCategory !== 'ALL') {
        if (t.category !== selectedCategory) return false;
      }

      // Date
      if (dateFilter === 'TODAY') {
        if (t.date !== todayStr) return false;
      } else if (dateFilter === 'YESTERDAY') {
        if (t.date !== yStr) return false;
      } else if (dateFilter === 'WEEK') {
        if (t.date < weekStartStr) return false;
      } else if (dateFilter === 'MONTH') {
        if (t.date < monthStartStr) return false;
      } else if (dateFilter === 'CUSTOM') {
        if (customStartDate && t.date < customStartDate) return false;
        if (customEndDate && t.date > customEndDate) return false;
      }

      return true;
    });
  }, [
    transactions,
    searchQuery,
    selectedAccount,
    selectedType,
    selectedCategory,
    dateFilter,
    customStartDate,
    customEndDate,
    todayStr,
    yStr,
    weekStartStr,
    monthStartStr,
  ]);

  // Aggregate stats for filtered view
  const summary = useMemo(() => {
    let totalIn = 0;
    let totalOut = 0;
    let totalTransfers = 0;
    let totalCommissions = 0;
    filteredTransactions.forEach((t) => {
      if (t.serviceType) {
        const comm = Number(t.commissionAmount) || 0;
        totalCommissions += comm;
        totalIn += comm; // shop profit/income gained
        return;
      }
      const amt = Number(t.amount) || 0;
      if (t.type === 'IN') totalIn += amt;
      else if (t.type === 'OUT') totalOut += amt;
      else if (t.type === 'TRANSFER') totalTransfers += amt;
    });
    return {
      totalIn,
      totalOut,
      netCashflow: totalIn - totalOut,
      totalTransfers,
      totalCommissions,
      count: filteredTransactions.length,
    };
  }, [filteredTransactions]);

  const handleDelete = async (id: string) => {
    setIsDeleting(true);
    try {
      await onDeleteTransaction(id);
      setDeleteConfirmId(null);
      if (viewTx?.id === id) setViewTx(null);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="space-y-4 pb-20 pt-2 px-3 sm:px-4 max-w-5xl mx-auto">
      {/* HEADER & ACTIONS */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <span>{t('transactionsPageTitle')}</span>
            <span className="text-xs bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
              {filteredTransactions.length} {t('records')}
            </span>
          </h2>
          <p className="text-xs text-slate-500">
            {t('transactionsPageSubtitle')}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => exportTransactionsToCSV(filteredTransactions)}
            className="flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 shadow-xs transition-colors"
            title={t('csvExportBtn')}
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>{t('csvExportBtn')}</span>
          </button>

          <button
            onClick={() => onOpenAddModal('IN')}
            className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>{t('navAddEntry')}</span>
          </button>
        </div>
      </div>

      {/* SEARCH AND FILTERS BAR */}
      <div className="bg-white rounded-2xl border border-slate-200 p-3 sm:p-4 shadow-xs space-y-3">
        {/* Search Input */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder={t('searchPlaceholder')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-8 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-emerald-500"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Quick Date Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
          {(
            [
              { id: 'ALL', label: t('all') },
              { id: 'TODAY', label: t('today') },
              { id: 'YESTERDAY', label: t('yesterday') },
              { id: 'WEEK', label: t('thisWeek') },
              { id: 'MONTH', label: t('thisMonth') },
              { id: 'CUSTOM', label: t('customRange') },
            ] as const
          ).map((item) => (
            <button
              key={item.id}
              onClick={() => setDateFilter(item.id)}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap text-xs transition-colors ${
                dateFilter === item.id
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Custom date range inputs */}
        {dateFilter === 'CUSTOM' && (
          <div className="grid grid-cols-2 gap-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
            <div>
              <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                {t('from')} ({t('date')})
              </label>
              <input
                type="date"
                value={customStartDate}
                onChange={(e) => setCustomStartDate(e.target.value)}
                className="w-full p-1.5 bg-white border border-slate-300 rounded-lg text-xs"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                {t('to')} ({t('date')})
              </label>
              <input
                type="date"
                value={customEndDate}
                onChange={(e) => setCustomEndDate(e.target.value)}
                className="w-full p-1.5 bg-white border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </div>
        )}

        {/* Dropdowns Row */}
        <div className="grid grid-cols-3 gap-2">
          {/* Account Filter */}
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
              {t('account')}
            </label>
            <select
              value={selectedAccount}
              onChange={(e) => setSelectedAccount(e.target.value)}
              className="w-full text-xs p-1.5 bg-slate-50 border border-slate-200 rounded-lg font-medium"
            >
              <option value="ALL">{t('all')} ({t('accountsTitle')})</option>
              {ACCOUNT_DEFINITIONS.map((a) => (
                <option key={a.id} value={a.id}>
                  {getAccountName(a.id, language)}
                </option>
              ))}
            </select>
          </div>

          {/* Type Filter */}
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
              {t('type')}
            </label>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full text-xs p-1.5 bg-slate-50 border border-slate-200 rounded-lg font-medium"
            >
              <option value="ALL">{t('all')}</option>
              <option value="IN">{t('typeIncome')}</option>
              <option value="OUT">{t('typeExpense')}</option>
              <option value="TRANSFER">{t('typeTransfer')}</option>
            </select>
          </div>

          {/* Category Filter */}
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
              {t('category')}
            </label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full text-xs p-1.5 bg-slate-50 border border-slate-200 rounded-lg font-medium"
            >
              <option value="ALL">{t('all')}</option>
              {CATEGORIES.map((c) => (
                <option key={c.id} value={c.id}>
                  {getCategoryLabel(c.id, language)}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Summary Ribbon */}
        <div className="pt-2 border-t border-slate-100 grid grid-cols-3 gap-2 text-center text-xs">
          <div className="bg-emerald-50 text-emerald-800 p-2 rounded-xl border border-emerald-100">
            <div className="text-[10px] font-medium text-emerald-600">{t('totalInflow')}</div>
            <div className="font-bold text-sm">+{formatPKR(summary.totalIn, language)}</div>
          </div>
          <div className="bg-rose-50 text-rose-800 p-2 rounded-xl border border-rose-100">
            <div className="text-[10px] font-medium text-rose-600">{t('totalOutflow')}</div>
            <div className="font-bold text-sm">-{formatPKR(summary.totalOut, language)}</div>
          </div>
          <div className="bg-slate-100 text-slate-800 p-2 rounded-xl border border-slate-200">
            <div className="text-[10px] font-medium text-slate-500">{t('netCashflow')}</div>
            <div
              className={`font-bold text-sm ${
                summary.netCashflow >= 0 ? 'text-emerald-700' : 'text-rose-600'
              }`}
            >
              {formatPKR(summary.netCashflow, language)}
            </div>
          </div>
        </div>
      </div>

      {/* TRANSACTIONS LIST */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {filteredTransactions.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-xs font-bold text-slate-600">
              {t('noFilterResults')}
            </p>
            <p className="text-[11px] text-slate-400 mt-1">
              {language === 'ur' ? 'تلاش یا فلٹر تبدیل کریں' : 'Try modifying your search or filter'}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredTransactions.map((tItem) => {
              // Commission service transactions (Send Money / Cash Withdrawal)
              if (tItem.serviceType) {
                const principal = Number(tItem.principalAmount ?? tItem.amount) || 0;
                const comm = Number(tItem.commissionAmount) || 0;
                const isSend = tItem.serviceType === 'send_money';

                return (
                  <div
                    key={tItem.id}
                    onClick={() => setViewTx(tItem)}
                    className="p-3.5 hover:bg-slate-50 transition-colors cursor-pointer flex items-center justify-between gap-3 group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          isSend
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-blue-50 text-blue-700 border border-blue-200'
                        }`}
                      >
                        {isSend ? <Send className="w-5 h-5" /> : <ArrowDownToLine className="w-5 h-5" />}
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-xs font-bold text-slate-800">
                            {isSend ? t('sendMoney') : t('cashWithdrawal')}
                          </span>
                          <span className="text-[10px] bg-amber-100 text-amber-900 border border-amber-300 px-1.5 py-0.2 rounded-full font-bold">
                            {t('commissionEarned')}: +{formatPKR(comm, language)}
                          </span>
                          {tItem.reference && (
                            <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded font-mono">
                              #{tItem.reference}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-1">
                          <span className="font-bold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                            {getAccountName(tItem.accountId, language)}
                          </span>
                          <span className="text-slate-600">
                            {t('principalAmountLabel')}: {formatPKR(principal, language)}
                          </span>
                          {tItem.customerName && (
                            <span className="text-amber-800 font-semibold bg-amber-50 px-1.5 py-0.5 rounded">
                              {tItem.customerName}
                            </span>
                          )}
                          <span>{formatDate(tItem.date, language)}</span>
                          <span>{formatTime(tItem.time, language)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right shrink-0 flex items-center gap-3">
                      <div>
                        <div className="text-sm sm:text-base font-black text-emerald-700">
                          +{formatPKR(comm, language)}
                        </div>
                        <div className="text-[10px] text-slate-400 capitalize font-medium">
                          {t('commissionIncome')}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              }

              const catLabel = getCategoryLabel(tItem.category, language);
              const isIn = tItem.type === 'IN';
              const isOut = tItem.type === 'OUT';
              const isTransfer = tItem.type === 'TRANSFER';

              return (
                <div
                  key={tItem.id}
                  onClick={() => setViewTx(tItem)}
                  className="p-3.5 hover:bg-slate-50 transition-colors cursor-pointer flex items-center justify-between gap-3 group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                        isIn
                          ? 'bg-emerald-50 text-emerald-600 border border-emerald-200'
                          : isOut
                          ? 'bg-rose-50 text-rose-600 border border-rose-200'
                          : 'bg-blue-50 text-blue-600 border border-blue-200'
                      }`}
                    >
                      {isIn && <ArrowDownLeft className="w-5 h-5" />}
                      {isOut && <ArrowUpRight className="w-5 h-5" />}
                      {isTransfer && <ArrowLeftRight className="w-5 h-5" />}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-bold text-slate-800">
                          {tItem.description || catLabel}
                        </span>
                        {tItem.grossProfit !== undefined && (
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded-full font-bold">
                            {t('pureProfit')}: {formatPKR(tItem.grossProfit, language)}
                          </span>
                        )}
                        {tItem.reference && (
                          <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded font-mono">
                            #{tItem.reference}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-1">
                        <span className="font-bold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded">
                          {getAccountName(tItem.accountId, language)}
                        </span>
                        {tItem.toAccountId && (
                          <>
                            <span>→</span>
                            <span className="font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded">
                              {getAccountName(tItem.toAccountId, language)}
                            </span>
                          </>
                        )}
                        {tItem.customerName && (
                          <span className="text-amber-800 font-semibold bg-amber-50 px-1.5 py-0.5 rounded">
                            {tItem.customerName}
                          </span>
                        )}
                        <span>{formatDate(tItem.date, language)}</span>
                        <span>{formatTime(tItem.time, language)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0 flex items-center gap-3">
                    <div>
                      <div
                        className={`text-sm sm:text-base font-black ${
                          isIn
                            ? 'text-emerald-700'
                            : isOut
                            ? 'text-rose-600'
                            : 'text-blue-700'
                        }`}
                      >
                        {isIn ? '+' : isOut ? '-' : ''}
                        {formatPKR(tItem.amount, language)}
                      </div>
                      <div className="text-[10px] text-slate-400 capitalize">
                        {catLabel}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* TRANSACTION DETAILS MODAL */}
      {viewTx && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden animate-in fade-in duration-150">
            {/* Modal Header */}
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-emerald-700" />
                <h3 className="font-bold text-sm text-slate-800">
                  {t('transactionDetailsTitle')}
                </h3>
              </div>
              <button
                onClick={() => setViewTx(null)}
                className="w-7 h-7 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 space-y-4">
              {/* Big Amount Badge */}
              {viewTx.serviceType ? (
                <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200 text-center space-y-2">
                  <div className="text-xs text-emerald-800 font-bold uppercase tracking-wider">
                    {viewTx.serviceType === 'send_money' ? t('sendMoney') : t('cashWithdrawal')}
                  </div>
                  <div className="text-3xl font-black text-emerald-700">
                    +{formatPKR(viewTx.commissionAmount || 0, language)}
                  </div>
                  <div className="text-xs font-semibold text-emerald-900">
                    {t('pureCommissionProfit')}
                  </div>
                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-emerald-200/60 text-xs text-left">
                    <div className="bg-white/80 p-2 rounded-xl border border-emerald-100">
                      <div className="text-[10px] text-slate-500 font-medium">{t('principalAmountLabel')}</div>
                      <div className="font-bold text-slate-900">{formatPKR(viewTx.principalAmount || viewTx.amount, language)}</div>
                    </div>
                    <div className="bg-white/80 p-2 rounded-xl border border-emerald-100">
                      <div className="text-[10px] text-slate-500 font-medium">{t('universalCommissionRate')}</div>
                      <div className="font-bold text-slate-900">Rs. {viewTx.commissionRatePerThousand || (viewTx.serviceType === 'send_money' ? 10 : 20)}/1k</div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center p-4 rounded-2xl bg-slate-50 border border-slate-100">
                  <div className="text-xs text-slate-500 font-semibold mb-1">
                    {viewTx.type === 'IN'
                      ? t('incomeReceived')
                      : viewTx.type === 'OUT'
                      ? t('expensePaid')
                      : t('typeTransfer')}
                  </div>
                  <div
                    className={`text-2xl sm:text-3xl font-black ${
                      viewTx.type === 'IN'
                        ? 'text-emerald-700'
                        : viewTx.type === 'OUT'
                        ? 'text-rose-600'
                        : 'text-blue-700'
                    }`}
                  >
                    {viewTx.type === 'IN' ? '+' : viewTx.type === 'OUT' ? '-' : ''}
                    {formatPKR(viewTx.amount, language)}
                  </div>
                  <div className="text-xs font-bold text-slate-700 mt-1">
                    {getCategoryLabel(viewTx.category, language)}
                  </div>
                </div>
              )}

              {/* Mobile item detail if present */}
              {viewTx.category === 'mobile_sale' && viewTx.productName && (
                <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-xl space-y-2 text-xs">
                  <div className="font-bold text-amber-900 flex items-center gap-1.5">
                    <Smartphone className="w-4 h-4 text-amber-600" />
                    <span>{viewTx.productName}</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-slate-700">
                    <div>
                      <div className="text-[10px] text-slate-500">{t('purchasePriceLabel')}:</div>
                      <div className="font-semibold">{formatPKR(viewTx.purchasePrice || 0, language)}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-500">{t('salePriceLabel')}:</div>
                      <div className="font-semibold">{formatPKR(viewTx.salePrice || 0, language)}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-500">{t('quantityLabel')}:</div>
                      <div className="font-semibold">{viewTx.quantity || 1}</div>
                    </div>
                  </div>
                  {viewTx.grossProfit !== undefined && (
                    <div className="pt-1.5 border-t border-amber-200/80 flex items-center justify-between font-bold text-emerald-800">
                      <span>{t('pureProfit')}:</span>
                      <span className="text-sm">+{formatPKR(viewTx.grossProfit, language)}</span>
                    </div>
                  )}
                </div>
              )}

              {/* Key details list */}
              <div className="space-y-2 text-xs divide-y divide-slate-100">
                <div className="flex justify-between py-1">
                  <span className="text-slate-500">{t('account')}:</span>
                  <span className="font-bold text-slate-800">
                    {getAccountName(viewTx.accountId, language)}
                    {viewTx.toAccountId && ` → ${getAccountName(viewTx.toAccountId, language)}`}
                  </span>
                </div>

                <div className="flex justify-between py-1">
                  <span className="text-slate-500">{t('date')} & {t('time')}:</span>
                  <span className="font-semibold text-slate-800">
                    {formatDate(viewTx.date, language)} • {formatTime(viewTx.time, language)}
                  </span>
                </div>

                {viewTx.description && (
                  <div className="flex justify-between py-1">
                    <span className="text-slate-500">{t('description')}:</span>
                    <span className="font-semibold text-slate-800 max-w-[200px] text-right">
                      {viewTx.description}
                    </span>
                  </div>
                )}

                {viewTx.customerName && (
                  <div className="flex justify-between py-1">
                    <span className="text-slate-500">{t('customerNameLabel')}:</span>
                    <span className="font-bold text-amber-800">{viewTx.customerName}</span>
                  </div>
                )}

                {viewTx.supplierName && (
                  <div className="flex justify-between py-1">
                    <span className="text-slate-500">{t('supplierNameLabel')}:</span>
                    <span className="font-bold text-rose-800">{viewTx.supplierName}</span>
                  </div>
                )}

                {viewTx.reference && (
                  <div className="flex justify-between py-1">
                    <span className="text-slate-500">{t('refLabel')}:</span>
                    <span className="font-mono font-semibold text-slate-800">
                      {viewTx.reference}
                    </span>
                  </div>
                )}
              </div>

              {/* Actions Footer */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <button
                  onClick={() => {
                    setDeleteConfirmId(viewTx.id);
                  }}
                  className="px-3 py-2 text-xs font-bold text-red-600 hover:bg-red-50 rounded-xl flex items-center gap-1 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>{t('delete')}</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      onPrintReceipt(viewTx);
                      setViewTx(null);
                    }}
                    className="px-3 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl flex items-center gap-1"
                  >
                    <Printer className="w-4 h-4" />
                    <span>{t('printReceiptBtn')}</span>
                  </button>

                  <button
                    onClick={() => {
                      onEditTransaction(viewTx);
                      setViewTx(null);
                    }}
                    className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl flex items-center gap-1 shadow-sm"
                  >
                    <Edit2 className="w-4 h-4" />
                    <span>{t('edit')}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION DIALOG */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl p-5 shadow-2xl space-y-3">
            <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 mx-auto flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div className="text-center">
              <h4 className="font-bold text-slate-800 text-sm">
                {t('deleteConfirmTitle')}
              </h4>
              <p className="text-xs text-slate-500 mt-1">
                {t('deleteConfirmDesc')}
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="py-2.5 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl"
              >
                {t('deleteConfirmNo')}
              </button>
              <button
                disabled={isDeleting}
                onClick={() => handleDelete(deleteConfirmId)}
                className="py-2.5 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl shadow-md"
              >
                {isDeleting ? t('deleting') : t('deleteConfirmYes')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
