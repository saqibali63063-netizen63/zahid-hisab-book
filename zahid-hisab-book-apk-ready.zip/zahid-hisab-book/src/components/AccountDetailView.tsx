import React, { useState, useMemo } from 'react';
import {
  ArrowLeft,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  Search,
  Calendar,
  X,
  Plus,
  Receipt,
  Smartphone,
  Banknote,
  Flame,
  Building2,
  Clock,
  Lock,
  Send,
  ArrowDownToLine,
  Percent,
} from 'lucide-react';
import { Account, AccountId, CommissionServiceType, Transaction, TransactionType } from '../types';
import {
  formatDate,
  formatPKR,
  formatTime,
  getAccountBadge,
  getAccountName,
  getCategoryLabel,
  getTodayDateString,
} from '../lib/formatters';
import { useLanguage } from '../context/LanguageContext';

interface AccountDetailViewProps {
  account: Account;
  transactions: Transaction[];
  allAccounts: Account[];
  onBack: () => void;
  onOpenAddModal: (type: TransactionType, accountId: AccountId) => void;
  onOpenTransferModal: (fromAccountId: AccountId) => void;
  onOpenCommissionModal?: (serviceType: CommissionServiceType, accountId: AccountId) => void;
  onSelectTransaction: (tx: Transaction) => void;
  onPrintReceipt: (tx: Transaction) => void;
}

export const AccountDetailView: React.FC<AccountDetailViewProps> = ({
  account,
  transactions,
  allAccounts,
  onBack,
  onOpenAddModal,
  onOpenTransferModal,
  onOpenCommissionModal,
  onSelectTransaction,
  onPrintReceipt,
}) => {
  const { t, language } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [dateFilter, setDateFilter] = useState<'ALL' | 'TODAY' | 'YESTERDAY' | 'WEEK' | 'MONTH' | 'CUSTOM'>('ALL');
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'IN' | 'OUT' | 'TRANSFER'>('ALL');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');

  const todayStr = getTodayDateString();
  const yesterdayDate = new Date();
  yesterdayDate.setDate(yesterdayDate.getDate() - 1);
  const yStr = `${yesterdayDate.getFullYear()}-${String(yesterdayDate.getMonth() + 1).padStart(2, '0')}-${String(yesterdayDate.getDate()).padStart(2, '0')}`;

  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
  const weekStartStr = `${sevenDaysAgo.getFullYear()}-${String(sevenDaysAgo.getMonth() + 1).padStart(2, '0')}-${String(sevenDaysAgo.getDate()).padStart(2, '0')}`;

  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  const monthStartStr = `${thirtyDaysAgo.getFullYear()}-${String(thirtyDaysAgo.getMonth() + 1).padStart(2, '0')}-${String(thirtyDaysAgo.getDate()).padStart(2, '0')}`;

  // Filter transactions specifically for this account
  const accountTransactions = useMemo(() => {
    return transactions.filter((tItem) => {
      const involvesThis =
        tItem.accountId === account.id ||
        tItem.toAccountId === account.id ||
        (account.id === 'cash' && Boolean(tItem.serviceType));
      if (!involvesThis) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchDesc = tItem.description?.toLowerCase().includes(q);
        const matchCust = tItem.customerName?.toLowerCase().includes(q);
        const matchSupp = tItem.supplierName?.toLowerCase().includes(q);
        const matchRef = tItem.reference?.toLowerCase().includes(q);
        const matchProduct = tItem.productName?.toLowerCase().includes(q);
        const matchAmt = String(tItem.amount).includes(q) || String(tItem.principalAmount).includes(q);
        if (!matchDesc && !matchCust && !matchSupp && !matchRef && !matchProduct && !matchAmt) {
          return false;
        }
      }

      if (typeFilter !== 'ALL') {
        if (tItem.serviceType) {
          // If filtering by IN/OUT, consider net direction for this account
          let isAccountIn = false;
          if (account.id === 'cash') {
            isAccountIn = tItem.serviceType === 'send_money';
          } else {
            isAccountIn = tItem.serviceType === 'cash_withdrawal';
          }
          if (typeFilter === 'IN' && !isAccountIn) return false;
          if (typeFilter === 'OUT' && isAccountIn) return false;
          if (typeFilter === 'TRANSFER') return false;
        } else if (tItem.type !== typeFilter) {
          return false;
        }
      }

      if (dateFilter === 'TODAY') {
        if (tItem.date !== todayStr) return false;
      } else if (dateFilter === 'YESTERDAY') {
        if (tItem.date !== yStr) return false;
      } else if (dateFilter === 'WEEK') {
        if (tItem.date < weekStartStr) return false;
      } else if (dateFilter === 'MONTH') {
        if (tItem.date < monthStartStr) return false;
      } else if (dateFilter === 'CUSTOM') {
        if (customStart && tItem.date < customStart) return false;
        if (customEnd && tItem.date > customEnd) return false;
      }

      return true;
    });
  }, [
    transactions,
    account.id,
    searchQuery,
    typeFilter,
    dateFilter,
    customStart,
    customEnd,
    todayStr,
    yStr,
    weekStartStr,
    monthStartStr,
  ]);

  const stats = useMemo(() => {
    let totalIn = 0;
    let totalOut = 0;

    accountTransactions.forEach((tItem) => {
      if (tItem.serviceType) {
        const principal = Number(tItem.principalAmount ?? tItem.amount) || 0;
        const comm = Number(tItem.commissionAmount) || 0;
        if (account.id === 'cash') {
          if (tItem.serviceType === 'send_money') {
            totalIn += principal + comm;
          } else if (tItem.serviceType === 'cash_withdrawal') {
            totalOut += principal - comm;
          }
        } else if (tItem.accountId === account.id) {
          if (tItem.serviceType === 'send_money') {
            totalOut += principal;
          } else if (tItem.serviceType === 'cash_withdrawal') {
            totalIn += principal;
          }
        }
        return;
      }

      const amt = Number(tItem.amount) || 0;
      if (tItem.type === 'IN' && tItem.accountId === account.id) {
        totalIn += amt;
      } else if (tItem.type === 'OUT' && tItem.accountId === account.id) {
        totalOut += amt;
      } else if (tItem.type === 'TRANSFER') {
        if (tItem.accountId === account.id) {
          totalOut += amt;
        } else if (tItem.toAccountId === account.id) {
          totalIn += amt;
        }
      }
    });

    return { totalIn, totalOut, count: accountTransactions.length };
  }, [accountTransactions, account.id]);

  const getAccountIcon = () => {
    switch (account.id) {
      case 'cash':
        return <Banknote className="w-6 h-6 text-emerald-600" />;
      case 'easypaisa':
        return <Smartphone className="w-6 h-6 text-green-600" />;
      case 'jazzcash':
        return <Flame className="w-6 h-6 text-red-600" />;
      case 'bank':
        return <Building2 className="w-6 h-6 text-blue-600" />;
    }
  };

  const getAccountGradient = () => {
    switch (account.id) {
      case 'cash':
        return 'from-emerald-900 via-emerald-800 to-slate-900 border-emerald-700/50';
      case 'easypaisa':
        return 'from-green-900 via-emerald-800 to-slate-900 border-green-700/50';
      case 'jazzcash':
        return 'from-red-950 via-red-900 to-slate-900 border-red-800/50';
      case 'bank':
        return 'from-blue-950 via-blue-900 to-slate-900 border-blue-800/50';
    }
  };

  return (
    <div className="space-y-4 pb-24 pt-2 px-3 sm:px-4 max-w-5xl mx-auto">
      {/* TOP NAVIGATION / BACK BUTTON */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold border border-slate-200 shadow-xs active:scale-95 transition-all"
        >
          <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
          <span>{t('backToDashboard')}</span>
        </button>

        <button
          onClick={() => onOpenTransferModal(account.id)}
          className="flex items-center gap-1.5 px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-800 rounded-xl text-xs font-bold border border-blue-200 shadow-xs active:scale-95 transition-all"
        >
          <ArrowLeftRight className="w-3.5 h-3.5" />
          <span>{t('transferMoney')}</span>
        </button>
      </div>

      {/* ACCOUNT HERO BANNER & CURRENT BALANCE */}
      <div
        className={`bg-gradient-to-br ${getAccountGradient()} rounded-3xl p-5 text-white shadow-xl border relative overflow-hidden`}
      >
        <div className="flex items-center justify-between mb-4 border-b border-white/10 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center shadow-inner">
              {getAccountIcon()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold tracking-tight text-white">
                  {getAccountName(account.id, language)}
                </h2>
                <span className="text-[10px] bg-white/20 text-white font-semibold px-2 py-0.5 rounded-full uppercase tracking-wider">
                  {getAccountBadge(account.id, language)}
                </span>
              </div>
              {account.accountNumber && (
                <p className="text-xs text-white/80 mt-0.5 font-mono">
                  {account.accountNumber}
                </p>
              )}
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-emerald-300 font-semibold bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-700/60 inline-flex items-center gap-1">
              <Lock className="w-2.5 h-2.5" />
              {t('directAccount')}
            </span>
          </div>
        </div>

        {/* Current Balance Display */}
        <div className="text-center py-2">
          <div className="text-xs uppercase tracking-wider text-slate-300 font-semibold mb-1">
            {t('currentBalance')}
          </div>
          <div className="text-3xl sm:text-4xl font-black tracking-tight text-white">
            {formatPKR(account.currentBalance, language)}
          </div>
          <div className="text-[11px] text-white/70 mt-1">
            {t('accountCurrentBalanceDesc')}
          </div>
        </div>

        {/* Inflow vs Outflow Mini Ribbon */}
        <div className="mt-4 pt-3 border-t border-white/10 grid grid-cols-2 gap-2 text-center text-xs">
          <div className="bg-black/20 rounded-xl p-2 border border-white/10">
            <div className="text-[10px] text-emerald-300">{t('totalIncomeReceived')}</div>
            <div className="font-bold text-white text-sm">+{formatPKR(stats.totalIn, language)}</div>
          </div>
          <div className="bg-black/20 rounded-xl p-2 border border-white/10">
            <div className="text-[10px] text-rose-300">{t('totalExpensePaid')}</div>
            <div className="font-bold text-white text-sm">-{formatPKR(stats.totalOut, language)}</div>
          </div>
        </div>
      </div>

      {/* ACCOUNT-SPECIFIC ACTION BUTTONS */}
      {account.id !== 'cash' ? (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {/* Quick Send Money */}
          <button
            onClick={() => onOpenCommissionModal ? onOpenCommissionModal('send_money', account.id) : onOpenAddModal('IN', account.id)}
            className="flex items-center gap-2 p-3 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 active:scale-95 text-white rounded-2xl shadow-sm transition-all font-bold text-xs group"
          >
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <Send className="w-4 h-4" />
            </div>
            <div className="text-start truncate">
              <div className="leading-tight font-black">{t('sendMoney')}</div>
              <div className="text-[10px] text-emerald-200 font-normal">Rs. 10/1k</div>
            </div>
          </button>

          {/* Quick Cash Withdrawal */}
          <button
            onClick={() => onOpenCommissionModal ? onOpenCommissionModal('cash_withdrawal', account.id) : onOpenAddModal('IN', account.id)}
            className="flex items-center gap-2 p-3 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 active:scale-95 text-white rounded-2xl shadow-sm transition-all font-bold text-xs group"
          >
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <ArrowDownToLine className="w-4 h-4" />
            </div>
            <div className="text-start truncate">
              <div className="leading-tight font-black">{t('cashWithdrawal')}</div>
              <div className="text-[10px] text-blue-200 font-normal">Rs. 20/1k</div>
            </div>
          </button>

          {/* Money In */}
          <button
            onClick={() => onOpenAddModal('IN', account.id)}
            className="flex items-center gap-2 p-3 bg-emerald-800 hover:bg-emerald-900 active:scale-95 text-white rounded-2xl shadow-sm transition-all font-bold text-xs group"
          >
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <ArrowDownLeft className="w-4 h-4" />
            </div>
            <div className="text-start truncate">
              <div className="leading-tight">{t('addMoneyInBtn')}</div>
              <div className="text-[10px] text-emerald-200 font-normal">{t('typeIncome')}</div>
            </div>
          </button>

          {/* Money Out */}
          <button
            onClick={() => onOpenAddModal('OUT', account.id)}
            className="flex items-center gap-2 p-3 bg-rose-700 hover:bg-rose-800 active:scale-95 text-white rounded-2xl shadow-sm transition-all font-bold text-xs group"
          >
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <ArrowUpRight className="w-4 h-4" />
            </div>
            <div className="text-start truncate">
              <div className="leading-tight">{t('addMoneyOutBtn')}</div>
              <div className="text-[10px] text-rose-200 font-normal">{t('typeExpense')}</div>
            </div>
          </button>
        </div>
      ) : (
        <div className="space-y-2">
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => onOpenAddModal('IN', account.id)}
              className="flex items-center justify-center gap-2 p-3.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-2xl shadow-md transition-all font-bold text-sm group"
            >
              <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center group-hover:scale-105 transition-transform">
                <ArrowDownLeft className="w-5 h-5" />
              </div>
              <div className="text-start">
                <div className="leading-tight">{t('addMoneyInBtn')}</div>
              </div>
            </button>

            <button
              onClick={() => onOpenAddModal('OUT', account.id)}
              className="flex items-center justify-center gap-2 p-3.5 bg-rose-600 hover:bg-rose-700 active:scale-95 text-white rounded-2xl shadow-md transition-all font-bold text-sm group"
            >
              <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center group-hover:scale-105 transition-transform">
                <ArrowUpRight className="w-5 h-5" />
              </div>
              <div className="text-start">
                <div className="leading-tight">{t('addMoneyOutBtn')}</div>
              </div>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onOpenCommissionModal ? onOpenCommissionModal('send_money', 'easypaisa') : onOpenAddModal('IN', account.id)}
              className="flex items-center justify-center gap-2 p-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-900 rounded-xl font-bold text-xs active:scale-95 transition-all"
            >
              <Send className="w-3.5 h-3.5 text-emerald-700" />
              <span>{t('sendMoney')} (Rs. 10/1k)</span>
            </button>
            <button
              onClick={() => onOpenCommissionModal ? onOpenCommissionModal('cash_withdrawal', 'easypaisa') : onOpenAddModal('IN', account.id)}
              className="flex items-center justify-center gap-2 p-2 bg-blue-50 hover:bg-blue-100 border border-blue-300 text-blue-900 rounded-xl font-bold text-xs active:scale-95 transition-all"
            >
              <ArrowDownToLine className="w-3.5 h-3.5 text-blue-700" />
              <span>{t('cashWithdrawal')} (Rs. 20/1k)</span>
            </button>
          </div>
        </div>
      )}

      {/* SEARCH AND FILTER BAR */}
      <div className="bg-white rounded-2xl border border-slate-200 p-3 sm:p-4 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-xs uppercase tracking-wider text-slate-700">
            {t('accountHistoryTitle')}
          </h3>
          <span className="text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full font-bold">
            {accountTransactions.length} {t('records')}
          </span>
        </div>

        {/* Search Input */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400 rtl:right-3 rtl:left-auto" />
          <input
            type="text"
            placeholder={t('searchPlaceholder')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-8 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-emerald-500 rtl:pr-9 rtl:pl-8"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 rtl:left-3 rtl:right-auto"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Quick Date Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
          {(
            [
              { id: 'ALL', label: t('all') },
              { id: 'TODAY', label: t('today') },
              { id: 'YESTERDAY', label: t('yesterday') },
              { id: 'WEEK', label: t('thisWeek') },
              { id: 'MONTH', label: t('thisMonth') },
              { id: 'CUSTOM', label: t('customRange') },
            ] as const
          ).map((item) => (
            <button
              key={item.id}
              onClick={() => setDateFilter(item.id)}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap text-xs transition-colors ${
                dateFilter === item.id
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {dateFilter === 'CUSTOM' && (
          <div className="grid grid-cols-2 gap-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
            <div>
              <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                {t('from')}
              </label>
              <input
                type="date"
                value={customStart}
                onChange={(e) => setCustomStart(e.target.value)}
                className="w-full p-1.5 bg-white border border-slate-300 rounded-lg text-xs"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                {t('to')}
              </label>
              <input
                type="date"
                value={customEnd}
                onChange={(e) => setCustomEnd(e.target.value)}
                className="w-full p-1.5 bg-white border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </div>
        )}

        {/* Type Filter Buttons */}
        <div className="flex items-center gap-1.5 pt-1 border-t border-slate-100 text-xs">
          <span className="text-[10px] font-bold text-slate-500 mr-1">{t('type')}:</span>
          {(
            [
              { id: 'ALL', label: t('all') },
              { id: 'IN', label: t('typeIncome') },
              { id: 'OUT', label: t('typeExpense') },
              { id: 'TRANSFER', label: t('typeTransfer') },
            ] as const
          ).map((item) => (
            <button
              key={item.id}
              onClick={() => setTypeFilter(item.id)}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors ${
                typeFilter === item.id
                  ? 'bg-emerald-700 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* TRANSACTION HISTORY FOR THIS ACCOUNT */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {accountTransactions.length === 0 ? (
          <div className="p-10 text-center text-slate-400">
            <Receipt className="w-10 h-10 mx-auto text-slate-300 mb-2 stroke-[1.5]" />
            <p className="text-xs font-bold text-slate-700">
              {t('noAccountTransactions')}
            </p>
            <div className="flex items-center justify-center gap-2 mt-4">
              <button
                onClick={() => onOpenAddModal('IN', account.id)}
                className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95"
              >
                {t('addFirstIncome')}
              </button>
              <button
                onClick={() => onOpenAddModal('OUT', account.id)}
                className="px-4 py-2 bg-rose-600 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95"
              >
                {t('addFirstExpense')}
              </button>
            </div>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {accountTransactions.map((tItem) => {
              // Handle commission transactions
              if (tItem.serviceType) {
                const principal = Number(tItem.principalAmount ?? tItem.amount) || 0;
                const comm = Number(tItem.commissionAmount) || 0;
                let isIn = false;
                let displayAmt = 0;
                let flowNote = '';

                if (account.id === 'cash') {
                  if (tItem.serviceType === 'send_money') {
                    isIn = true;
                    displayAmt = principal + comm;
                    flowNote = language === 'ur' ? 'گاہک سے نقد وصول' : 'Cash collected from customer';
                  } else {
                    isIn = false;
                    displayAmt = principal - comm;
                    flowNote = language === 'ur' ? 'گاہک کو نقد ادائیگی' : 'Cash paid to customer';
                  }
                } else {
                  if (tItem.serviceType === 'send_money') {
                    isIn = false;
                    displayAmt = principal;
                    flowNote = language === 'ur' ? 'والٹ سے رقم ارسال' : 'Sent from wallet';
                  } else {
                    isIn = true;
                    displayAmt = principal;
                    flowNote = language === 'ur' ? 'والٹ میں رقم موصول' : 'Received in wallet';
                  }
                }

                return (
                  <div
                    key={tItem.id}
                    onClick={() => onSelectTransaction(tItem)}
                    className="p-3.5 hover:bg-slate-50 transition-colors cursor-pointer flex items-center justify-between gap-3 group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          isIn
                            ? 'bg-emerald-50 text-emerald-600 border border-emerald-200'
                            : 'bg-rose-50 text-rose-600 border border-rose-200'
                        }`}
                      >
                        {isIn ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-xs font-bold text-slate-800">
                            {tItem.serviceType === 'send_money' ? t('sendMoney') : t('cashWithdrawal')}
                          </span>
                          <span className="text-[10px] bg-amber-100 text-amber-900 border border-amber-300 px-1.5 py-0.2 rounded-full font-bold">
                            {t('commissionLabel')}: +{formatPKR(comm, language)}
                          </span>
                          {tItem.reference && (
                            <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded font-mono">
                              #{tItem.reference}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-1">
                          <span className="font-bold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                            {getAccountBadge(tItem.accountId, language)}
                          </span>
                          <span className="text-slate-600">
                            {t('principalAmountLabel')}: {formatPKR(principal, language)}
                          </span>
                          {tItem.customerName && (
                            <span className="text-amber-800 font-semibold bg-amber-50 px-1.5 py-0.5 rounded">
                              {tItem.customerName}
                            </span>
                          )}
                          <span>{formatDate(tItem.date, language)}</span>
                          <span>{formatTime(tItem.time, language)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div
                        className={`text-sm sm:text-base font-black ${
                          isIn ? 'text-emerald-700' : 'text-rose-600'
                        }`}
                      >
                        {isIn ? '+' : '-'}
                        {formatPKR(displayAmt, language)}
                      </div>
                      <div className="text-[10px] text-slate-400 font-medium">
                        {flowNote}
                      </div>
                    </div>
                  </div>
                );
              }

              const isDirectIn = tItem.type === 'IN' && tItem.accountId === account.id;
              const isDirectOut = tItem.type === 'OUT' && tItem.accountId === account.id;
              const isOutgoingTransfer = tItem.type === 'TRANSFER' && tItem.accountId === account.id;
              const isIncomingTransfer = tItem.type === 'TRANSFER' && tItem.toAccountId === account.id;

              return (
                <div
                  key={tItem.id}
                  onClick={() => onSelectTransaction(tItem)}
                  className="p-3.5 hover:bg-slate-50 transition-colors cursor-pointer flex items-center justify-between gap-3 group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                        isDirectIn || isIncomingTransfer
                          ? 'bg-emerald-50 text-emerald-600 border border-emerald-200'
                          : isDirectOut || isOutgoingTransfer
                          ? 'bg-rose-50 text-rose-600 border border-rose-200'
                          : 'bg-blue-50 text-blue-600 border border-blue-200'
                      }`}
                    >
                      {(isDirectIn || isIncomingTransfer) && <ArrowDownLeft className="w-5 h-5" />}
                      {(isDirectOut || isOutgoingTransfer) && <ArrowUpRight className="w-5 h-5" />}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-bold text-slate-800">
                          {tItem.description || getCategoryLabel(tItem.category, language)}
                        </span>
                        {tItem.grossProfit !== undefined && (
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded-full font-bold">
                            {t('pureProfit')}: {formatPKR(tItem.grossProfit, language)}
                          </span>
                        )}
                        {tItem.reference && (
                          <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded font-mono">
                            #{tItem.reference}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-1">
                        {tItem.type === 'TRANSFER' ? (
                          <span className="font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded">
                            {isOutgoingTransfer
                              ? `${t('typeTransfer')} → ${getAccountBadge(tItem.toAccountId!, language)}`
                              : `${t('typeTransfer')} ← ${getAccountBadge(tItem.accountId, language)}`}
                          </span>
                        ) : (
                          <span className="font-bold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded">
                            {getCategoryLabel(tItem.category, language)}
                          </span>
                        )}
                        {tItem.customerName && (
                          <span className="text-amber-800 font-semibold bg-amber-50 px-1.5 py-0.5 rounded">
                            {tItem.customerName}
                          </span>
                        )}
                        <span>{formatDate(tItem.date, language)}</span>
                        <span>{formatTime(tItem.time, language)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div
                      className={`text-sm sm:text-base font-black ${
                        isDirectIn || isIncomingTransfer
                          ? 'text-emerald-700'
                          : 'text-rose-600'
                      }`}
                    >
                      {isDirectIn || isIncomingTransfer ? '+' : '-'}
                      {formatPKR(tItem.amount, language)}
                    </div>
                    <div className="text-[10px] text-slate-400 capitalize">
                      {isDirectIn
                        ? t('typeIncome')
                        : isDirectOut
                        ? t('typeExpense')
                        : t('typeTransfer')}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
